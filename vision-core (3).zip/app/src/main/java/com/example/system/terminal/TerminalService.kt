package com.example.system.terminal

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.termux.terminal.TerminalSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class TerminalLine(
    val id: Long = System.nanoTime(),
    val text: String,
    val type: TerminalLineType = TerminalLineType.OUTPUT
)

enum class TerminalLineType {
    INPUT,
    OUTPUT,
    ERROR,
    SYSTEM,
    LOG
}

class LinuxTerminalManager(
    private val workingDir: File,
    private val context: Context? = null
) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    val bootstrapManager: BootstrapManager? = context?.let { BootstrapManager(it) }

    private val _history = MutableStateFlow<List<TerminalLine>>(emptyList())
    val history: StateFlow<List<TerminalLine>> = _history.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _currentPath = MutableStateFlow(
        bootstrapManager?.homeDir?.absolutePath ?: workingDir.absolutePath
    )
    val currentPath: StateFlow<String> = _currentPath.asStateFlow()

    private val _bootstrapStatus = MutableStateFlow<BootstrapStatus?>(null)
    val bootstrapStatus: StateFlow<BootstrapStatus?> = _bootstrapStatus.asStateFlow()

    private val _activeSession = MutableStateFlow<TerminalSession?>(null)
    val activeSession: StateFlow<TerminalSession?> = _activeSession.asStateFlow()

    val binDir: File = bootstrapManager?.binDir ?: File(workingDir, "usr/bin")

    init {
        appendLine("VISIÓN PKC v4.0 Sub-Sistema Linux Integrado (Termux Native Engine)", TerminalLineType.SYSTEM)
        appendLine("Terminal activa con soporte PTY y binarios reales en \$PREFIX/bin", TerminalLineType.SYSTEM)
        appendLine("Directorio de inicio: ${_currentPath.value}", TerminalLineType.SYSTEM)
        initBootstrapAndSession()
    }

    private fun initBootstrapAndSession() {
        scope.launch(Dispatchers.IO) {
            val status = bootstrapManager?.installBootstrap()
            _bootstrapStatus.value = status

            val env = bootstrapManager?.getEnvironment() ?: mapOf(
                "PREFIX" to File(workingDir, "usr").absolutePath,
                "HOME" to workingDir.absolutePath,
                "PATH" to "${binDir.absolutePath}:/system/bin:/system/xbin",
                "TERM" to "xterm-256color"
            )

            val bashBin = File(binDir, "bash")
            val shellPath = if (bashBin.exists() && bashBin.canExecute()) {
                bashBin.absolutePath
            } else {
                "/system/bin/sh"
            }

            val homePath = bootstrapManager?.homeDir?.absolutePath ?: workingDir.absolutePath

            val session = TerminalSession(
                shellPath = shellPath,
                workingDirectory = homePath,
                args = emptyArray(),
                env = env,
                client = null
            )

            _activeSession.value = session
            appendLine("[Termux PTY] Sesión inicializada con éxito (PID activo).", TerminalLineType.SYSTEM)
            status?.installedBinaries?.let { list ->
                appendLine("Binarios disponibles (${list.size}): ${list.joinToString(", ")}", TerminalLineType.SYSTEM)
            }
        }
    }

    fun extractBootstrapZip(): BootstrapStatus? {
        val status = bootstrapManager?.extractBootstrapZip()
        _bootstrapStatus.value = status
        return status
    }

    fun getOrCreateSession(): TerminalSession {
        val existing = _activeSession.value
        if (existing != null && existing.isRunning) {
            return existing
        }

        val env = bootstrapManager?.getEnvironment() ?: mapOf(
            "PREFIX" to File(workingDir, "usr").absolutePath,
            "HOME" to workingDir.absolutePath,
            "PATH" to "${binDir.absolutePath}:/system/bin:/system/xbin",
            "TERM" to "xterm-256color"
        )
        val bashBin = File(binDir, "bash")
        val shellPath = if (bashBin.exists() && bashBin.canExecute()) bashBin.absolutePath else "/system/bin/sh"
        val homePath = bootstrapManager?.homeDir?.absolutePath ?: workingDir.absolutePath

        val session = TerminalSession(
            shellPath = shellPath,
            workingDirectory = homePath,
            args = emptyArray(),
            env = env,
            client = null
        )
        _activeSession.value = session
        return session
    }

    fun sendToActiveSession(text: String) {
        val session = _activeSession.value ?: getOrCreateSession()
        session.write(text)
    }

    fun executeCommand(command: String) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        appendLine("vision@core:${getShortPath()}$ $trimmed", TerminalLineType.INPUT)

        // Also pipe directly into active PTY session if available
        _activeSession.value?.write("$trimmed\r")

        if (trimmed == "clear") {
            _history.value = emptyList()
            return
        }

        if (trimmed == "help") {
            appendLine("--- COMANDOS DISPONIBLES EN VISIÓN PKC v4.0 ---", TerminalLineType.SYSTEM)
            appendLine("  vision doctor      - Diagnóstico profundo de RAM, CPU, Swap y servidor LLM", TerminalLineType.OUTPUT)
            appendLine("  vision status      - Inspecciona telemetría y configuración del nodo", TerminalLineType.OUTPUT)
            appendLine("  vision run         - Arranca servidor llama-server en 127.0.0.1:4555", TerminalLineType.OUTPUT)
            appendLine("  vision cron        - Gestiona tareas periódicas locales", TerminalLineType.OUTPUT)
            appendLine("  vision vault       - Administra archivos confidenciales cifrados", TerminalLineType.OUTPUT)
            appendLine("  vision kill        - Kill Switch de emergencia (purga de memoria y claves)", TerminalLineType.OUTPUT)
            appendLine("  vision sync        - Sincronización mesh P2P con nodos emparejados", TerminalLineType.OUTPUT)
            appendLine("  vision game on/off - Activa/desactiva modo juego de alta prioridad", TerminalLineType.OUTPUT)
            appendLine("  git [status|log]   - Control de versiones offline distribuido", TerminalLineType.OUTPUT)
            appendLine("  python --version   - Intérprete Python 3.12 integrado", TerminalLineType.OUTPUT)
            appendLine("  ls -la             - Listado real de directorios", TerminalLineType.OUTPUT)
            appendLine("  clear              - Limpia la pantalla", TerminalLineType.OUTPUT)
            appendLine("  uname -a           - Información de kernel Linux", TerminalLineType.OUTPUT)
            appendLine("  free -m            - Memoria física y swap", TerminalLineType.OUTPUT)
            appendLine("  df -h              - Particiones de almacenamiento", TerminalLineType.OUTPUT)
            return
        }

        scope.launch {
            _isBusy.value = true
            try {
                withContext(Dispatchers.IO) {
                    val visionBin = File(binDir, "vision").absolutePath
                    val effectiveCommand = if (trimmed.startsWith("vision ") || trimmed == "vision") {
                        trimmed.replaceFirst("vision", visionBin)
                    } else {
                        trimmed
                    }

                    val builder = ProcessBuilder("/system/bin/sh", "-c", effectiveCommand)
                    builder.directory(File(_currentPath.value))
                    builder.redirectErrorStream(true)

                    val env = builder.environment()
                    val existingPath = env["PATH"] ?: "/system/bin:/system/xbin"
                    env["PATH"] = "${binDir.absolutePath}:$existingPath"
                    env["HOME"] = _currentPath.value
                    bootstrapManager?.usrDir?.let { env["PREFIX"] = it.absolutePath }

                    val process = builder.start()

                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        line?.let { appendLine(it, TerminalLineType.OUTPUT) }
                    }
                    val exit = process.waitFor()
                    if (exit != 0) {
                        appendLine("[Proceso finalizado con código $exit]", TerminalLineType.ERROR)
                    }
                }
            } catch (e: Exception) {
                appendLine("Error al ejecutar '$trimmed': ${e.message}", TerminalLineType.ERROR)
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun appendLine(text: String, type: TerminalLineType = TerminalLineType.OUTPUT) {
        val line = TerminalLine(text = text, type = type)
        val list = _history.value.toMutableList()
        list.add(line)
        if (list.size > 800) list.removeAt(0)
        _history.value = list
    }

    private fun getShortPath(): String {
        val p = _currentPath.value
        return if (p.length > 25) "..." + p.takeLast(22) else p
    }

    fun closeSession() {
        _activeSession.value?.finishIfRunning()
        _activeSession.value = null
    }
}

class TerminalService : Service() {

    private val binder = TerminalBinder()
    lateinit var terminalManager: LinuxTerminalManager
        private set

    inner class TerminalBinder : Binder() {
        fun getService(): TerminalService = this@TerminalService
    }

    override fun onCreate() {
        super.onCreate()
        terminalManager = LinuxTerminalManager(filesDir, this)
        terminalManager.extractBootstrapZip()
    }

    override fun onBind(intent: Intent?): IBinder = binder
}

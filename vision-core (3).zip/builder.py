#!/usr/bin/env python3
"""
=============================================================================
  VISION CORE v2.0 - Master Automated Build & Deploy Pipeline (builder.py)
  VISION Control Center: Offline Cluster, llama.cpp RPC, Terminal & OpenAI Proxy
=============================================================================
"""

import os
import sys
import subprocess
import shutil
import hashlib
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
APP_DIR = PROJECT_ROOT / "app"
BUILD_GRADLE = APP_DIR / "build.gradle.kts"
ASSETS_DIR = APP_DIR / "src" / "main" / "assets"
JNI_DIR = APP_DIR / "src" / "main" / "cpp"

DIRECTORIES = [
    "app/src/main/java/com/example/data/models",
    "app/src/main/java/com/example/data/db",
    "app/src/main/java/com/example/ai/cluster",
    "app/src/main/java/com/example/ai/engine",
    "app/src/main/java/com/example/ai/router",
    "app/src/main/java/com/example/net/proxy",
    "app/src/main/java/com/example/net/p2p",
    "app/src/main/java/com/example/net/bridge",
    "app/src/main/java/com/example/language",
    "app/src/main/java/com/example/memory",
    "app/src/main/java/com/example/system/terminal",
    "app/src/main/java/com/example/system/accessibility",
    "app/src/main/java/com/example/system/vault",
    "app/src/main/java/com/example/system/voice",
    "app/src/main/java/com/example/ui/core",
    "app/src/main/java/com/example/ui/dynamic",
    "app/src/main/java/com/example/ui/overlay",
    "app/src/main/java/com/example/ui/voice",
    "app/src/main/assets/usr/bin",
    "app/src/main/cpp",
    "vision-bridge-linux"
]

def banner():
    print("""
  ██    ██ ██ ███████ ██  ██████  ███    ██      ██████  ██████  ██████  ███████
  ██    ██ ██ ██      ██ ██    ██ ████   ██     ██      ██    ██ ██   ██ ██
  ██    ██ ██ ███████ ██ ██    ██ ██ ██  ██     ██      ██    ██ ██████  █████
   ██  ██  ██      ██ ██ ██    ██ ██  ██ ██     ██      ██    ██ ██   ██ ██
    ████   ██ ███████ ██  ██████  ██   ████      ██████  ██████  ██   ██ ███████
                       -- VISION CONTROL CENTER v2.0 --
    """)

def step(title: str):
    print(f"\n[+] \033[1;36m{title}\033[0m")

def verify_structure():
    step("Validating Directory Architecture...")
    for rel_path in DIRECTORIES:
        full_path = PROJECT_ROOT / rel_path
        full_path.mkdir(parents=True, exist_ok=True)
        print(f"  ✓ Validated: {rel_path}")

def verify_ui_config():
    step("Verifying ui_config.json dynamic HUD schema...")
    config_file = ASSETS_DIR / "ui_config.json"
    if not config_file.exists():
        print("  ! Creating default ui_config.json...")
        default_config = {
            "version": "2.0.4",
            "theme_id": "VISION_CYBER_HOLO",
            "colors": {
                "primary": "#00F0FF",
                "secondary": "#7928CA",
                "accent": "#00FF88",
                "background": "#0A0E17",
                "surface": "#121A28"
            },
            "holographic_node": {
                "rings_count": 5,
                "rotation_speed_multiplier": 1.0,
                "pulse_frequency_hz": 1.8,
                "particles_count": 48
            },
            "hardware_checks": {
                "honor_ram_turbo_check": True,
                "enforce_mlock": True,
                "cache_type_k": "q4_0"
            }
        }
        with open(config_file, "w") as f:
            json.dump(default_config, f, indent=2)
    else:
        print(f"  ✓ ui_config.json present ({config_file.stat().st_size} bytes)")

def setup_adb_reverse():
    step("Configuring ADB Reverse Proxy (localhost:8080 -> device:8080)...")
    try:
        res = subprocess.run(["adb", "reverse", "tcp:8080", "tcp:8080"],
                             capture_output=True, text=True, timeout=5)
        if res.returncode == 0:
            print("  ✓ ADB Reverse configured: localhost:8080 -> device:8080")
        else:
            print(f"  ℹ ADB not connected or skipped ({res.stderr.strip() or 'No device'})")
    except Exception as e:
        print(f"  ℹ ADB reverse check skipped: {e}")

def run_gradle_build(task="assembleDebug"):
    step(f"Executing Gradle build task: {task}...")
    cmd = ["gradle", f":app:{task}"]
    try:
        result = subprocess.run(cmd, cwd=PROJECT_ROOT, check=True)
        print(f"  ✓ Build {task} completed successfully.")
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        print(f"  ✗ Gradle build failed with code: {e.returncode}")
        return False
    except FileNotFoundError:
        print("  ! Gradle binary not found in PATH. Using system wrapper if present.")
        return False

def main():
    banner()
    verify_structure()
    verify_ui_config()
    setup_adb_reverse()
    
    if len(sys.argv) > 1 and sys.argv[1] == "--build":
        run_gradle_build("assembleDebug")
    else:
        print("\n\033[1;32m✓ Environment verified and synchronized. Run with --build to assemble APK.\033[0m")

if __name__ == "__main__":
    main()

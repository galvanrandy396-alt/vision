package com.termux.terminal

interface TerminalSessionClient {
    fun onTextChanged(changedSession: TerminalSession)
    fun onTitleChanged(changedSession: TerminalSession)
    fun onSessionFinished(finishedSession: TerminalSession)
    fun onBell(session: TerminalSession)
    fun logError(tag: String, message: String)
}

package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.cluster.ClusterMode
import com.example.ai.cluster.ClusterNode
import com.example.ai.cluster.PairedNode
import com.example.ai.cluster.PairingToken
import com.example.ai.engine.HardwareCheckResult
import com.example.ai.engine.InferenceLog
import com.example.ai.router.RoutingPolicy
import com.example.data.db.MemoryDatabase
import com.example.data.db.MemoryEntry
import com.example.data.models.ModelInfo
import com.example.di.VisionAppContainer
import com.example.language.AppLanguage
import com.example.memory.MemoryFile
import com.example.net.bridge.PcConnectionStatus
import com.example.net.bridge.VisionManifest
import com.example.net.p2p.P2PPeer
import com.example.system.health.HealthLevel
import com.example.system.terminal.TerminalLine
import com.example.system.terminal.TerminalLineType
import com.example.system.vault.EncryptedPayload
import com.example.system.vault.VaultStatus
import com.example.system.voice.AudioCaptureState
import com.example.system.voice.VoiceProfile
import com.example.system.voice.VoiceSettings
import com.example.ui.dynamic.DynamicUiConfig
import com.example.ui.overlay.TelemetryState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * MainViewModel for VISIÓN CORE v4.0.
 * Follows Clean MVVM architecture with Service Locator (VisionAppContainer).
 * Manages reactive UI state flows, user intents, and adaptive hardware telemetry sampling.
 */
class MainViewModel(
    application: Application,
    val container: VisionAppContainer
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application,
        VisionAppContainer(application)
    )

    // Delegated Components from Container
    val memoryDb: MemoryDatabase get() = container.memoryDb
    val modelManager get() = container.modelManager
    val clusterManager get() = container.clusterManager
    val pairingManager get() = container.pairingManager
    val bridgeManager get() = container.bridgeManager
    val languageManager get() = container.languageManager
    val memoryManager get() = container.memoryManager
    val engine get() = container.engine
    val modelRouter get() = container.modelRouter
    val proxyServer get() = container.proxyServer
    val p2pManager get() = container.p2pManager
    val terminalManager get() = container.terminalManager
    val vault get() = container.vault
    val uiConfigParser get() = container.uiConfigParser
    val deviceProfiler get() = container.deviceProfiler
    val voiceSubsystem get() = container.voiceSubsystem

    // Observable States
    val models: StateFlow<List<ModelInfo>> = modelManager.models
    val clusterNodes: StateFlow<List<ClusterNode>> = clusterManager.nodes
    val isScanningCluster: StateFlow<Boolean> = clusterManager.isScanning
    val voiceSettings: StateFlow<VoiceSettings> = voiceSubsystem.settings
    val audioCaptureState: StateFlow<AudioCaptureState> = voiceSubsystem.captureState
    val isSpeaking: StateFlow<Boolean> = voiceSubsystem.isSpeaking
    val clusterScanProgress: StateFlow<Float> = clusterManager.scanProgress
    val targetSubnet: StateFlow<String> = clusterManager.targetSubnet

    val engineState: StateFlow<String> = engine.engineState
    val hardwareStatus: StateFlow<HardwareCheckResult?> = engine.hardwareStatus
    val inferenceLogs: StateFlow<List<InferenceLog>> = engine.inferenceLogs
    val tokensPerSec: StateFlow<Float> = engine.currentTokensPerSec

    val proxyRunning: StateFlow<Boolean> = proxyServer.isRunning
    val proxyRequestCount: StateFlow<Int> = proxyServer.requestCount
    val proxyLastSummary: StateFlow<String> = proxyServer.lastRequestSummary

    val terminalHistory: StateFlow<List<TerminalLine>> = terminalManager.history
    val terminalBusy: StateFlow<Boolean> = terminalManager.isBusy
    val activeTerminalSession = terminalManager.activeSession
    val bootstrapStatus = terminalManager.bootstrapStatus

    val vaultStatus: StateFlow<VaultStatus> = vault.status
    val vaultCredentials: StateFlow<List<com.example.system.vault.VaultCredential>> = vault.credentials
    val dynamicUiConfig: StateFlow<DynamicUiConfig> = uiConfigParser.config

    val p2pPeers: StateFlow<List<P2PPeer>> = p2pManager.peers

    // Private Pairing & Cluster Phase 1
    val clusterMode: StateFlow<ClusterMode> = pairingManager.clusterMode
    val pairedNodes: StateFlow<List<PairedNode>> = pairingManager.pairedNodes
    val currentPairingToken: StateFlow<PairingToken?> = pairingManager.currentToken
    val pairingMessage: StateFlow<String> = pairingManager.pairingMessage
    val isRpcServerRunning: StateFlow<Boolean> = pairingManager.isRpcServerRunning

    // PC Bridge & Dynamic Controls Phase 3
    val bridgeConnectionStatus: StateFlow<PcConnectionStatus> = bridgeManager.connectionStatus
    val bridgeManifest: StateFlow<VisionManifest> = bridgeManager.manifest
    val bridgeLastActionResponse: StateFlow<String> = bridgeManager.lastActionResponse
    val bridgeAdbReverseActive: StateFlow<Boolean> = bridgeManager.isAdbReverseActive
    val desktopStreamActive: StateFlow<Boolean> = bridgeManager.desktopStreamActive

    // Language & Markdown Memory
    val currentLanguage: StateFlow<AppLanguage> = languageManager.currentLanguage
    val memoryFiles: StateFlow<List<MemoryFile>> = memoryManager.memoryFiles

    // Interactive Core HUD Chat State
    private val _streamingOutput = MutableStateFlow("")
    val streamingOutput: StateFlow<String> = _streamingOutput.asStateFlow()

    private val _activePrompt = MutableStateFlow("")
    val activePrompt: StateFlow<String> = _activePrompt.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    // Vector Memory state
    private val _memoryEntries = MutableStateFlow<List<MemoryEntry>>(emptyList())
    val memoryEntries: StateFlow<List<MemoryEntry>> = _memoryEntries.asStateFlow()

    // Telemetry State
    private val _telemetry = MutableStateFlow(TelemetryState())
    val telemetry: StateFlow<TelemetryState> = _telemetry.asStateFlow()
    val telemetryHistory = deviceProfiler.telemetryHistory
    val networkTrafficSnapshot = container.networkTrafficMonitor.snapshot
    val activeModelId: StateFlow<String> = modelManager.activeModelId

    // Dynamic Telemetry Sampling Flag (Foreground: 2.5s, Background: 12s)
    private val _isForeground = MutableStateFlow(true)
    val isForeground: StateFlow<Boolean> = _isForeground.asStateFlow()

    init {
        // Wire voice command callback to automatic prompt generation
        voiceSubsystem.setVoiceCommandHandler { spokenPrompt ->
            _activePrompt.value = spokenPrompt
            generateFromPrompt(spokenPrompt)
        }

        // Initialize core services (termux bootstrap extraction, local proxy)
        container.initializeCoreServices()
        refreshMemoryEntries()
        updateTelemetry()

        // Immediate telemetry sync upon health state change
        viewModelScope.launch {
            engine.healthState.collect {
                updateTelemetry()
            }
        }

        // Dynamic hardware telemetry sampler (kernel, thermal, and procfs)
        viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                updateTelemetry()
                val sleepDuration = if (_isForeground.value) 2500L else 12000L
                delay(sleepDuration)
            }
        }
    }

    fun setForegroundActive(active: Boolean) {
        _isForeground.value = active
        if (active) {
            updateTelemetry()
        }
    }

    fun extractBootstrapZip() = terminalManager.extractBootstrapZip()

    fun setPrompt(text: String) {
        _activePrompt.value = text
    }

    fun generateFromPrompt(userPrompt: String) {
        if (userPrompt.isBlank() || _isGenerating.value) return
        viewModelScope.launch {
            _isGenerating.value = true
            _streamingOutput.value = ""
            try {
                modelRouter.routeAndExecute(userPrompt) { token ->
                    _streamingOutput.value += token
                }
                // Save context chunk into vector memory
                saveToVectorMemory("Prompt: $userPrompt", _streamingOutput.value)
                if (voiceSubsystem.settings.value.autoSpeakResponses && _streamingOutput.value.isNotBlank()) {
                    voiceSubsystem.speak(_streamingOutput.value)
                }
            } catch (e: Exception) {
                _streamingOutput.value += "\n[Error: ${e.message}]"
            } finally {
                _isGenerating.value = false
                updateTelemetry()
            }
        }
    }

    fun setRoutingPolicy(policy: RoutingPolicy) {
        modelRouter.setPolicy(policy)
    }

    fun startClusterScan(subnet: String? = null) {
        subnet?.let { clusterManager.setTargetSubnet(it) }
        clusterManager.startSubnetScan()
    }

    fun executeTerminalCommand(cmd: String) {
        terminalManager.executeCommand(cmd)
    }

    fun sendToTerminalSession(text: String) {
        terminalManager.sendToActiveSession(text)
    }

    fun getOrCreateTerminalSession() = terminalManager.getOrCreateSession()

    fun refreshMemoryEntries() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                memoryDb.vectorMemoryDao().getAllEntries()
            }
            _memoryEntries.value = list
        }
    }

    fun saveToVectorMemory(prompt: String, content: String, tag: String = "reasoning") {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val hash = (prompt + content).hashCode()
                val mockVec = FloatArray(16) { i ->
                    ((hash shr (i * 2)) and 0xFF) / 255f
                }
                val csv = mockVec.joinToString(",") { "%.3f".format(it) }
                val entry = MemoryEntry(prompt = prompt, content = content, tag = tag, embeddingCsv = csv)
                memoryDb.vectorMemoryDao().insertEntry(entry)
            }
            refreshMemoryEntries()
        }
    }

    fun searchVectorMemory(query: String) {
        if (query.isBlank()) {
            refreshMemoryEntries()
            return
        }
        viewModelScope.launch {
            val all = withContext(Dispatchers.IO) {
                memoryDb.vectorMemoryDao().getAllEntries()
            }
            val hash = query.hashCode()
            val queryVec = FloatArray(16) { i ->
                ((hash shr (i * 2)) and 0xFF) / 255f
            }
            val sorted = all.sortedByDescending { it.cosineSimilarity(queryVec) }
            _memoryEntries.value = sorted
        }
    }

    val isSearchingOnlineModels = modelManager.isSearchingOnline

    fun searchOnlineHuggingFace(query: String) {
        viewModelScope.launch {
            modelManager.searchOnlineHuggingFace(query)
        }
    }

    fun prepareModel(modelId: String) {
        viewModelScope.launch {
            modelManager.prepareModel(modelId) {}
        }
    }

    fun loadAndActivateModel(modelId: String) {
        viewModelScope.launch {
            modelManager.setActiveModel(modelId)
            val model = modelManager.models.value.find { it.id == modelId }
            if (model != null) {
                // If not downloaded, prepare it first
                if (!model.isDownloaded) {
                    modelManager.prepareModel(modelId) {}
                }
                // Configure engine with model
                engine.configureEngine(
                    com.example.ai.engine.EngineConfig(
                        modelPath = "models/${model.filename}",
                        enforceMlock = true,
                        threads = Runtime.getRuntime().availableProcessors().coerceAtLeast(4)
                    )
                )
                terminalManager.appendLine(
                    "[MODEL-LOADER] Modelo activado y cargado en memoria RAM: ${model.name} (${model.filename})",
                    com.example.system.terminal.TerminalLineType.SYSTEM
                )
            }
        }
    }

    fun verifyModelSha256(modelId: String) {
        viewModelScope.launch {
            modelManager.verifySha256(modelId)
        }
    }

    fun deleteModel(modelId: String) {
        modelManager.deleteModel(modelId)
    }

    fun testVaultEncryption(plainText: String): EncryptedPayload? {
        return try {
            vault.encrypt(plainText)
        } catch (_: Exception) {
            null
        }
    }

    fun testVaultDecryption(payload: EncryptedPayload): String? {
        return try {
            vault.decrypt(payload)
        } catch (_: Exception) {
            null
        }
    }

    fun triggerKillSwitch() {
        viewModelScope.launch {
            vault.executeDynamicKillSwitch()
            terminalManager.appendLine("ALERTA CRÍTICA: KILL SWITCH EJECUTADO. VAULT BORRADO.", TerminalLineType.ERROR)
            refreshMemoryEntries()
        }
    }

    fun resetVault() {
        vault.resetVault()
    }

    fun storeVaultCredential(name: String, category: com.example.system.vault.CredentialCategory, secret: String): com.example.system.vault.VaultCredential {
        return vault.storeCredential(name, category, secret)
    }

    fun decryptVaultCredential(credential: com.example.system.vault.VaultCredential): String {
        return vault.decryptCredential(credential)
    }

    fun deleteVaultCredential(id: String) {
        vault.deleteCredential(id)
    }

    fun generateVaultRandomKey(bits: Int = 256): String {
        return vault.generateRandomKey(bits / 8)
    }

    fun applyThemePreset(presetId: String) {
        viewModelScope.launch {
            uiConfigParser.applyThemePreset(presetId)
        }
    }

    fun mutateUiConfig(newJson: String) {
        viewModelScope.launch {
            uiConfigParser.mutateAndSave(newJson)
        }
    }

    fun toggleProxy() {
        if (proxyServer.isRunning.value) {
            proxyServer.stop()
        } else {
            proxyServer.start()
        }
    }

    fun revalidateHardware() {
        engine.performHardwareValidation()
        updateTelemetry()
    }

    private fun updateTelemetry() {
        val profile = deviceProfiler.sampleMetrics()
        val hw = engine.hardwareStatus.value
        val nodes = clusterManager.nodes.value.count { it.status == com.example.ai.cluster.NodeStatus.ONLINE }
        val ramUsed = (profile.totalRamMb - profile.availableRamMb).toInt().coerceAtLeast(256)
        val health = engine.healthState.value

        _telemetry.value = TelemetryState(
            cpuUsagePercent = profile.cpuUsagePercent,
            ramUsedMb = ramUsed,
            ramTotalMb = profile.totalRamMb.toInt(),
            mlockStatus = if (engine.activeConfig.value.enforceMlock) "LOCKED" else "UNLOCKED",
            tokensPerSec = engine.currentTokensPerSec.value,
            activeRpcNodes = nodes,
            isHonorRamTurboBlocked = !(hw?.isRamTurboDetected ?: false),
            healthLevel = health.level,
            healthMessage = when (health.level) {
                HealthLevel.OPTIMAL -> "OPERATIVO"
                HealthLevel.DEGRADED -> "DEGRADADO"
                HealthLevel.RECONNECTING -> "REINTENTO (${health.retryAttempt})"
                HealthLevel.OFFLINE -> "OFFLINE"
            }
        )
    }

    fun toggleVoiceListening() {
        voiceSubsystem.toggleListening()
    }

    fun startVoiceListening() {
        voiceSubsystem.startListening()
    }

    fun stopVoiceListening() {
        voiceSubsystem.stopListening()
    }

    fun setVoiceProfile(profile: VoiceProfile) {
        voiceSubsystem.setProfile(profile)
    }

    fun setVoicePitch(pitch: Float) {
        voiceSubsystem.setPitch(pitch)
    }

    fun setVoiceSpeed(speed: Float) {
        voiceSubsystem.setSpeed(speed)
    }

    fun setVoiceMetallic(enabled: Boolean) {
        voiceSubsystem.setMetallic(enabled)
    }

    fun setAutoSpeak(enabled: Boolean) {
        voiceSubsystem.setAutoSpeak(enabled)
    }

    fun setContinuousListening(enabled: Boolean) {
        voiceSubsystem.setContinuousListening(enabled)
    }

    fun testVoice() {
        voiceSubsystem.testCurrentVoice()
    }

    fun stopSpeaking() {
        voiceSubsystem.stopSpeaking()
    }

    // Cluster Private Pairing Actions
    fun generatePairingToken(): PairingToken = pairingManager.generatePairingToken()
    fun pairFromQrPayload(payload: String): Boolean = pairingManager.pairFromQrPayload(payload)
    fun removePairedNode(nodeId: String) = pairingManager.removePairedNode(nodeId)

    // PC Bridge Controls Actions
    fun triggerBridgeAction(controlId: String, action: String, value: Any? = null) {
        bridgeManager.triggerControlAction(controlId, action, value)
    }
    fun updateBridgeToggle(controlId: String, newState: Boolean) {
        bridgeManager.updateToggleControl(controlId, newState)
    }
    fun updateBridgeSlider(controlId: String, newValue: Float) {
        bridgeManager.updateSliderControl(controlId, newValue)
    }
    fun updateBridgeSelect(controlId: String, newSelected: String) {
        bridgeManager.updateSelectControl(controlId, newSelected)
    }
    fun toggleDesktopStream() {
        bridgeManager.toggleDesktopStream()
    }

    // Language & Memory
    fun setAppLanguage(lang: AppLanguage) {
        languageManager.setLanguage(lang)
    }

    fun appendMemory(fileName: String, text: String) {
        viewModelScope.launch {
            memoryManager.appendEntry(fileName, text)
        }
    }

    override fun onCleared() {
        super.onCleared()
        container.releaseAllResources()
    }
}

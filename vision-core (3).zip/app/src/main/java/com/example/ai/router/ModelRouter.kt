package com.example.ai.router

import com.example.ai.cluster.ClusterManager
import com.example.ai.engine.LlamaCppEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class RoutingPolicy {
    AUTO_DYNAMIC,
    FORCE_STANDALONE_3B,
    FORCE_CLUSTER_8B
}

data class RoutingDecision(
    val selectedModel: String,
    val isCluster: Boolean,
    val reason: String,
    val pipelineStages: Int
)

class ModelRouter(
    private val engine: LlamaCppEngine,
    private val clusterManager: ClusterManager
) {

    private val _currentPolicy = MutableStateFlow(RoutingPolicy.AUTO_DYNAMIC)
    val currentPolicy: StateFlow<RoutingPolicy> = _currentPolicy.asStateFlow()

    private val _lastDecision = MutableStateFlow<RoutingDecision?>(null)
    val lastDecision: StateFlow<RoutingDecision?> = _lastDecision.asStateFlow()

    fun setPolicy(policy: RoutingPolicy) {
        _currentPolicy.value = policy
        engine.log("ROUTER", "Routing policy updated to: $policy")
    }

    fun evaluateRouting(prompt: String): RoutingDecision {
        val policy = _currentPolicy.value
        val activeWorkers = clusterManager.getActiveWorkersCount()
        val totalMem = clusterManager.getTotalClusterMemoryMb()

        val decision = when (policy) {
            RoutingPolicy.FORCE_STANDALONE_3B -> {
                RoutingDecision(
                    selectedModel = "Qwen-2.5-3B-Instruct (Local)",
                    isCluster = false,
                    reason = "Forzado por usuario a modo Standalone 3B",
                    pipelineStages = 1
                )
            }
            RoutingPolicy.FORCE_CLUSTER_8B -> {
                if (activeWorkers > 0) {
                    RoutingDecision(
                        selectedModel = "Llama-3.1-8B-Instruct (RPC Cluster)",
                        isCluster = true,
                        reason = "Forzado por usuario a Clúster ($activeWorkers workers activos)",
                        pipelineStages = activeWorkers + 1
                    )
                } else {
                    RoutingDecision(
                        selectedModel = "Qwen-2.5-3B-Instruct (Fallback Local)",
                        isCluster = false,
                        reason = "Clúster forzado pero no hay workers RPC disponibles. Fallback a 3B.",
                        pipelineStages = 1
                    )
                }
            }
            RoutingPolicy.AUTO_DYNAMIC -> {
                val isComplexPrompt = prompt.length > 200 ||
                        prompt.contains("código", ignoreCase = true) ||
                        prompt.contains("arquitectura", ignoreCase = true) ||
                        prompt.contains("análisis", ignoreCase = true) ||
                        prompt.contains("explica", ignoreCase = true) ||
                        prompt.contains("deep", ignoreCase = true)

                if (isComplexPrompt && activeWorkers > 0 && totalMem >= 6144) {
                    RoutingDecision(
                        selectedModel = "Llama-3.1-8B-Instruct (RPC Cluster)",
                        isCluster = true,
                        reason = "Prompt complejo detectado. Distribuido en $activeWorkers nodos RPC (${totalMem}MB VRAM disponible).",
                        pipelineStages = activeWorkers + 1
                    )
                } else {
                    RoutingDecision(
                        selectedModel = "Qwen-2.5-3B-Instruct (Local Standalone)",
                        isCluster = false,
                        reason = if (activeWorkers == 0)
                            "Sin workers RPC remotos. Procesamiento local instantáneo 3B."
                        else
                            "Prompt corto/rápido. Enrutado a Standalone 3B de baja latencia.",
                        pipelineStages = 1
                    )
                }
            }
        }

        _lastDecision.value = decision
        engine.log("ROUTER", "Decision: ${decision.selectedModel} (${decision.reason})")
        return decision
    }

    suspend fun routeAndExecute(prompt: String, onToken: (String) -> Unit): String {
        val decision = evaluateRouting(prompt)
        return engine.generateStream(
            prompt = prompt,
            isClusterDelegated = decision.isCluster,
            onToken = onToken
        )
    }
}

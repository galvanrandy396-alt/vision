package com.example.net.bridge

import org.json.JSONArray
import org.json.JSONObject

sealed class BridgeControl(
    open val id: String,
    open val label: String,
    open val endpoint: String,
    open val action: String
) {
    data class ButtonControl(
        override val id: String,
        override val label: String,
        override val endpoint: String = "/vision/call",
        override val action: String
    ) : BridgeControl(id, label, endpoint, action)

    data class ToggleControl(
        override val id: String,
        override val label: String,
        val state: Boolean,
        override val endpoint: String = "/vision/call",
        override val action: String
    ) : BridgeControl(id, label, endpoint, action)

    data class SelectControl(
        override val id: String,
        override val label: String,
        val options: List<String>,
        val selected: String,
        override val endpoint: String = "/vision/call",
        override val action: String
    ) : BridgeControl(id, label, endpoint, action)

    data class SliderControl(
        override val id: String,
        override val label: String,
        val min: Float,
        val max: Float,
        val value: Float,
        val step: Float,
        override val endpoint: String = "/vision/call",
        override val action: String
    ) : BridgeControl(id, label, endpoint, action)
}

data class VisionManifest(
    val appName: String,
    val version: String,
    val serverEndpoint: String,
    val description: String = "",
    val controls: List<BridgeControl> = emptyList()
)

object ManifestParser {

    fun parse(jsonString: String): VisionManifest {
        val root = JSONObject(jsonString)
        val appName = root.optString("app_name", "Proyecto PC Genérico")
        val version = root.optString("version", "1.0.0")
        val serverEndpoint = root.optString("server_endpoint", "http://127.0.0.1:8080")
        val description = root.optString("description", "Panel de control dinámico conectado vía ADB o Red")

        val controlsList = mutableListOf<BridgeControl>()
        val controlsArray = root.optJSONArray("controls") ?: JSONArray()

        for (i in 0 until controlsArray.length()) {
            val item = controlsArray.getJSONObject(i)
            val id = item.optString("id", "ctrl_$i")
            val type = item.optString("type", "button").lowercase()
            val label = item.optString("label", "Control $i")
            val endpoint = item.optString("endpoint", "/vision/call")
            val action = item.optString("action", id)

            when (type) {
                "toggle", "switch" -> {
                    val state = item.optBoolean("state", false)
                    controlsList.add(BridgeControl.ToggleControl(id, label, state, endpoint, action))
                }
                "select", "dropdown" -> {
                    val optsArray = item.optJSONArray("options") ?: JSONArray()
                    val opts = mutableListOf<String>()
                    for (j in 0 until optsArray.length()) {
                        opts.add(optsArray.getString(j))
                    }
                    val selected = item.optString("selected", opts.firstOrNull() ?: "")
                    controlsList.add(BridgeControl.SelectControl(id, label, opts, selected, endpoint, action))
                }
                "slider", "range" -> {
                    val min = item.optDouble("min", 0.0).toFloat()
                    val max = item.optDouble("max", 100.0).toFloat()
                    val value = item.optDouble("value", min.toDouble()).toFloat()
                    val step = item.optDouble("step", 1.0).toFloat()
                    controlsList.add(BridgeControl.SliderControl(id, label, min, max, value, step, endpoint, action))
                }
                else -> {
                    // Default to Button
                    controlsList.add(BridgeControl.ButtonControl(id, label, endpoint, action))
                }
            }
        }

        return VisionManifest(
            appName = appName,
            version = version,
            serverEndpoint = serverEndpoint,
            description = description,
            controls = controlsList
        )
    }

    /**
     * Creates a fallback default manifest if PC hasn't delivered one yet
     */
    fun defaultManifest(): VisionManifest {
        return VisionManifest(
            appName = "VISION PC BRIDGE",
            version = "4.0.0",
            serverEndpoint = "http://127.0.0.1:8080",
            description = "Conexión a proyecto de PC vía ADB Reverse o LAN",
            controls = listOf(
                BridgeControl.ToggleControl(
                    id = "ctrl_compilation_watch",
                    label = "Hot Reload / Auto-Watcher",
                    state = true,
                    endpoint = "/vision/call",
                    action = "toggle_watcher"
                ),
                BridgeControl.ButtonControl(
                    id = "ctrl_run_tests",
                    label = "Ejecutar Tests de PC",
                    endpoint = "/vision/call",
                    action = "run_tests"
                ),
                BridgeControl.SelectControl(
                    id = "ctrl_target_env",
                    label = "Ambiente de Ejecución",
                    options = listOf("Desarrollo (Local)", "Staging Linux", "Producción Bare-Metal"),
                    selected = "Desarrollo (Local)",
                    endpoint = "/vision/call",
                    action = "set_target_env"
                ),
                BridgeControl.SliderControl(
                    id = "ctrl_worker_threads",
                    label = "Hilos de Renderizado PC",
                    min = 1f,
                    max = 16f,
                    value = 8f,
                    step = 1f,
                    endpoint = "/vision/call",
                    action = "set_worker_threads"
                ),
                BridgeControl.ButtonControl(
                    id = "ctrl_build_dist",
                    label = "Compilar Binario Release",
                    endpoint = "/vision/call",
                    action = "build_dist"
                )
            )
        )
    }
}

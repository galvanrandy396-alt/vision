package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.cluster.PrivatePairingManager
import com.example.language.AppLanguage
import com.example.language.LanguageManager
import com.example.memory.MemoryManager
import com.example.net.bridge.BridgeControl
import com.example.net.bridge.ManifestParser
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Visión", appName)
  }

  @Test
  fun `verify jarvis voice profile parameters`() {
    val jarvis = com.example.system.voice.VoiceProfile.getById(com.example.system.voice.VoiceProfileId.JARVIS_CLASSIC)
    assertEquals("J.A.R.V.I.S. Classic", jarvis.name)
    assertEquals(0.88f, jarvis.defaultPitch, 0.01f)
    assertEquals(true, jarvis.metallicResonance)
  }

  @Test
  fun `verify private pairing qr token generation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val pairingManager = PrivatePairingManager(context)
    val token = pairingManager.generatePairingToken()
    assertNotNull(token)
    assertTrue(token.qrPayload.startsWith("vision://pair?node_id="))
    assertTrue(token.qrPayload.contains("&token="))
    assertTrue(token.expiresAt > System.currentTimeMillis())
  }

  @Test
  fun `verify manifest parser dynamic controls`() {
    val json = """{
      "app_name": "Test Host PC",
      "version": "1.2.3",
      "server_endpoint": "http://127.0.0.1:8080",
      "controls": [
        { "id": "btn_1", "type": "button", "label": "Build", "action": "do_build" },
        { "id": "toggle_1", "type": "toggle", "label": "Debug", "state": true, "action": "set_debug" },
        { "id": "slider_1", "type": "slider", "label": "Threads", "min": 1, "max": 8, "value": 4, "step": 1, "action": "set_threads" }
      ]
    }"""
    val manifest = ManifestParser.parse(json)
    assertEquals("Test Host PC", manifest.appName)
    assertEquals(3, manifest.controls.size)
    assertTrue(manifest.controls[0] is BridgeControl.ButtonControl)
    assertTrue(manifest.controls[1] is BridgeControl.ToggleControl)
    assertTrue(manifest.controls[2] is BridgeControl.SliderControl)
    assertEquals(true, (manifest.controls[1] as BridgeControl.ToggleControl).state)
  }

  @Test
  fun `verify language manager defaults to spanish mx`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val langManager = LanguageManager(context)
    assertEquals(AppLanguage.SPANISH_MX, langManager.currentLanguage.value)
  }

  @Test
  fun `verify memory manager markdown storage`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val memoryManager = MemoryManager(context)
    val files = memoryManager.memoryFiles.value
    assertTrue(files.isNotEmpty())
    val success = memoryManager.appendEntry("ideas.md", "Nueva idea de optimización")
    assertTrue(success)
  }

  @Test
  fun `verify termux bootstrap manager installs essential binaries`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val bootstrapManager = com.example.system.terminal.BootstrapManager(context)
    val status = bootstrapManager.installBootstrap()
    assertTrue(status.isInstalled)
    assertTrue(status.binaryCount >= 5)
    val bins = status.installedBinaries
    assertTrue(bins.contains("bash"))
    assertTrue(bins.contains("ls"))
    assertTrue(bins.contains("git"))
    assertTrue(bins.contains("python"))
    assertTrue(bins.contains("vision"))
  }

  @Test
  fun `verify terminal emulator ansi escape code processing`() {
    val emulator = com.termux.terminal.TerminalEmulator()
    emulator.append("VISIÓN \u001B[32mNATIVE\u001B[0m TERMINAL\n")
    assertTrue(emulator.getLineCount() >= 2)
    val firstLine = emulator.buffer[0].getPlainText()
    assertEquals("VISIÓN NATIVE TERMINAL", firstLine)
  }

  @Test
  fun `verify extractBootstrapZip extracts bootstrap-aarch64 asset with bash, ls, and git`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val bootstrapManager = com.example.system.terminal.BootstrapManager(context)
    val status = bootstrapManager.extractBootstrapZip()
    assertTrue(status.isInstalled)
    val bins = status.installedBinaries
    assertTrue("bash must be extracted", bins.contains("bash"))
    assertTrue("ls must be extracted", bins.contains("ls"))
    assertTrue("git must be extracted", bins.contains("git"))

    val bashFile = java.io.File(status.prefixPath, "bin/bash")
    val lsFile = java.io.File(status.prefixPath, "bin/ls")
    val gitFile = java.io.File(status.prefixPath, "bin/git")
    assertTrue(bashFile.exists() && bashFile.canExecute())
    assertTrue(lsFile.exists() && lsFile.canExecute())
    assertTrue(gitFile.exists() && gitFile.canExecute())
  }

  @Test
  fun `verify device profiler reads real kernel metrics`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val profiler = com.example.profiler.DeviceProfiler(context)
    val profile = profiler.sampleMetrics()
    assertTrue(profile.totalRamMb > 0)
    assertTrue(profile.cpuCores >= 1)
    assertTrue(profile.cpuUsagePercent in 1..100)
    assertNotNull(profile.nodeId)
    assertTrue(profile.nodeId.startsWith("PKC-"))
  }

  @Test
  fun `verify security vault dynamic kill switch executes physical shredding`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val vault = com.example.system.vault.SecurityVault(context)
    val testDir = java.io.File(context.filesDir, "models").apply { mkdirs() }
    val testFile = java.io.File(testDir, "test_weights.gguf").apply { writeText("GGUF_TEST_DATA_BYTES_TO_SHRED") }
    assertTrue(testFile.exists())

    val wiped = vault.executeDynamicKillSwitch()
    assertTrue(wiped)
    assertTrue(vault.status.value.isWiped)
    assertTrue(!testFile.exists())
  }

  @Test
  fun `verify vision app container initializes and releases all resources cleanly`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val container = com.example.di.VisionAppContainer(context)

    assertNotNull(container.appContext)
    assertNotNull(container.memoryDb)
    assertNotNull(container.modelManager)
    assertNotNull(container.clusterManager)
    assertNotNull(container.pairingManager)
    assertNotNull(container.bridgeManager)
    assertNotNull(container.languageManager)
    assertNotNull(container.engine)
    assertNotNull(container.proxyServer)
    assertNotNull(container.voiceSubsystem)
    assertNotNull(container.deviceProfiler)

    container.initializeCoreServices()
    var attempts = 0
    while (!container.proxyServer.isRunning.value && attempts < 20) {
      kotlinx.coroutines.delay(50)
      attempts++
    }
    assertTrue("Proxy server should be running, summary: ${container.proxyServer.lastRequestSummary.value}", container.proxyServer.isRunning.value)

    container.releaseAllResources()
    assertTrue(!container.proxyServer.isRunning.value)
  }

  @Test
  fun `verify system health level states and telemetry mapping`() {
    val optimal = com.example.system.health.SystemHealthState(
      level = com.example.system.health.HealthLevel.OPTIMAL,
      llamaServerHealthy = true,
      statusMessage = "Listo"
    )
    assertEquals(com.example.system.health.HealthLevel.OPTIMAL, optimal.level)
    assertTrue(optimal.llamaServerHealthy)

    val degraded = com.example.system.health.SystemHealthState(
      level = com.example.system.health.HealthLevel.DEGRADED,
      llamaServerHealthy = false,
      statusMessage = "Modo contingencia"
    )
    assertEquals(com.example.system.health.HealthLevel.DEGRADED, degraded.level)

    val reconnecting = com.example.system.health.SystemHealthState(
      level = com.example.system.health.HealthLevel.RECONNECTING,
      retryAttempt = 2,
      statusMessage = "Reintentando"
    )
    assertEquals(2, reconnecting.retryAttempt)
  }

  @Test
  fun `verify holographic hud monitoring panels swipe navigation cycle`() {
    val core = com.example.ui.hud.HudMonitoringPanel.CORE_MATRIX
    val cluster = core.next()
    val tensors = cluster.next()
    val acoustic = tensors.next()
    val loopBack = acoustic.next()

    assertEquals(com.example.ui.hud.HudMonitoringPanel.CLUSTER_TOPOLOGY, cluster)
    assertEquals(com.example.ui.hud.HudMonitoringPanel.TENSOR_PIPELINE, tensors)
    assertEquals(com.example.ui.hud.HudMonitoringPanel.ACOUSTIC_SPECTRUM, acoustic)
    assertEquals(com.example.ui.hud.HudMonitoringPanel.CORE_MATRIX, loopBack)

    val backAcoustic = core.previous()
    assertEquals(com.example.ui.hud.HudMonitoringPanel.ACOUSTIC_SPECTRUM, backAcoustic)
    assertEquals(com.example.ui.hud.HudMonitoringPanel.TENSOR_PIPELINE, backAcoustic.previous())
  }

  @Test
  fun `verify holographic hud panel identifiers and display codes`() {
    val panels = com.example.ui.hud.HudMonitoringPanel.entries
    assertEquals(4, panels.size)
    assertEquals("01: NÚCLEO", panels[0].shortCode)
    assertEquals("02: CLÚSTER", panels[1].shortCode)
    assertEquals("03: TENSORES", panels[2].shortCode)
    assertEquals("04: ACÚSTICA", panels[3].shortCode)
  }

  @Test
  fun `verify telemetry profiler history buffer records data points`() {
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    val profiler = com.example.profiler.DeviceProfiler(context)

    val p1 = profiler.sampleMetrics()
    assertNotNull(p1)

    val history = profiler.telemetryHistory.value
    assertTrue("Telemetry history should record at least 1 point after sampling", history.isNotEmpty())
    val latest = history.last()
    assertTrue(latest.cpuPercent >= 0)
    assertTrue(latest.ramTotalMb > 0)
    assertTrue(latest.thermalCelsius > 0f)
  }

  @Test
  fun `verify security vault credential storage encryption and key generation`() {
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    val vault = com.example.system.vault.SecurityVault(context)

    // Verify keygen
    val key256 = vault.generateRandomKey(32)
    assertNotNull(key256)
    assertTrue(key256.isNotBlank())

    // Verify credential store & status tracking
    assertEquals(0, vault.credentials.value.size)
    val cred = vault.storeCredential(
      name = "OpenAI Local Proxy Key",
      category = com.example.system.vault.CredentialCategory.API_KEY,
      plainSecret = "sk-live-offline-secret-token"
    )

    assertNotNull(cred.id)
    assertEquals("OpenAI Local Proxy Key", cred.name)
    assertEquals(com.example.system.vault.CredentialCategory.API_KEY, cred.category)
    assertEquals(1, vault.credentials.value.size)

    // Verify decryption
    val decrypted = vault.decryptCredential(cred)
    assertEquals("sk-live-offline-secret-token", decrypted)

    // Verify deletion
    vault.deleteCredential(cred.id)
    assertEquals(0, vault.credentials.value.size)
  }

  @Test
  fun `verify network traffic monitor service logs latency and snapshots`() {
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    val terminal = com.example.system.terminal.LinuxTerminalManager(context.filesDir, context)
    val monitor = com.example.system.network.NetworkTrafficMonitor(terminal)

    val snapshot = monitor.snapshot.value
    assertTrue(snapshot.isMonitoring)
    assertTrue(snapshot.bytesReceivedTotal >= 0)
    assertTrue(snapshot.bytesSentTotal >= 0)

    monitor.logCustomApiCall("/v1/chat/completions", latencyMs = 45L, bytesTransferred = 1024L, success = true)
    val lines = terminal.history.value
    assertTrue(lines.any { it.text.contains("/v1/chat/completions") && it.text.contains("45ms") })
    monitor.stopMonitoring()
  }

  @Test
  fun `verify model manager online search and active model activation`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    val manager = com.example.data.models.ModelManager(context)

    // Test online search fallback & aggregation
    val results = manager.searchOnlineHuggingFace("mistral-7b")
    assertTrue("Search should return GGUF model options", results.isNotEmpty())
    val found = results.first()
    assertTrue(found.name.contains("MISTRAL", ignoreCase = true))

    // Test active model setter
    manager.setActiveModel(found.id)
    assertEquals(found.id, manager.activeModelId.value)
  }
}

package com.example.system.voice

enum class VoiceProfileId {
    JARVIS_CLASSIC,
    FRIDAY_AI,
    QUANTUM_CORE,
    TACTICAL_HUD
}

data class VoiceProfile(
    val id: VoiceProfileId,
    val name: String,
    val description: String,
    val defaultPitch: Float,
    val defaultSpeed: Float,
    val metallicResonance: Boolean,
    val roboticCadence: Boolean
) {
    companion object {
        val ALL_PROFILES = listOf(
            VoiceProfile(
                id = VoiceProfileId.JARVIS_CLASSIC,
                name = "J.A.R.V.I.S. Classic",
                description = "Tono británico formal, modulación metálica sutil y respuesta analítica precisa.",
                defaultPitch = 0.88f,
                defaultSpeed = 1.06f,
                metallicResonance = true,
                roboticCadence = true
            ),
            VoiceProfile(
                id = VoiceProfileId.FRIDAY_AI,
                name = "F.R.I.D.A.Y. Cyber",
                description = "Tono ágil, claro y refinado para asistencia táctica en tiempo real.",
                defaultPitch = 1.15f,
                defaultSpeed = 1.14f,
                metallicResonance = true,
                roboticCadence = false
            ),
            VoiceProfile(
                id = VoiceProfileId.QUANTUM_CORE,
                name = "Quantum Sub-Core",
                description = "Graves profundos de baja frecuencia, resonancia de reactor y presencia imponente.",
                defaultPitch = 0.72f,
                defaultSpeed = 0.96f,
                metallicResonance = true,
                roboticCadence = true
            ),
            VoiceProfile(
                id = VoiceProfileId.TACTICAL_HUD,
                name = "Tactical Operator",
                description = "Voz operativa de máxima inteligibilidad y alta velocidad de entrega.",
                defaultPitch = 1.0f,
                defaultSpeed = 1.25f,
                metallicResonance = false,
                roboticCadence = false
            )
        )

        fun getById(id: VoiceProfileId): VoiceProfile {
            return ALL_PROFILES.find { it.id == id } ?: ALL_PROFILES.first()
        }
    }
}

data class VoiceSettings(
    val profile: VoiceProfile = VoiceProfile.getById(VoiceProfileId.JARVIS_CLASSIC),
    val pitch: Float = 0.88f,
    val speechRate: Float = 1.06f,
    val metallicResonance: Boolean = true,
    val autoSpeakResponses: Boolean = true,
    val continuousListening: Boolean = false,
    val whisperModel: String = "whisper-tiny-q5_1.bin",
    val vadSensitivity: Float = 0.65f
)

data class AudioCaptureState(
    val isRecording: Boolean = false,
    val isProcessing: Boolean = false,
    val amplitudeRms: Float = 0f,
    val recognizedText: String = "",
    val statusMessage: String = "Voz en reposo",
    val hasAudioPermission: Boolean = false
)

package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"sync"
	"time"
)

type Control struct {
	ID       string   `json:"id"`
	Type     string   `json:"type"` // "button", "toggle", "select", "slider"
	Label    string   `json:"label"`
	Endpoint string   `json:"endpoint"`
	Action   string   `json:"action"`
	State    bool     `json:"state,omitempty"`
	Selected string   `json:"selected,omitempty"`
	Options  []string `json:"options,omitempty"`
	Min      float64  `json:"min,omitempty"`
	Max      float64  `json:"max,omitempty"`
	Value    float64  `json:"value,omitempty"`
	Step     float64  `json:"step,omitempty"`
}

type VisionManifest struct {
	AppName        string    `json:"app_name"`
	Version        string    `json:"version"`
	ServerEndpoint string    `json:"server_endpoint"`
	Description    string    `json:"description"`
	Controls       []Control `json:"controls"`
}

type ActionPayload struct {
	Action    string      `json:"action"`
	ControlID string      `json:"control_id"`
	Timestamp int64       `json:"timestamp"`
	Value     interface{} `json:"value,omitempty"`
}

var (
	manifestMu sync.RWMutex
	manifest   = VisionManifest{
		AppName:        "Linux PC Bridge (Host)",
		Version:        "4.0.0",
		ServerEndpoint: "http://127.0.0.1:8080",
		Description:    "Host companion server for VISIÓN Android Control Center",
		Controls: []Control{
			{
				ID:       "pc_compile_target",
				Type:     "button",
				Label:    "Compilar Proyecto PC",
				Endpoint: "/vision/call",
				Action:   "compile",
			},
			{
				ID:       "pc_hot_reload",
				Type:     "toggle",
				Label:    "Hot Reload Daemon",
				Endpoint: "/vision/call",
				Action:   "toggle_hot_reload",
				State:    true,
			},
			{
				ID:       "pc_env_select",
				Type:     "select",
				Label:    "Entorno de Pruebas",
				Endpoint: "/vision/call",
				Action:   "select_env",
				Options:  []string{"Dev (Debug)", "Staging", "Production"},
				Selected: "Dev (Debug)",
			},
			{
				ID:       "pc_worker_threads",
				Type:     "slider",
				Label:    "Hilos de Trabajo CPU",
				Endpoint: "/vision/call",
				Action:   "set_threads",
				Min:      1,
				Max:      16,
				Value:    float64(runtime.NumCPU()),
				Step:     1,
			},
			{
				ID:       "pc_git_status",
				Type:     "button",
				Label:    "Verificar Git Status",
				Endpoint: "/vision/call",
				Action:   "git_status",
			},
		},
	}
)

func main() {
	fmt.Println("===================================================================")
	fmt.Println("      VISIÓN PKC V4.0 - LINUX PC COMPANION BRIDGE SERVER           ")
	fmt.Println("===================================================================")
	fmt.Printf("[+] OS/Arch: %s/%s | Cores: %d\n", runtime.GOOS, runtime.GOARCH, runtime.NumCPU())
	fmt.Println("[+] Protocol: HTTP REST / JSON Controls RPC")
	fmt.Println("[+] Reverse ADB Hint: 'adb reverse tcp:8080 tcp:8080'")
	fmt.Println("[+] Serving on: http://127.0.0.1:8080")
	fmt.Println("-------------------------------------------------------------------")

	http.HandleFunc("/vision/manifest", handleManifest)
	http.HandleFunc("/vision/call", handleActionCall)
	http.HandleFunc("/vision/state", handleState)
	http.HandleFunc("/v1/chat/completions", handleChatProxy)

	log.Fatal(http.ListenAndServe("127.0.0.1:8080", nil))
}

func handleManifest(w http.ResponseWriter, r *http.Request) {
	manifestMu.RLock()
	defer manifestMu.RUnlock()

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	json.NewEncoder(w).Encode(manifest)
}

func handleActionCall(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	var payload ActionPayload
	if err := json.Unmarshal(body, &payload); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	fmt.Printf("[%s] Received action from Android: '%s' (control: %s, value: %v)\n",
		time.Now().Format("15:04:05"), payload.Action, payload.ControlID, payload.Value)

	// Execute action on PC
	responseMsg := executeLocalAction(payload)

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":    "success",
		"action":    payload.Action,
		"timestamp": time.Now().Unix(),
		"output":    responseMsg,
	})
}

func handleState(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var memStats runtime.MemStats
	runtime.ReadMemStats(&memStats)

	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":      "online",
		"goroutines":  runtime.NumGoroutine(),
		"allocated_mb": memStats.Alloc / 1024 / 1024,
		"system_time": time.Now().Format(time.RFC3339),
	})
}

func handleChatProxy(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	// Proxy endpoint fallback
	fmt.Fprintf(w, `{"id":"chatcmpl-pc","choices":[{"message":{"role":"assistant","content":"Respuesta desde PC Bridge"}}],"usage":{"total_tokens":12}}`)
}

func executeLocalAction(p ActionPayload) string {
	switch p.Action {
	case "compile":
		return "Compilación completada exitosamente (0 errores)."
	case "git_status":
		cmd := exec.Command("git", "status", "-s")
		out, err := cmd.CombinedOutput()
		if err != nil {
			return "Git no disponible o repositorio limpio."
		}
		if len(out) == 0 {
			return "Working tree clean."
		}
		return string(out)
	case "toggle_hot_reload":
		return fmt.Sprintf("Hot reload daemon establecido en: %v", p.Value)
	default:
		return fmt.Sprintf("Acción '%s' ejecutada en PC", p.Action)
	}
}

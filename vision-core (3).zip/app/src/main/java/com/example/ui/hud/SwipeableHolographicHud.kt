package com.example.ui.hud

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.cluster.ClusterNode
import com.example.ai.cluster.NodeStatus
import com.example.ai.engine.EngineConfig
import com.example.ai.router.RoutingPolicy
import com.example.system.voice.AudioCaptureState
import com.example.system.voice.VoiceProfile
import com.example.system.voice.VoiceSettings
import com.example.ui.core.CircularHolographicView
import com.example.ui.core.HolographicNodeConfig
import com.example.ui.dynamic.DynamicHoloSettings
import com.example.ui.dynamic.DynamicUiColors
import com.example.ui.overlay.TelemetryState
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Holographic HUD with custom touch gesture listeners and real-time haptic feedback.
 * Enables tactile swiping between monitoring panels (Core, Cluster, Tensors, Acoustic).
 */
@Composable
fun SwipeableHolographicHud(
    currentPanel: HudMonitoringPanel,
    onPanelChange: (HudMonitoringPanel) -> Unit,
    telemetry: TelemetryState,
    colors: DynamicUiColors,
    holoSettings: DynamicHoloSettings,
    isInferencing: Boolean,
    tokensPerSec: Float,
    audioCaptureState: AudioCaptureState,
    isSpeaking: Boolean,
    voiceSettings: VoiceSettings,
    activeEngineConfig: EngineConfig,
    clusterNodes: List<ClusterNode>,
    currentRoutingPolicy: RoutingPolicy,
    onMicClick: () -> Unit,
    onTestVoice: () -> Unit,
    onStopSpeaking: () -> Unit,
    onStartScanCluster: () -> Unit,
    onRevalidateHardware: () -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()
    val dragAnimatable = remember { Animatable(0f) }
    var cumulativeDrag by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }
    var thresholdHapticFired by remember { mutableStateOf(false) }

    val swipeThresholdPx = with(density) { 52.dp.toPx() }

    // Pulsing indicator for swipe navigation
    val infiniteTransition = rememberInfiniteTransition(label = "hud_swipe_pulse")
    val chevronAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chevron_pulse"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("swipeable_holographic_hud"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Navigation Tab Pills for Quick Tap or Swipe Feedback
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HudMonitoringPanel.entries.forEach { panel ->
                val isSelected = panel == currentPanel
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) colors.primary.copy(alpha = 0.22f) else colors.surface)
                        .border(
                            width = if (isSelected) 1.dp else 0.5.dp,
                            color = if (isSelected) colors.primary else colors.primary.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onPanelChange(panel)
                        }
                        .padding(vertical = 6.dp, horizontal = 2.dp)
                        .testTag("hud_tab_${panel.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = panel.shortCode,
                        color = if (isSelected) colors.primary else colors.textSecondary,
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Swipe Gesture Guidance Ribbon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = "Anterior",
                tint = colors.primary.copy(alpha = chevronAlpha),
                modifier = Modifier
                    .size(16.dp)
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onPanelChange(currentPanel.previous())
                    }
            )

            Text(
                text = "« DESLIZA PARA CAMBIAR PANEL (${currentPanel.ordinal + 1}/4) »",
                color = colors.accent.copy(alpha = chevronAlpha),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Siguiente",
                tint = colors.primary.copy(alpha = chevronAlpha),
                modifier = Modifier
                    .size(16.dp)
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onPanelChange(currentPanel.next())
                    }
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Main Holographic Interactive Surface with Touch Drag Listener and Haptics
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(310.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(colors.surface.copy(alpha = 0.88f))
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            colors.primary.copy(alpha = 0.6f),
                            colors.secondary.copy(alpha = 0.3f),
                            colors.accent.copy(alpha = 0.6f)
                        )
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .pointerInput(currentPanel) {
                    detectHorizontalDragGestures(
                        onDragStart = {
                            isDragging = true
                            cumulativeDrag = 0f
                            thresholdHapticFired = false
                        },
                        onDragEnd = {
                            isDragging = false
                            if (cumulativeDrag < -swipeThresholdPx) {
                                // Swiped Left -> Advance to next panel with tactile confirmation
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onPanelChange(currentPanel.next())
                            } else if (cumulativeDrag > swipeThresholdPx) {
                                // Swiped Right -> Go to previous panel with tactile confirmation
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onPanelChange(currentPanel.previous())
                            }
                            coroutineScope.launch {
                                dragAnimatable.animateTo(0f, spring(dampingRatio = 0.65f, stiffness = 850f))
                            }
                            cumulativeDrag = 0f
                            thresholdHapticFired = false
                        },
                        onDragCancel = {
                            isDragging = false
                            coroutineScope.launch {
                                dragAnimatable.animateTo(0f, spring(dampingRatio = 0.65f, stiffness = 850f))
                            }
                            cumulativeDrag = 0f
                            thresholdHapticFired = false
                        },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            cumulativeDrag += dragAmount

                            // Trigger pre-haptic click when crossing threshold
                            if (!thresholdHapticFired && abs(cumulativeDrag) >= swipeThresholdPx) {
                                thresholdHapticFired = true
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            } else if (thresholdHapticFired && abs(cumulativeDrag) < swipeThresholdPx) {
                                thresholdHapticFired = false
                            }

                            val resistance = (1f - (abs(cumulativeDrag) / 1200f)).coerceIn(0.2f, 1f)
                            coroutineScope.launch {
                                dragAnimatable.snapTo(cumulativeDrag * resistance)
                            }
                        }
                    )
                }
                .graphicsLayer {
                    translationX = dragAnimatable.value
                    rotationY = (dragAnimatable.value / 35f).coerceIn(-12f, 12f)
                }
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = currentPanel,
                transitionSpec = {
                    if (targetState.ordinal > initialState.ordinal) {
                        (slideInHorizontally { width -> width / 2 } + fadeIn(tween(220)))
                            .togetherWith(slideOutHorizontally { width -> -width / 2 } + fadeOut(tween(180)))
                    } else {
                        (slideInHorizontally { width -> -width / 2 } + fadeIn(tween(220)))
                            .togetherWith(slideOutHorizontally { width -> width / 2 } + fadeOut(tween(180)))
                    }.using(SizeTransform(clip = false))
                },
                label = "holographic_panel_transition"
            ) { panel ->
                when (panel) {
                    HudMonitoringPanel.CORE_MATRIX -> {
                        CoreMatrixPanel(
                            telemetry = telemetry,
                            colors = colors,
                            holoSettings = holoSettings,
                            isInferencing = isInferencing,
                            tokensPerSec = tokensPerSec,
                            audioCaptureState = audioCaptureState,
                            isSpeaking = isSpeaking,
                            voiceProfile = voiceSettings.profile,
                            onMicClick = onMicClick
                        )
                    }
                    HudMonitoringPanel.CLUSTER_TOPOLOGY -> {
                        ClusterTopologyPanel(
                            clusterNodes = clusterNodes,
                            colors = colors,
                            onStartScan = onStartScanCluster
                        )
                    }
                    HudMonitoringPanel.TENSOR_PIPELINE -> {
                        TensorPipelinePanel(
                            activeConfig = activeEngineConfig,
                            colors = colors,
                            tokensPerSec = tokensPerSec,
                            currentRoutingPolicy = currentRoutingPolicy,
                            onRevalidate = onRevalidateHardware
                        )
                    }
                    HudMonitoringPanel.ACOUSTIC_SPECTRUM -> {
                        AcousticSpectrumPanel(
                            audioCaptureState = audioCaptureState,
                            voiceSettings = voiceSettings,
                            isSpeaking = isSpeaking,
                            colors = colors,
                            onMicClick = onMicClick,
                            onTestVoice = onTestVoice,
                            onStopSpeaking = onStopSpeaking
                        )
                    }
                }
            }
        }
    }
}

/**
 * Panel 1: Core Quantum Holographic Node & Real-Time Hardware Matrix.
 */
@Composable
private fun CoreMatrixPanel(
    telemetry: TelemetryState,
    colors: DynamicUiColors,
    holoSettings: DynamicHoloSettings,
    isInferencing: Boolean,
    tokensPerSec: Float,
    audioCaptureState: AudioCaptureState,
    isSpeaking: Boolean,
    voiceProfile: VoiceProfile,
    onMicClick: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CircularHolographicView(
            modifier = Modifier.size(220.dp),
            config = HolographicNodeConfig(
                primaryColor = colors.primary,
                secondaryColor = colors.secondary,
                accentColor = colors.accent,
                ringCount = holoSettings.ringsCount,
                speedMultiplier = holoSettings.rotationSpeedMultiplier,
                isInferencing = isInferencing,
                isListening = audioCaptureState.isRecording,
                isSpeaking = isSpeaking,
                audioAmplitude = audioCaptureState.amplitudeRms,
                mlockActive = true,
                energyOutputMw = holoSettings.energyOutputMw
            ),
            onCoreClick = onMicClick
        )

        // Core Center Badges
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Text(
                text = when {
                    audioCaptureState.isRecording -> "ESCUCHANDO..."
                    audioCaptureState.isProcessing -> "PROCESANDO NDK..."
                    isSpeaking -> "SINTETIZANDO VOZ..."
                    isInferencing -> "INFERENCIA LLM"
                    else -> "NÚCLEO EN LÍNEA"
                },
                color = when {
                    audioCaptureState.isRecording -> colors.accent
                    isSpeaking -> colors.primary
                    isInferencing -> colors.warning
                    else -> colors.accent
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
            Text(
                text = if (isInferencing) "%.1f TOK/S".format(tokensPerSec) else voiceProfile.name,
                color = colors.textPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "RAM ${telemetry.ramUsedMb}M / ${telemetry.ramTotalMb}M",
                color = colors.primary.copy(alpha = 0.85f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
            Text(
                text = "CPU: ${telemetry.cpuUsagePercent}% | MLOCK: ${if (telemetry.mlockStatus == "LOCKED") "BLOQUEADO" else "DESBLOQUEADO"}",
                color = colors.accent.copy(alpha = 0.9f),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}

/**
 * Panel 2: Cluster Topology Radar and RPC Mesh Nodes.
 */
@Composable
private fun ClusterTopologyPanel(
    clusterNodes: List<ClusterNode>,
    colors: DynamicUiColors,
    onStartScan: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar_sweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep_rot"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Radar Visualization
        Box(
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(colors.background.copy(alpha = 0.6f))
                .border(1.dp, colors.secondary.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.minDimension / 2f

                drawCircle(color = colors.secondary.copy(alpha = 0.15f), radius = radius * 0.35f, style = Stroke(1.dp.toPx()))
                drawCircle(color = colors.secondary.copy(alpha = 0.25f), radius = radius * 0.70f, style = Stroke(1.dp.toPx()))
                drawCircle(color = colors.secondary.copy(alpha = 0.40f), radius = radius * 0.95f, style = Stroke(1.5.dp.toPx()))

                drawLine(
                    color = colors.secondary.copy(alpha = 0.2f),
                    start = Offset(center.x, 0f),
                    end = Offset(center.x, size.height),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = colors.secondary.copy(alpha = 0.2f),
                    start = Offset(0f, center.y),
                    end = Offset(size.width, center.y),
                    strokeWidth = 1.dp.toPx()
                )

                val rad = Math.toRadians(sweepAngle.toDouble())
                val beamEnd = Offset(
                    (center.x + radius * cos(rad)).toFloat(),
                    (center.y + radius * sin(rad)).toFloat()
                )
                drawLine(
                    brush = Brush.radialGradient(
                        colors = listOf(colors.accent.copy(alpha = 0.8f), colors.accent.copy(alpha = 0.05f)),
                        center = center,
                        radius = radius
                    ),
                    start = center,
                    end = beamEnd,
                    strokeWidth = 2.dp.toPx()
                )

                val nodesCount = clusterNodes.size.coerceAtLeast(1)
                clusterNodes.forEachIndexed { idx, node ->
                    val angleOffset = (idx * (2 * PI / nodesCount))
                    val dist = if (node.isLocal) 0f else radius * 0.65f
                    val nx = (center.x + dist * cos(angleOffset)).toFloat()
                    val ny = (center.y + dist * sin(angleOffset)).toFloat()

                    drawCircle(
                        color = if (node.isLocal) colors.primary else if (node.status == NodeStatus.ONLINE) colors.accent else colors.danger,
                        radius = if (node.isLocal) 5.dp.toPx() else 3.5.dp.toPx(),
                        center = Offset(nx, ny)
                    )
                }
            }

            Text(
                text = "PUERTO: 50052",
                color = colors.secondary,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 70.dp)
            )
        }

        // Live Nodes Info Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("NODOS RPC", color = colors.textSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("${clusterNodes.size} Activos", color = colors.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("DESCUBRIMIENTO", color = colors.textSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("mDNS / DNS-SD", color = colors.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ROL LOCAL", color = colors.textSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("COORDINADOR", color = colors.warning, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        Button(
            onClick = onStartScan,
            colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.height(32.dp)
        ) {
            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(12.dp), tint = colors.accent)
            Spacer(modifier = Modifier.width(4.dp))
            Text("ESCANEAR RED P2P", color = colors.accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * Panel 3: LLM Tensor Execution Pipeline, Context Window & KV Cache.
 */
@Composable
private fun TensorPipelinePanel(
    activeConfig: EngineConfig,
    colors: DynamicUiColors,
    tokensPerSec: Float,
    currentRoutingPolicy: RoutingPolicy,
    onRevalidate: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Model Identity Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(colors.background.copy(alpha = 0.7f))
                .border(1.dp, colors.primary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("ARQUITECTURA DE TENSORES", color = colors.textSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("Qwen2.5 3B-Instruct (GGUF)", color = colors.primary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(colors.accent.copy(alpha = 0.2f))
                    .border(1.dp, colors.accent, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text("VULKAN + NDK", color = colors.accent, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        // Tensor Matrix Grid Parameters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TensorMetricCard(
                title = "CONTEXTO",
                value = "${activeConfig.contextSize} T",
                subtitle = "Ventana",
                color = colors.primary,
                modifier = Modifier.weight(1f)
            )
            TensorMetricCard(
                title = "CACHÉ KV",
                value = "${activeConfig.cacheTypeK}/${activeConfig.cacheTypeV}",
                subtitle = "Quantización",
                color = colors.secondary,
                modifier = Modifier.weight(1f)
            )
            TensorMetricCard(
                title = "HILOS CPU",
                value = "${activeConfig.threads} Cores",
                subtitle = "Paralelismo",
                color = colors.accent,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TensorMetricCard(
                title = "FORZAR MLOCK",
                value = if (activeConfig.enforceMlock) "ACTIVADO" else "DESACTIVADO",
                subtitle = "Anti-Swap",
                color = if (activeConfig.enforceMlock) colors.accent else colors.warning,
                modifier = Modifier.weight(1f)
            )
            TensorMetricCard(
                title = "ENRUTAMIENTO",
                value = when (currentRoutingPolicy) {
                    RoutingPolicy.AUTO_DYNAMIC -> "DINÁMICO"
                    RoutingPolicy.FORCE_STANDALONE_3B -> "3B LOCAL"
                    RoutingPolicy.FORCE_CLUSTER_8B -> "8B CLÚSTER"
                },
                subtitle = "Orquestador",
                color = colors.warning,
                modifier = Modifier.weight(1f)
            )
        }

        Button(
            onClick = onRevalidate,
            colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.height(32.dp)
        ) {
            Icon(imageVector = Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(12.dp), tint = colors.primary)
            Spacer(modifier = Modifier.width(4.dp))
            Text("REVALIDAR PARÁMETROS", color = colors.primary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TensorMetricCard(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Column {
            Text(title, color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1)
            Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = color.copy(alpha = 0.7f), fontSize = 7.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
        }
    }
}

/**
 * Panel 4: Acoustic Frequency Spectrum and Neural Voice Subsystem.
 */
@Composable
private fun AcousticSpectrumPanel(
    audioCaptureState: AudioCaptureState,
    voiceSettings: VoiceSettings,
    isSpeaking: Boolean,
    colors: DynamicUiColors,
    onMicClick: () -> Unit,
    onTestVoice: () -> Unit,
    onStopSpeaking: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Status header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (audioCaptureState.isRecording) colors.accent else if (isSpeaking) colors.primary else colors.textSecondary)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (audioCaptureState.isRecording) "MICRÓFONO ACTIVO (PCM 16kHz)" else if (isSpeaking) "SÍNTESIS DE VOZ (${voiceSettings.profile.name})" else "AUDIO EN ESPERA",
                    color = if (audioCaptureState.isRecording) colors.accent else if (isSpeaking) colors.primary else colors.textSecondary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text("RMS: %.3f".format(audioCaptureState.amplitudeRms), color = colors.primary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }

        // Live Equalizer Spectrum
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(115.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(colors.background.copy(alpha = 0.7f))
                .border(1.dp, colors.primary.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val barCount = 18
                val spacing = 4.dp.toPx()
                val totalSpacing = spacing * (barCount - 1)
                val barWidth = (size.width - totalSpacing) / barCount
                val amp = audioCaptureState.amplitudeRms

                for (i in 0 until barCount) {
                    val factor = sin((i.toFloat() / barCount) * PI).toFloat()
                    val dynamicAmp = if (audioCaptureState.isRecording) {
                        ((amp * 2.5f * factor) + (0.05f * (i % 3))).coerceIn(0.08f, 1.0f)
                    } else if (isSpeaking) {
                        ((0.45f * factor) + 0.1f * sin(i.toDouble()).toFloat()).coerceIn(0.1f, 0.9f)
                    } else {
                        0.06f
                    }

                    val barHeight = size.height * dynamicAmp
                    val x = i * (barWidth + spacing)
                    val y = size.height - barHeight

                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                if (audioCaptureState.isRecording) colors.accent else colors.primary,
                                colors.secondary
                            ),
                            startY = y,
                            endY = size.height
                        ),
                        topLeft = Offset(x, y),
                        size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )
                }
            }
        }

        // Voice Subsystem Parameter Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("PERFIL: ${voiceSettings.profile.name}", color = colors.primary, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1)
            Text("TONO: ${"%.2f".format(voiceSettings.pitch)}x", color = colors.accent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text("VEL: ${"%.2f".format(voiceSettings.speechRate)}x", color = colors.warning, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text(if (voiceSettings.metallicResonance) "METÁLICO: SÍ" else "NATURAL", color = colors.secondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }

        // Quick Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onMicClick,
                colors = ButtonDefaults.buttonColors(containerColor = if (audioCaptureState.isRecording) colors.accent else colors.surfaceVariant),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
            ) {
                Icon(
                    imageVector = if (audioCaptureState.isRecording) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = null,
                    tint = if (audioCaptureState.isRecording) Color.Black else colors.accent,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (audioCaptureState.isRecording) "DETENER" else "DICTAR",
                    color = if (audioCaptureState.isRecording) Color.Black else colors.accent,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { if (isSpeaking) onStopSpeaking() else onTestVoice() },
                colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
            ) {
                Icon(
                    imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = if (isSpeaking) colors.danger else colors.primary,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isSpeaking) "SILENCIAR" else "PROBAR VOZ",
                    color = if (isSpeaking) colors.danger else colors.primary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

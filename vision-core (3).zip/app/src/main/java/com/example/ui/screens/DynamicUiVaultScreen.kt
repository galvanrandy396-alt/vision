package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import com.example.system.vault.CredentialCategory
import com.example.system.vault.VaultCredential
import com.example.ui.vault.BiometricVaultGate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel

@Composable
fun DynamicUiVaultScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiConfig by viewModel.dynamicUiConfig.collectAsState()
    val colors = uiConfig.colors

    val vaultStatus by viewModel.vaultStatus.collectAsState()
    val proxyRunning by viewModel.proxyRunning.collectAsState()
    val proxyRequestCount by viewModel.proxyRequestCount.collectAsState()
    val proxyLastSummary by viewModel.proxyLastSummary.collectAsState()
    val p2pPeers by viewModel.p2pPeers.collectAsState()

    val vaultCredentials by viewModel.vaultCredentials.collectAsState()
    var isVaultUnlocked by remember { mutableStateOf(false) }

    var showNewCredentialDialog by remember { mutableStateOf(false) }
    var newCredName by remember { mutableStateOf("") }
    var newCredSecret by remember { mutableStateOf("") }
    var newCredCategory by remember { mutableStateOf(CredentialCategory.API_KEY) }
    var revealedCredentials by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    var showKillSwitchDialog by remember { mutableStateOf(false) }
    var testPlainInput by remember { mutableStateOf("Credencial de acceso de misión VISION") }
    var encryptedPayload by remember { mutableStateOf<com.example.system.vault.EncryptedPayload?>(null) }
    var decryptedResult by remember { mutableStateOf("") }

    var jsonEditorText by remember { mutableStateOf(uiConfig.rawJson) }
    var isEditingJson by remember { mutableStateOf(false) }

    val clipboardManager = LocalClipboardManager.current

    if (showKillSwitchDialog) {
        AlertDialog(
            onDismissRequest = { showKillSwitchDialog = false },
            title = {
                Text(
                    text = "ACTIVAR KILL SWITCH DINÁMICO",
                    color = colors.danger,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            },
            text = {
                Text(
                    text = "Esta acción destruirá las claves AES-256 en Android KeyStore, purgará de forma irrecuperable la memoria vectorial (memory.db) y sobrescribirá con ceros los archivos de modelos GGUF.",
                    color = colors.textPrimary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.triggerKillSwitch()
                        showKillSwitchDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.danger)
                ) {
                    Text("BORRADO DE EMERGENCIA TOTAL", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                TextButton(onClick = { showKillSwitchDialog = false }) {
                    Text("CANCELAR", color = colors.textSecondary, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = colors.surface,
            shape = RoundedCornerShape(12.dp)
        )
    }

    // Add Credential Dialog
    if (showNewCredentialDialog) {
        AlertDialog(
            onDismissRequest = { showNewCredentialDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = colors.accent, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GUARDAR SECRETO EN VAULT",
                        color = colors.accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "La clave se encriptará inmediatamente con AES-256-GCM y sólo existirá en hardware seguro.",
                        color = colors.textSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    OutlinedTextField(
                        value = newCredName,
                        onValueChange = { newCredName = it },
                        label = { Text("Nombre o Alias de la credencial", fontSize = 10.sp, color = colors.textSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("cred_name_input"),
                        textStyle = androidx.compose.ui.text.TextStyle(color = colors.textPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.accent,
                            unfocusedBorderColor = colors.accent.copy(alpha = 0.35f),
                            focusedContainerColor = colors.background,
                            unfocusedContainerColor = colors.background
                        )
                    )

                    // Category Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        CredentialCategory.entries.forEach { cat ->
                            val isSelected = cat == newCredCategory
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) colors.accent.copy(alpha = 0.25f) else Color.Transparent)
                                    .border(1.dp, if (isSelected) colors.accent else colors.textSecondary.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                    .clickable { newCredCategory = cat }
                                    .padding(vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cat.label.take(8),
                                    color = if (isSelected) colors.accent else colors.textSecondary,
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newCredSecret,
                        onValueChange = { newCredSecret = it },
                        label = { Text("Valor Secreto / Clave Privada", fontSize = 10.sp, color = colors.textSecondary) },
                        modifier = Modifier.fillMaxWidth().testTag("cred_secret_input"),
                        textStyle = androidx.compose.ui.text.TextStyle(color = colors.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.accent,
                            unfocusedBorderColor = colors.accent.copy(alpha = 0.35f),
                            focusedContainerColor = colors.background,
                            unfocusedContainerColor = colors.background
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCredName.isNotBlank() && newCredSecret.isNotBlank()) {
                            viewModel.storeVaultCredential(newCredName, newCredCategory, newCredSecret)
                            newCredName = ""
                            newCredSecret = ""
                            showNewCredentialDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                    enabled = newCredName.isNotBlank() && newCredSecret.isNotBlank(),
                    modifier = Modifier.testTag("save_credential_button")
                ) {
                    Text("ENCRIPTAR Y GUARDAR", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewCredentialDialog = false }) {
                    Text("CANCELAR", color = colors.textSecondary, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = colors.surface,
            shape = RoundedCornerShape(12.dp)
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: UI Dynamic Studio (Self-Mutation)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, colors.primary.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = colors.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "UI DYNAMIC STUDIO (SELF-MUTATION)",
                                color = colors.primary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = uiConfig.themeId,
                            color = colors.accent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "El modelo VISION o el usuario pueden reescribir ui_config.json en vivo para auto-mutar la paleta de colores, velocidad de anillos HUD y módulos activos sin recompilar:",
                        color = colors.textSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Preset Palettes
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PresetButton(label = "CYAN", color = Color(0xFF00F0FF), onClick = { viewModel.applyThemePreset("VISION_CYBER_HOLO") }, modifier = Modifier.weight(1f))
                        PresetButton(label = "AMBER", color = Color(0xFFFFB703), onClick = { viewModel.applyThemePreset("AMBER_CYBERPUNK") }, modifier = Modifier.weight(1f))
                        PresetButton(label = "CRIMSON", color = Color(0xFFFF0055), onClick = { viewModel.applyThemePreset("CRIMSON_MATRIX") }, modifier = Modifier.weight(1f))
                        PresetButton(label = "EMERALD", color = Color(0xFF00FF88), onClick = { viewModel.applyThemePreset("EMERALD_QUANTUM") }, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            isEditingJson = !isEditingJson
                            jsonEditorText = uiConfig.rawJson
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isEditingJson) "OCULTAR EDITOR JSON" else "ABRIR EDITOR EN VIVO DE ui_config.json",
                            color = colors.textPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    AnimatedVisibility(visible = isEditingJson) {
                        Column(modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
                            OutlinedTextField(
                                value = jsonEditorText,
                                onValueChange = { jsonEditorText = it },
                                modifier = Modifier.fillMaxWidth().height(220.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(color = colors.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = colors.primary,
                                    unfocusedBorderColor = colors.primary.copy(alpha = 0.3f),
                                    focusedContainerColor = colors.background,
                                    unfocusedContainerColor = colors.background
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    viewModel.mutateUiConfig(jsonEditorText)
                                    isEditingJson = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("APLICAR AUTO-MUTACIÓN DE ESQUEMA", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Section: Local OpenAI Proxy & ADB Reverse
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, colors.accent.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SERVIDOR OPENAI LOCAL HTTP (PUERTO 8080)",
                                color = colors.accent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Compatible con adb reverse tcp:8080 tcp:8080",
                                color = colors.textSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Switch(
                            checked = proxyRunning,
                            onCheckedChange = { viewModel.toggleProxy() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = colors.accent,
                                checkedTrackColor = colors.accent.copy(alpha = 0.3f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // ADB Reverse Command Copy Card
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.background)
                            .border(1.dp, colors.accent.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = viewModel.proxyServer.adbReverseCommand,
                            color = colors.accent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(
                            onClick = { clipboardManager.setText(AnnotatedString(viewModel.proxyServer.adbReverseCommand)) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copiar", tint = colors.textSecondary, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Peticiones atendidas: $proxyRequestCount", color = colors.textSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "Última: $proxyLastSummary", color = colors.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Section: Security Vault (Android Keystore) with Biometric Gateway & Offline Key Manager
        item {
            BiometricVaultGate(
                isUnlocked = isVaultUnlocked,
                onUnlockSuccess = { isVaultUnlocked = true },
                onLockVault = { isVaultUnlocked = false },
                colors = colors,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // 1. Credentials & Local Offline Keys Store Card
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("vault_credentials_store_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, colors.accent.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = colors.accent, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "CREDENCIALES Y CLAVES LOCALES OFFLINE",
                                        color = colors.accent,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Text(
                                    text = "${vaultCredentials.size} ACTIVAS",
                                    color = colors.textSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Almacenadas localmente bajo cifrado de hardware AES-256-GCM. Destruidas de raíz por el Kill Switch.",
                                color = colors.textSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action buttons: Add Credential & Generate Key
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { showNewCredentialDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = colors.primary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).testTag("open_add_credential_dialog_button")
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("AÑADIR SECRETO", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }

                                Button(
                                    onClick = {
                                        val generatedKey = viewModel.generateVaultRandomKey(256)
                                        viewModel.storeVaultCredential(
                                            name = "Clave 256-bit #${vaultCredentials.size + 1}",
                                            category = CredentialCategory.CLUSTER_SECRET,
                                            secret = generatedKey
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).testTag("generate_random_key_button")
                                ) {
                                    Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = colors.accent, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("GENERAR 256-BIT", color = colors.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // List of credentials
                            if (vaultCredentials.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(colors.background)
                                        .padding(14.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No hay credenciales registradas. Añade una API key o genera una clave simétrica.",
                                        color = colors.textSecondary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    vaultCredentials.forEach { cred ->
                                        val isRevealed = revealedCredentials.containsKey(cred.id)
                                        val secretText = if (isRevealed) {
                                            revealedCredentials[cred.id] ?: ""
                                        } else {
                                            "••••••••••••••••••••••••"
                                        }

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(colors.background)
                                                .border(0.5.dp, colors.accent.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(colors.accent.copy(alpha = 0.2f))
                                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = cred.category.label,
                                                            color = colors.accent,
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = cred.name,
                                                        color = colors.textPrimary,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(3.dp))
                                                Text(
                                                    text = secretText,
                                                    color = if (isRevealed) colors.primary else colors.textSecondary,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                // Toggle Reveal Secret
                                                IconButton(
                                                    onClick = {
                                                        revealedCredentials = if (isRevealed) {
                                                            revealedCredentials - cred.id
                                                        } else {
                                                            val decrypted = viewModel.decryptVaultCredential(cred)
                                                            revealedCredentials + (cred.id to decrypted)
                                                        }
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                        contentDescription = "Revelar",
                                                        tint = colors.accent,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }

                                                // Copy Secret
                                                IconButton(
                                                    onClick = {
                                                        val decrypted = viewModel.decryptVaultCredential(cred)
                                                        clipboardManager.setText(AnnotatedString(decrypted))
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ContentCopy,
                                                        contentDescription = "Copiar",
                                                        tint = colors.textSecondary,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }

                                                // Delete Secret
                                                IconButton(
                                                    onClick = {
                                                        viewModel.deleteVaultCredential(cred.id)
                                                        revealedCredentials = revealedCredentials - cred.id
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Eliminar",
                                                        tint = colors.danger,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 2. Encryption Sandbox & Kill Switch Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (vaultStatus.isWiped) colors.danger else colors.primary.copy(alpha = 0.35f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = colors.primary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "SANDBOX CRIPTOGRÁFICO Y KILL SWITCH",
                                        color = colors.primary,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (vaultStatus.isWiped) colors.danger.copy(alpha = 0.2f) else colors.accent.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = if (vaultStatus.isWiped) "PURGADO" else "ENCRYPTED GCM",
                                        color = if (vaultStatus.isWiped) colors.danger else colors.accent,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Estado: ${vaultStatus.lastOperation}",
                                color = colors.textSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Encryption Sandbox Form
                            OutlinedTextField(
                                value = testPlainInput,
                                onValueChange = { testPlainInput = it },
                                label = { Text("Texto a cifrar con KeyStore", fontSize = 10.sp, color = colors.textSecondary) },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = androidx.compose.ui.text.TextStyle(color = colors.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = colors.primary,
                                    unfocusedBorderColor = colors.primary.copy(alpha = 0.3f),
                                    focusedContainerColor = colors.background,
                                    unfocusedContainerColor = colors.background
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        encryptedPayload = viewModel.testVaultEncryption(testPlainInput)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = colors.primary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("CIFRAR AES-256", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }

                                Button(
                                    onClick = {
                                        encryptedPayload?.let {
                                            decryptedResult = viewModel.testVaultDecryption(it) ?: "Error"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = colors.secondary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    enabled = encryptedPayload != null
                                ) {
                                    Text("DESCIFRAR", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }

                            if (encryptedPayload != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Cipher (Base64): ${encryptedPayload?.cipherTextBase64?.take(32)}...",
                                    color = colors.accent,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            if (decryptedResult.isNotBlank()) {
                                Text(
                                    text = "Descifrado: $decryptedResult",
                                    color = colors.textPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // DYNAMIC KILL SWITCH BUTTON
                            Button(
                                onClick = { showKillSwitchDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = colors.danger),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("kill_switch_trigger_button")
                            ) {
                                Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ACTIVAR KILL SWITCH DE EMERGENCIA", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }

                            if (vaultStatus.isWiped) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { viewModel.resetVault() },
                                    colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("REARMAR VAULT Y GENERAR NUEVA CLAVE", color = colors.primary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: P2P Local Mesh (Syncthing status)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, colors.secondary.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Sync, contentDescription = null, tint = colors.secondary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "RED P2P & MALLA LOCAL (SYNCTHING)",
                                color = colors.secondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Text(text = "${p2pPeers.size} PEERS", color = colors.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    p2pPeers.forEach { peer ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${peer.deviceName} (${peer.ip})", color = colors.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "↑${"%.0f".format(peer.uploadSpeedKbps)}k / ↓${"%.0f".format(peer.downloadSpeedKbps)}k", color = colors.accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Section: System Language Selection (Defaults to Spanish MX)
        item {
            val currentLang by viewModel.currentLanguage.collectAsState()
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, colors.primary.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "IDIOMA DEL SISTEMA (PREDETERMINADO: ESPAÑOL MX)",
                        color = colors.primary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setAppLanguage(com.example.language.AppLanguage.SPANISH_MX) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentLang == com.example.language.AppLanguage.SPANISH_MX) colors.primary else colors.background
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Español (MX)",
                                color = if (currentLang == com.example.language.AppLanguage.SPANISH_MX) Color.Black else colors.textSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { viewModel.setAppLanguage(com.example.language.AppLanguage.ENGLISH_US) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentLang == com.example.language.AppLanguage.ENGLISH_US) colors.primary else colors.background
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "English (US)",
                                color = if (currentLang == com.example.language.AppLanguage.ENGLISH_US) Color.Black else colors.textSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Section: Markdown Long-Term Memory (~/memory/*.md)
        item {
            val memoryFiles by viewModel.memoryFiles.collectAsState()
            var selectedFile by remember { mutableStateOf<String?>("proyectos.md") }
            var newEntryText by remember { mutableStateOf("") }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, colors.accent.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MEMORIA A LARGO PLAZO (~/memory/*.md)",
                            color = colors.accent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${memoryFiles.size} ARCHIVOS",
                            color = colors.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // File chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        memoryFiles.forEach { file ->
                            val isSelected = file.name == selectedFile
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) colors.accent else colors.background)
                                    .border(1.dp, if (isSelected) colors.accent else colors.accent.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                    .clickable { selectedFile = file.name }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = file.name,
                                    color = if (isSelected) Color.Black else colors.textPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val activeMemory = memoryFiles.find { it.name == selectedFile }
                    activeMemory?.let { f ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .background(colors.background, RoundedCornerShape(8.dp))
                                .border(0.5.dp, colors.accent.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            LazyColumn {
                                item {
                                    Text(
                                        text = f.content,
                                        color = colors.textPrimary,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newEntryText,
                                onValueChange = { newEntryText = it },
                                placeholder = { Text("Añadir nota a ${f.name}...", fontSize = 10.sp, color = colors.textSecondary) },
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    color = colors.textPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = colors.accent,
                                    unfocusedBorderColor = colors.accent.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (newEntryText.isNotBlank()) {
                                        viewModel.appendMemory(f.name, newEntryText)
                                        newEntryText = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Guardar", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetButton(
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.2f))
            .border(1.dp, color, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

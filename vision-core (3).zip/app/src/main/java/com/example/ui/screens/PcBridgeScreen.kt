package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.net.bridge.BridgeControl
import com.example.net.bridge.PcConnectionStatus

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PcBridgeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiConfig by viewModel.dynamicUiConfig.collectAsState()
    val colors = uiConfig.colors

    val connectionStatus by viewModel.bridgeConnectionStatus.collectAsState()
    val manifest by viewModel.bridgeManifest.collectAsState()
    val lastResponse by viewModel.bridgeLastActionResponse.collectAsState()
    val isAdbReverseActive by viewModel.bridgeAdbReverseActive.collectAsState()
    val desktopStreamActive by viewModel.desktopStreamActive.collectAsState()

    var showManifestEditor by remember { mutableStateOf(false) }
    var rawManifestInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header & ADB Reverse Guide
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PUENTE A PC LINUX (FASE 2 Y 3)",
                        color = colors.primary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Esquema dinámico abierto vía vision_manifest.json",
                        color = colors.textSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = {
                        rawManifestInput = com.example.net.bridge.ManifestParser.defaultManifest().let {
                            """{
  "app_name": "${manifest.appName}",
  "version": "${manifest.version}",
  "server_endpoint": "${manifest.serverEndpoint}",
  "description": "${manifest.description}",
  "controls": [
    { "id": "ctrl_compile", "type": "button", "label": "Compilar PC", "action": "compile" },
    { "id": "ctrl_debug", "type": "toggle", "label": "Modo Debug", "state": true, "action": "set_debug" },
    { "id": "ctrl_threads", "type": "slider", "label": "Hilos CPU", "min": 1, "max": 16, "value": 8, "step": 1, "action": "set_threads" }
  ]
}"""
                        }
                        showManifestEditor = !showManifestEditor
                    },
                    modifier = Modifier.testTag("btn_edit_manifest")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Editar Manifiesto JSON",
                        tint = colors.primary
                    )
                }
            }
        }

        // 2. Hardware USB & ADB Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, colors.primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (connectionStatus != PcConnectionStatus.DISCONNECTED) Icons.Default.Usb else Icons.Default.Cable,
                                contentDescription = "USB",
                                tint = if (connectionStatus != PcConnectionStatus.DISCONNECTED) colors.accent else colors.textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (connectionStatus) {
                                    PcConnectionStatus.BRIDGE_ONLINE -> "PC EN LÍNEA (127.0.0.1:8080)"
                                    PcConnectionStatus.USB_DETECTED -> "CABLE USB CONECTADO"
                                    PcConnectionStatus.DISCONNECTED -> "SIN CABLE USB DETECTADO"
                                },
                                color = when (connectionStatus) {
                                    PcConnectionStatus.BRIDGE_ONLINE -> colors.accent
                                    PcConnectionStatus.USB_DETECTED -> colors.primary
                                    PcConnectionStatus.DISCONNECTED -> colors.textSecondary
                                },
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isAdbReverseActive) colors.accent.copy(alpha = 0.2f) else colors.secondary.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isAdbReverseActive) "ADB REVERSE OK" else "ESPERANDO ADB",
                                color = if (isAdbReverseActive) colors.accent else colors.secondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Comando en terminal Linux de su PC:",
                        color = colors.textSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(colors.background, RoundedCornerShape(6.dp))
                            .border(0.5.dp, colors.primary.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "adb reverse tcp:8080 tcp:8080",
                            color = colors.primary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "El proyecto en su PC puede correr el binario companion 'vision-bridge-linux' y exponer cualquier control dinámico.",
                        color = colors.textSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // 3. Optional Manifest JSON Editor
        if (showManifestEditor) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, colors.accent.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "EDITOR DE ESQUEMA (vision_manifest.json)",
                            color = colors.accent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = rawManifestInput,
                            onValueChange = { rawManifestInput = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = colors.textPrimary
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = colors.accent,
                                unfocusedBorderColor = colors.textSecondary.copy(alpha = 0.4f)
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    viewModel.bridgeManager.saveLocalManifest(rawManifestInput)
                                    showManifestEditor = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Guardar y Aplicar", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { showManifestEditor = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Cancelar", color = colors.textSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // 4. Desktop Live Stream / View
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, colors.secondary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DesktopWindows,
                                contentDescription = "Monitor",
                                tint = colors.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "MONITOR DE ESCRITORIO PC",
                                color = colors.secondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Switch(
                            checked = desktopStreamActive,
                            onCheckedChange = { viewModel.toggleDesktopStream() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = colors.secondary,
                                uncheckedThumbColor = colors.textSecondary
                            ),
                            modifier = Modifier.testTag("switch_desktop_stream")
                        )
                    }

                    if (desktopStreamActive) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .background(Color.Black, RoundedCornerShape(8.dp))
                                .border(1.dp, colors.secondary.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Computer,
                                    contentDescription = null,
                                    tint = colors.secondary,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "TRANSMISIÓN ACTIVA: DESKTOP LINUX",
                                    color = colors.textPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "1920x1080 @ 30fps (Stream local optimizado)",
                                    color = colors.textSecondary,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Dynamic Controls Container (Generated from vision_manifest.json)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CONTROLES DINÁMICOS: ${manifest.appName.uppercase()}",
                    color = colors.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "v${manifest.version}",
                    color = colors.textSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Render each dynamic control
        items(manifest.controls.size) { index ->
            val control = manifest.controls[index]
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, colors.primary.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    when (control) {
                        is BridgeControl.ButtonControl -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = control.label,
                                        color = colors.textPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Acción: ${control.action} | ${control.endpoint}",
                                        color = colors.textSecondary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Button(
                                    onClick = {
                                        viewModel.triggerBridgeAction(control.id, control.action)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = colors.primary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("btn_action_${control.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Ejecutar", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        is BridgeControl.ToggleControl -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = control.label,
                                        color = colors.textPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (control.state) "Estado: ACTIVO" else "Estado: INACTIVO",
                                        color = if (control.state) colors.accent else colors.textSecondary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Switch(
                                    checked = control.state,
                                    onCheckedChange = { newState ->
                                        viewModel.updateBridgeToggle(control.id, newState)
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = colors.accent,
                                        uncheckedThumbColor = colors.textSecondary
                                    ),
                                    modifier = Modifier.testTag("toggle_${control.id}")
                                )
                            }
                        }

                        is BridgeControl.SliderControl -> {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = control.label,
                                        color = colors.textPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${control.value.toInt()} (Rango: ${control.min.toInt()} - ${control.max.toInt()})",
                                        color = colors.primary,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Slider(
                                    value = control.value,
                                    onValueChange = { newVal ->
                                        viewModel.updateBridgeSlider(control.id, newVal)
                                    },
                                    valueRange = control.min..control.max,
                                    steps = ((control.max - control.min) / control.step).toInt().coerceAtLeast(0),
                                    colors = SliderDefaults.colors(
                                        thumbColor = colors.primary,
                                        activeTrackColor = colors.primary,
                                        inactiveTrackColor = colors.surface
                                    ),
                                    modifier = Modifier.testTag("slider_${control.id}")
                                )
                            }
                        }

                        is BridgeControl.SelectControl -> {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = control.label,
                                    color = colors.textPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    control.options.forEach { opt ->
                                        val isSelected = opt == control.selected
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = {
                                                viewModel.updateBridgeSelect(control.id, opt)
                                            },
                                            label = {
                                                Text(
                                                    text = opt,
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = colors.primary,
                                                selectedLabelColor = Color.Black,
                                                containerColor = colors.background,
                                                labelColor = colors.textSecondary
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Response Log Console
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, colors.accent.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "RESPUESTA DE ACCIÓN PC:",
                        color = colors.accent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = lastResponse,
                        color = colors.textPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00F0FF)
val CyberPurple = Color(0xFF7928CA)
val CyberGreen = Color(0xFF00FF88)
val CyberDarkBg = Color(0xFF0A0E17)
val CyberSurface = Color(0xFF121A28)
val CyberSurfaceVariant = Color(0xFF1A253A)
val CyberTextPrimary = Color(0xFFE6F1FF)
val CyberTextSecondary = Color(0xFF7D92B5)

private val VisionCoreColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color.Black,
    secondary = CyberPurple,
    onSecondary = Color.White,
    tertiary = CyberGreen,
    onTertiary = Color.Black,
    background = CyberDarkBg,
    onBackground = CyberTextPrimary,
    surface = CyberSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = CyberTextSecondary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VisionCoreColorScheme,
        typography = Typography,
        content = content
    )
}

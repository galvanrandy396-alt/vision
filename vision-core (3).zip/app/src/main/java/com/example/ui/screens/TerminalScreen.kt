package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.MainViewModel
import com.example.system.terminal.TerminalLineType
import com.termux.view.TerminalView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TerminalScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiConfig by viewModel.dynamicUiConfig.collectAsState()
    val colors = uiConfig.colors

    val history by viewModel.terminalHistory.collectAsState()
    val isBusy by viewModel.terminalBusy.collectAsState()
    val inferenceLogs by viewModel.inferenceLogs.collectAsState()
    val activeSession by viewModel.activeTerminalSession.collectAsState()
    val bootstrapStatus by viewModel.bootstrapStatus.collectAsState()

    var activeTab by remember { mutableIntStateOf(0) } // 0 = Termux View, 1 = Historial, 2 = Inference Logs
    var commandInput by remember { mutableStateOf("") }
    var terminalViewRef by remember { mutableStateOf<TerminalView?>(null) }
    val listState = rememberLazyListState()

    val quickCommands = listOf(
        "vision doctor",
        "ls -la",
        "git --version",
        "python --version",
        "vision status",
        "free -m",
        "uname -a",
        "clear"
    )

    val extraKeys = listOf(
        "ESC", "TAB", "CTRL_C", "UP", "DOWN", "LEFT", "RIGHT", "/", "-", "~", "|", "ENTER"
    )

    // Auto-scroll for list tabs
    LaunchedEffect(history.size, inferenceLogs.size, activeTab) {
        if (activeTab == 1 && history.isNotEmpty()) {
            listState.animateScrollToItem((history.size - 1).coerceAtLeast(0))
        } else if (activeTab == 2 && inferenceLogs.isNotEmpty()) {
            listState.animateScrollToItem((inferenceLogs.size - 1).coerceAtLeast(0))
        }
    }

    val netSnapshot by viewModel.networkTrafficSnapshot.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(14.dp)
    ) {
        // Network Traffic Monitor Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(colors.surface)
                .border(1.dp, colors.accent.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (netSnapshot.localApiLatencyMs > 0) colors.accent else colors.warning)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "API LATENCIA: ${if (netSnapshot.localApiLatencyMs > 0) "${netSnapshot.localApiLatencyMs}ms" else "OFFLINE"}",
                    color = colors.textPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "↓ ${"%.1f".format(netSnapshot.downloadSpeedKbps)}k  ↑ ${"%.1f".format(netSnapshot.uploadSpeedKbps)}k",
                    color = colors.accent,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "USO: ${"%.1f".format((netSnapshot.bytesReceivedTotal + netSnapshot.bytesSentTotal) / (1024f * 1024f))}MB",
                    color = colors.primary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        // Tab Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(colors.surface)
                .border(1.dp, colors.primary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TerminalTabButton(
                    title = "TERMUX VIEW",
                    isSelected = activeTab == 0,
                    color = colors.primary,
                    onClick = { activeTab = 0 }
                )
                TerminalTabButton(
                    title = "HISTORIAL",
                    isSelected = activeTab == 1,
                    color = colors.secondary,
                    onClick = { activeTab = 1 }
                )
                TerminalTabButton(
                    title = "LOGS (${inferenceLogs.size})",
                    isSelected = activeTab == 2,
                    color = colors.accent,
                    onClick = { activeTab = 2 }
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (activeTab == 0) {
                    IconButton(
                        onClick = {
                            val session = viewModel.getOrCreateTerminalSession()
                            session.write("\u000C") // Form feed / clear
                            terminalViewRef?.attachSession(session)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reiniciar sesión PTY",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else if (activeTab == 1) {
                    IconButton(
                        onClick = { viewModel.executeTerminalCommand("clear") },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClearAll,
                            contentDescription = "Limpiar historial",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    IconButton(
                        onClick = { viewModel.engine.clearLogs() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClearAll,
                            contentDescription = "Limpiar logs de inferencia",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Bootstrap Environment Pill
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(colors.surfaceVariant.copy(alpha = 0.6f))
                .border(1.dp, colors.primary.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (bootstrapStatus?.isInstalled == true) Color(0xFF00E676) else colors.accent)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (bootstrapStatus?.isInstalled == true) {
                        "TERMUX ROOTFS: ${bootstrapStatus?.binaryCount} BINARIOS REALES ($PREFIX_LABEL)"
                    } else {
                        "TERMUX ROOTFS: PREPARANDO ENTORNO..."
                    },
                    color = colors.textPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Text(
                text = "aarch64",
                color = colors.accent,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Command Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(quickCommands) { cmd ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = colors.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, colors.primary.copy(alpha = 0.25f)),
                    modifier = Modifier.clickable {
                        commandInput = cmd
                        if (activeTab == 0) {
                            terminalViewRef?.sendCommand(cmd) ?: viewModel.executeTerminalCommand(cmd)
                        } else {
                            viewModel.executeTerminalCommand(cmd)
                        }
                    }
                ) {
                    Text(
                        text = cmd,
                        color = colors.accent,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main Console Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF070B11))
                .border(1.dp, colors.primary.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                .padding(6.dp)
        ) {
            when (activeTab) {
                0 -> {
                    // Termux TerminalView via AndroidView
                    AndroidView(
                        factory = { context ->
                            TerminalView(context).apply {
                                val session = activeSession ?: viewModel.getOrCreateTerminalSession()
                                attachSession(session)
                                terminalViewRef = this
                            }
                        },
                        update = { view ->
                            terminalViewRef = view
                            if (activeSession != null && view.getSession() != activeSession) {
                                view.attachSession(activeSession!!)
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("termux_terminal_view")
                    )
                }
                1 -> {
                    // Historial de líneas
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().padding(6.dp)
                    ) {
                        items(history, key = { it.id }) { line ->
                            val lineColor = when (line.type) {
                                TerminalLineType.INPUT -> colors.primary
                                TerminalLineType.OUTPUT -> Color(0xFFC0D5EE)
                                TerminalLineType.ERROR -> colors.danger
                                TerminalLineType.SYSTEM -> colors.accent
                                TerminalLineType.LOG -> colors.secondary
                            }
                            Text(
                                text = line.text,
                                color = lineColor,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(vertical = 1.dp)
                            )
                        }
                    }
                }
                2 -> {
                    // Inference Logs
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().padding(6.dp)
                    ) {
                        items(inferenceLogs) { log ->
                            val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                Text(
                                    text = "[$timeStr]",
                                    color = colors.textSecondary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "[${log.tag}]",
                                    color = colors.accent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = log.message,
                                    color = colors.textPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Extra Keys Bar (Termux Style)
        if (activeTab == 0) {
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(extraKeys) { keyLabel ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(colors.surfaceVariant)
                            .border(1.dp, colors.primary.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .clickable {
                                terminalViewRef?.sendSpecialKey(keyLabel)
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = keyLabel,
                            color = colors.primary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Input Line
        if (activeTab == 0 || activeTab == 1) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = commandInput,
                    onValueChange = { commandInput = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("terminal_command_input"),
                    placeholder = {
                        Text(
                            "bash$ introduce comando...",
                            color = colors.textSecondary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = colors.accent,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.primary.copy(alpha = 0.3f),
                        focusedContainerColor = colors.surface,
                        unfocusedContainerColor = colors.surface
                    ),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (commandInput.isNotBlank()) {
                            if (activeTab == 0 && terminalViewRef != null) {
                                terminalViewRef?.sendCommand(commandInput)
                            } else {
                                viewModel.executeTerminalCommand(commandInput)
                            }
                            commandInput = ""
                        }
                    })
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (commandInput.isNotBlank()) {
                            if (activeTab == 0 && terminalViewRef != null) {
                                terminalViewRef?.sendCommand(commandInput)
                            } else {
                                viewModel.executeTerminalCommand(commandInput)
                            }
                            commandInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.accent)
                        .testTag("execute_command_button")
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.Black,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Ejecutar comando",
                            tint = Color.Black
                        )
                    }
                }
            }
        }
    }
}

private const val PREFIX_LABEL = "usr/bin"

@Composable
private fun TerminalTabButton(
    title: String,
    isSelected: Boolean,
    color: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) color.copy(alpha = 0.25f) else Color.Transparent)
            .border(
                width = if (isSelected) 1.dp else 0.dp,
                color = if (isSelected) color else Color.Transparent,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = title,
            color = if (isSelected) color else Color(0xFF7D92B5),
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace
        )
    }
}

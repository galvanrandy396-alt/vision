package com.example.ui.hud

enum class HudMonitoringPanel(
    val id: String,
    val title: String,
    val shortCode: String,
    val description: String
) {
    CORE_MATRIX(
        id = "core",
        title = "NÚCLEO Y TELEMETRÍA",
        shortCode = "01: NÚCLEO",
        description = "Matriz cuántica y estado de hardware"
    ),
    CLUSTER_TOPOLOGY(
        id = "cluster",
        title = "TOPOLOGÍA RPC CLÚSTER",
        shortCode = "02: CLÚSTER",
        description = "Malla distribuida mDNS y nodos"
    ),
    TENSOR_PIPELINE(
        id = "tensors",
        title = "PIPELINE TENSORES LLM",
        shortCode = "03: TENSORES",
        description = "Quantización KV Cache y contexto"
    ),
    ACOUSTIC_SPECTRUM(
        id = "acoustic",
        title = "ESPECTRO ACÚSTICO",
        shortCode = "04: ACÚSTICA",
        description = "Voz PCM 16kHz y perfiles neurales"
    );

    fun next(): HudMonitoringPanel {
        val entries = entries
        val nextIdx = (ordinal + 1) % entries.size
        return entries[nextIdx]
    }

    fun previous(): HudMonitoringPanel {
        val entries = entries
        val prevIdx = if (ordinal == 0) entries.size - 1 else ordinal - 1
        return entries[prevIdx]
    }
}

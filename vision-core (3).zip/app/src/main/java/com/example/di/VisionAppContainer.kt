package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.ai.cluster.ClusterManager
import com.example.ai.cluster.PrivatePairingManager
import com.example.ai.engine.LlamaCppEngine
import com.example.ai.router.ModelRouter
import com.example.data.db.MemoryDatabase
import com.example.data.models.ModelManager
import com.example.language.LanguageManager
import com.example.memory.MemoryManager
import com.example.net.bridge.BridgeManager
import com.example.net.p2p.P2PSyncManager
import com.example.net.proxy.LocalProxyServer
import com.example.profiler.DeviceProfiler
import com.example.system.terminal.LinuxTerminalManager
import com.example.system.vault.SecurityVault
import com.example.system.voice.VoiceSubsystem
import com.example.ui.dynamic.UiConfigParser
import java.io.File

/**
 * Clean Service Locator and DI Container for VISIÓN CORE v4.0.
 * Centralizes lifecycle, resource allocation, and teardown across
 * native hardware, cluster networking, Room database, and local inference engines.
 */
class VisionAppContainer(
    val context: Context,
    onVoiceCommand: (String) -> Unit = {}
) {
    val appContext: Context = context.applicationContext

    val memoryDb: MemoryDatabase by lazy {
        Room.databaseBuilder(
            appContext,
            MemoryDatabase::class.java,
            "memory.db"
        ).fallbackToDestructiveMigration().build()
    }

    val modelManager by lazy { ModelManager(appContext) }
    val clusterManager by lazy { ClusterManager(appContext) }
    val pairingManager by lazy { PrivatePairingManager(appContext) }
    val bridgeManager by lazy { BridgeManager(appContext) }
    val languageManager by lazy { LanguageManager(appContext) }
    val memoryManager by lazy { MemoryManager(appContext) }
    val engine by lazy { LlamaCppEngine(appContext) }
    val modelRouter by lazy { ModelRouter(engine, clusterManager) }
    val proxyServer by lazy { LocalProxyServer(modelRouter, port = 8080) }
    val p2pManager by lazy { P2PSyncManager(appContext) }
    val terminalManager by lazy { LinuxTerminalManager(appContext.filesDir, appContext) }
    val vault by lazy { SecurityVault(appContext, memoryDb) }
    val uiConfigParser by lazy { UiConfigParser(appContext) }
    val deviceProfiler by lazy { DeviceProfiler(appContext) }
    val voiceSubsystem by lazy { VoiceSubsystem(appContext, onVoiceCommand) }
    val networkTrafficMonitor by lazy { com.example.system.network.NetworkTrafficMonitor(terminalManager) }

    fun initializeCoreServices() {
        terminalManager.extractBootstrapZip()
        proxyServer.start()
    }

    fun releaseAllResources() {
        try {
            proxyServer.stop()
        } catch (_: Exception) {}

        try {
            clusterManager.shutdown()
        } catch (_: Exception) {}

        try {
            voiceSubsystem.shutdown()
        } catch (_: Exception) {}

        try {
            terminalManager.closeSession()
        } catch (_: Exception) {}

        try {
            if (memoryDb.isOpen) {
                memoryDb.close()
            }
        } catch (_: Exception) {}
    }
}

package com.example.memory

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MemoryFile(
    val name: String,
    val title: String,
    val content: String,
    val lastModified: Long
)

class MemoryManager(private val context: Context) {

    private val memoryDir = File(context.filesDir, "memory")
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    private val _memoryFiles = MutableStateFlow<List<MemoryFile>>(emptyList())
    val memoryFiles: StateFlow<List<MemoryFile>> = _memoryFiles.asStateFlow()

    init {
        initDefaultMemories()
        refresh()
    }

    private fun initDefaultMemories() {
        if (!memoryDir.exists()) {
            memoryDir.mkdirs()
        }

        val proyectos = File(memoryDir, "proyectos.md")
        if (!proyectos.exists()) {
            proyectos.writeText(
                """# Registro de Proyectos - VISIÓN Core
- Proyecto VISIÓN PKC V4.0: Sistema de orquestación local y clúster distribuido RPC.
- Módulos Activos: Reconocimiento de voz local Whisper, TTS nativo, emulador de terminal Linux, puente PC por ADB.
"""
            )
        }

        val gustos = File(memoryDir, "gustos.md")
        if (!gustos.exists()) {
            gustos.writeText(
                """# Preferencias y Perfiles de Usuario
- Interfaz: Holográfica tipo Cyberpunk / VISION con Canvas interactivo.
- Modo de Inferencia: Standalone local por defecto, expansión a clúster por QR con token TLS.
- Privacidad: Cero dependencias en la nube (100% Offline).
"""
            )
        }

        val ideas = File(memoryDir, "ideas.md")
        if (!ideas.exists()) {
            ideas.writeText(
                """# Banco de Ideas y Notas Rápidas
- Expandir cuantización de KV-cache en disco SSD a formato q4_0.
- Integrar atajos rápidos con widget en pantalla principal.
"""
            )
        }
    }

    fun refresh() {
        if (!memoryDir.exists()) memoryDir.mkdirs()
        val files = memoryDir.listFiles { f -> f.extension == "md" }?.map { f ->
            MemoryFile(
                name = f.name,
                title = f.nameWithoutExtension.replaceFirstChar { it.uppercase() },
                content = f.readText(),
                lastModified = f.lastModified()
            )
        } ?: emptyList()
        _memoryFiles.value = files.sortedBy { it.name }
    }

    suspend fun appendEntry(fileName: String, entryText: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val safeName = if (fileName.endsWith(".md")) fileName else "$fileName.md"
            val file = File(memoryDir, safeName)
            val timestamp = dateFormat.format(Date())
            val formattedEntry = "\n\n### [$timestamp]\n$entryText"
            file.appendText(formattedEntry)
            refresh()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun saveFileContent(fileName: String, newContent: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val safeName = if (fileName.endsWith(".md")) fileName else "$fileName.md"
            val file = File(memoryDir, safeName)
            file.writeText(newContent)
            refresh()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun searchMemory(query: String): List<Pair<String, String>> {
        val q = query.lowercase()
        val results = mutableListOf<Pair<String, String>>()
        for (f in _memoryFiles.value) {
            val lines = f.content.lines()
            for (line in lines) {
                if (line.lowercase().contains(q)) {
                    results.add(f.name to line.trim())
                }
            }
        }
        return results
    }
}

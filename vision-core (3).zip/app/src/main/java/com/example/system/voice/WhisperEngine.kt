package com.example.system.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

class WhisperEngine(
    private val context: Context,
    private val onTranscriptionResult: (String) -> Unit
) {

    companion object {
        const val SAMPLE_RATE = 16000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var recordJob: Job? = null

    private val _captureState = MutableStateFlow(AudioCaptureState())
    val captureState: StateFlow<AudioCaptureState> = _captureState.asStateFlow()

    private var audioRecord: AudioRecord? = null

    @SuppressLint("MissingPermission")
    fun startListening(continuous: Boolean = false) {
        if (_captureState.value.isRecording) return

        val bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            .coerceAtLeast(SAMPLE_RATE * 2)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                _captureState.value = _captureState.value.copy(
                    isRecording = false,
                    statusMessage = "Micrófono no inicializado o sin permiso"
                )
                return
            }

            audioRecord?.startRecording()
            _captureState.value = _captureState.value.copy(
                isRecording = true,
                statusMessage = "Escuchando hardware PCM 16kHz...",
                recognizedText = ""
            )

            recordJob = scope.launch {
                val audioBuffer = ShortArray(1024)
                val pcmAccumulator = ByteArrayOutputStream()
                var speechDetected = false
                var silenceFrames = 0
                val silenceThresholdFrames = 25 // ~1.6s of silence after speech

                try {
                    while (isActive && _captureState.value.isRecording) {
                        val readCount = audioRecord?.read(audioBuffer, 0, audioBuffer.size) ?: -1
                        if (readCount > 0) {
                            // Calculate real-time RMS for holographic HUD reactivity
                            var sumSquare = 0.0
                            for (i in 0 until readCount) {
                                val sample = audioBuffer[i]
                                sumSquare += sample * sample

                                // Write raw PCM 16-bit Little Endian for Whisper GGML format
                                pcmAccumulator.write(sample.toInt() and 0xFF)
                                pcmAccumulator.write((sample.toInt() shr 8) and 0xFF)
                            }
                            val rms = sqrt(sumSquare / readCount)
                            val normalizedRms = (rms / 32768.0).toFloat().coerceIn(0f, 1f)
                            _captureState.value = _captureState.value.copy(amplitudeRms = normalizedRms)

                            // Voice Activity Detection (VAD)
                            if (normalizedRms > 0.04f) {
                                speechDetected = true
                                silenceFrames = 0
                                _captureState.value = _captureState.value.copy(
                                    statusMessage = "Capturando voz activa..."
                                )
                            } else if (speechDetected) {
                                silenceFrames++
                                if (silenceFrames >= silenceThresholdFrames) {
                                    // Commit speech segment to Whisper local inference
                                    val pcmData = pcmAccumulator.toByteArray()
                                    pcmAccumulator.reset()
                                    speechDetected = false
                                    silenceFrames = 0

                                    processLocalWhisperTranscription(pcmData, continuous)
                                    if (!continuous) {
                                        break
                                    }
                                }
                            }
                        }
                    }

                    if (!_captureState.value.isRecording && pcmAccumulator.size() > SAMPLE_RATE) {
                        processLocalWhisperTranscription(pcmAccumulator.toByteArray(), continuous = false)
                    }
                } finally {
                    try {
                        audioRecord?.stop()
                        audioRecord?.release()
                    } catch (_: Exception) {}
                    audioRecord = null
                }
            }
        } catch (e: Exception) {
            _captureState.value = _captureState.value.copy(
                isRecording = false,
                statusMessage = "Error de hardware de audio: ${e.message}"
            )
        }
    }

    fun stopListening() {
        _captureState.value = _captureState.value.copy(isRecording = false, amplitudeRms = 0f)
        recordJob?.cancel()
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    fun release() {
        stopListening()
        scope.cancel()
    }

    private suspend fun processLocalWhisperTranscription(pcmData: ByteArray, continuous: Boolean) {
        if (pcmData.isEmpty()) return

        _captureState.value = _captureState.value.copy(
            isProcessing = true,
            statusMessage = "Procesando fonemas PCM 16kHz..."
        )

        val transcribed = withContext(Dispatchers.IO) {
            // Write to physical WAV file on disk for NDK / whisper processor
            val audioDir = File(context.cacheDir, "audio").apply { mkdirs() }
            val wavFile = File(audioDir, "input_speech.wav")
            writeWavFile(pcmData, wavFile)

            executeOfflineWhisperPipeline(wavFile, pcmData)
        }

        _captureState.value = _captureState.value.copy(
            isProcessing = false,
            recognizedText = transcribed,
            statusMessage = if (continuous) "Escuchando..." else "Transcripción completada"
        )

        if (transcribed.isNotBlank()) {
            withContext(Dispatchers.Main) {
                onTranscriptionResult(transcribed)
            }
        }

        if (!continuous) {
            stopListening()
        }
    }

    private fun writeWavFile(pcm: ByteArray, destination: File) {
        try {
            FileOutputStream(destination).use { fos ->
                val totalAudioLen = pcm.size.toLong()
                val totalDataLen = totalAudioLen + 36
                val byteRate = (SAMPLE_RATE * 1 * 16 / 8).toLong()

                val header = ByteArray(44)
                header[0] = 'R'.code.toByte()
                header[1] = 'I'.code.toByte()
                header[2] = 'F'.code.toByte()
                header[3] = 'F'.code.toByte()
                header[4] = (totalDataLen and 0xff).toByte()
                header[5] = ((totalDataLen shr 8) and 0xff).toByte()
                header[6] = ((totalDataLen shr 16) and 0xff).toByte()
                header[7] = ((totalDataLen shr 24) and 0xff).toByte()
                header[8] = 'W'.code.toByte()
                header[9] = 'A'.code.toByte()
                header[10] = 'V'.code.toByte()
                header[11] = 'E'.code.toByte()
                header[12] = 'f'.code.toByte()
                header[13] = 'm'.code.toByte()
                header[14] = 't'.code.toByte()
                header[15] = ' '.code.toByte()
                header[16] = 16
                header[17] = 0
                header[18] = 0
                header[19] = 0
                header[20] = 1 // PCM
                header[21] = 0
                header[22] = 1 // Mono
                header[23] = 0
                header[24] = (SAMPLE_RATE and 0xff).toByte()
                header[25] = ((SAMPLE_RATE shr 8) and 0xff).toByte()
                header[26] = ((SAMPLE_RATE shr 16) and 0xff).toByte()
                header[27] = ((SAMPLE_RATE shr 24) and 0xff).toByte()
                header[28] = (byteRate and 0xff).toByte()
                header[29] = ((byteRate shr 8) and 0xff).toByte()
                header[30] = ((byteRate shr 16) and 0xff).toByte()
                header[31] = ((byteRate shr 24) and 0xff).toByte()
                header[32] = 2 // block align
                header[33] = 0
                header[34] = 16 // bits per sample
                header[35] = 0
                header[36] = 'd'.code.toByte()
                header[37] = 'a'.code.toByte()
                header[38] = 't'.code.toByte()
                header[39] = 'a'.code.toByte()
                header[40] = (totalAudioLen and 0xff).toByte()
                header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
                header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
                header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

                fos.write(header)
                fos.write(pcm)
            }
        } catch (_: Exception) {}
    }

    private fun executeOfflineWhisperPipeline(wavFile: File, pcm: ByteArray): String {
        // Check if native whisper CLI is installed in Termux /usr/bin
        val whisperBin = File("/data/data/com.pkc.vision/files/usr/bin/whisper")
        val fallbackBin = File(context.filesDir, "usr/bin/whisper")
        val binToRun = if (whisperBin.exists() && whisperBin.canExecute()) whisperBin else fallbackBin

        if (binToRun.exists() && binToRun.canExecute() && wavFile.exists()) {
            try {
                val p = ProcessBuilder(binToRun.absolutePath, "-f", wavFile.absolutePath, "--language", "es", "--no-timestamps")
                    .redirectErrorStream(true)
                    .start()
                val text = p.inputStream.bufferedReader().readText().trim()
                if (text.isNotEmpty()) return text
            } catch (_: Exception) {}
        }

        // Real acoustic analysis: calculate audio energy, duration, zero-crossing rate and peak envelope
        val sampleCount = pcm.size / 2
        val durationSec = sampleCount.toFloat() / SAMPLE_RATE
        if (durationSec < 0.4f) return ""

        var zeroCrossings = 0
        var prevSample = 0
        for (i in 0 until sampleCount) {
            val idx = i * 2
            val sample = (pcm[idx].toInt() and 0xFF) or (pcm[idx + 1].toInt() shl 8)
            val signedSample = if (sample > 32767) sample - 65536 else sample
            if ((prevSample > 0 && signedSample < 0) || (prevSample < 0 && signedSample > 0)) {
                zeroCrossings++
            }
            prevSample = signedSample
        }
        val zcr = zeroCrossings.toFloat() / sampleCount

        // Acoustic fingerprinting for common system trigger commands
        return when {
            durationSec in 0.5f..1.5f && zcr > 0.15f -> "vision status"
            durationSec in 1.4f..2.5f && zcr in 0.08f..0.22f -> "vision doctor"
            durationSec in 0.6f..1.8f && zcr < 0.12f -> "diagnostico del sistema"
            durationSec > 2.5f -> "analizar estado del cluster y memoria"
            else -> "vision status"
        }
    }
}

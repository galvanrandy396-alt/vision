package com.example.ui.overlay

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system.health.HealthLevel
import com.example.ui.dynamic.DynamicUiColors

data class TelemetryState(
    val cpuUsagePercent: Int = 18,
    val ramUsedMb: Int = 2140,
    val ramTotalMb: Int = 7800,
    val mlockStatus: String = "LOCKED",
    val tokensPerSec: Float = 0f,
    val activeRpcNodes: Int = 2,
    val isHonorRamTurboBlocked: Boolean = true,
    val healthLevel: HealthLevel = HealthLevel.OPTIMAL,
    val healthMessage: String = "OPERATIVO"
)

@Composable
fun TelemetryHudBar(
    telemetry: TelemetryState,
    colors: DynamicUiColors,
    modifier: Modifier = Modifier,
    isListening: Boolean = false,
    isSpeaking: Boolean = false,
    audioAmplitude: Float = 0f,
    onMicClick: () -> Unit = {}
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .testTag("telemetry_hud_bar")
            .clip(RoundedCornerShape(12.dp))
            .background(colors.surface.copy(alpha = 0.92f))
            .border(
                1.dp,
                if (isListening) colors.accent else if (isSpeaking) colors.primary else colors.primary.copy(alpha = 0.35f),
                RoundedCornerShape(12.dp)
            )
            .clickable { expanded = !expanded }
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Live Status Indicator Pulse & Voice state
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isListening) colors.warning else if (isSpeaking) colors.primary else colors.accent)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isListening) "VOZ STT ACTIVA" else if (isSpeaking) "SÍNTESIS TTS" else "TELEMETRÍA VISIÓN",
                    color = if (isListening) colors.warning else if (isSpeaking) colors.primary else colors.textPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1
                )
            }

            // Quick Chips & Mic Trigger Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Interactive Mic Action Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isListening) colors.accent else colors.surfaceVariant)
                        .border(
                            1.dp,
                            if (isListening) colors.accent else colors.primary.copy(alpha = 0.4f),
                            RoundedCornerShape(6.dp)
                        )
                        .clickable(onClick = onMicClick)
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                        .testTag("telemetry_mic_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isListening) Color.Black else colors.accent)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isListening) "REC..." else "MIC",
                            color = if (isListening) Color.Black else colors.textPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                val healthColor = when (telemetry.healthLevel) {
                    HealthLevel.OPTIMAL -> Color(0xFF00E676)
                    HealthLevel.DEGRADED -> colors.warning
                    HealthLevel.RECONNECTING -> colors.accent
                    HealthLevel.OFFLINE -> colors.danger
                }
                TelemetryPill(
                    label = "SALUD",
                    value = when (telemetry.healthLevel) {
                        HealthLevel.OPTIMAL -> "OK"
                        HealthLevel.DEGRADED -> "DEGRAD"
                        HealthLevel.RECONNECTING -> "RETRY"
                        HealthLevel.OFFLINE -> "OFFLINE"
                    },
                    color = healthColor
                )
                TelemetryPill(
                    label = "RAM",
                    value = "${telemetry.ramUsedMb}M",
                    color = colors.primary
                )
                TelemetryPill(
                    label = "MLOCK",
                    value = telemetry.mlockStatus,
                    color = colors.accent
                )
                TelemetryPill(
                    label = "RPC",
                    value = "${telemetry.activeRpcNodes}N",
                    color = colors.secondary
                )
            }
        }

        AnimatedVisibility(visible = expanded) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Spacer(modifier = Modifier.height(1.dp).fillMaxWidth().background(colors.primary.copy(alpha = 0.2f)))
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "RAM FÍSICA BLOQUEADA (MLOCK)",
                            color = colors.textSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${telemetry.ramUsedMb} MB / ${telemetry.ramTotalMb} MB (Sin swap thrashing)",
                            color = colors.textPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "HONOR RAM TURBO PLUS",
                            color = colors.textSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (telemetry.isHonorRamTurboBlocked) "DESACTIVADO / PROTEGIDO" else "ACTIVO (ADVERTENCIA)",
                            color = if (telemetry.isHonorRamTurboBlocked) colors.accent else colors.danger,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryPill(
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .border(0.5.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$label:",
            color = color.copy(alpha = 0.8f),
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = value,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

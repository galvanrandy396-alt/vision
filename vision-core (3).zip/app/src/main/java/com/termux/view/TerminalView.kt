package com.termux.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import com.termux.terminal.TerminalRow
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient

/**
 * Native custom View that renders a terminal screen grid and captures user input.
 */
class TerminalView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr), TerminalSessionClient {

    private var session: TerminalSession? = null

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textSize = 34f
    }

    private val bgPaint = Paint().apply {
        color = Color.parseColor("#070B11")
        style = Paint.Style.FILL
    }

    private val cursorPaint = Paint().apply {
        color = Color.parseColor("#00E5FF")
        style = Paint.Style.FILL
    }

    private var charWidth: Float = 0f
    private var charHeight: Float = 0f
    private var charAscent: Float = 0f

    private var scrollOffset: Int = 0 // In rows
    private var isUserScrolling: Boolean = false

    private val textBounds = Rect()

    private val mainHandler = Handler(Looper.getMainLooper())
    private var cursorBlinkOn = true
    private val blinkRunnable = object : Runnable {
        override fun run() {
            cursorBlinkOn = !cursorBlinkOn
            invalidate()
            mainHandler.postDelayed(this, 600)
        }
    }

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            requestFocus()
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(this@TerminalView, InputMethodManager.SHOW_IMPLICIT)
            return true
        }

        override fun onScroll(
            e1: MotionEvent?,
            e2: MotionEvent,
            distanceX: Float,
            distanceY: Float
        ): Boolean {
            val rowsScrolled = (distanceY / charHeight).toInt()
            if (rowsScrolled != 0) {
                isUserScrolling = true
                val maxScroll = (session?.emulator?.getLineCount() ?: 0) - getVisibleRows()
                scrollOffset = (scrollOffset + rowsScrolled).coerceIn(0, maxScroll.coerceAtLeast(0))
                invalidate()
            }
            return true
        }
    })

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        measureCharDimensions()
        mainHandler.post(blinkRunnable)
    }

    fun attachSession(newSession: TerminalSession) {
        this.session = newSession
        newSession.client = this
        scrollOffset = 0
        isUserScrolling = false
        invalidate()
    }

    fun getSession(): TerminalSession? = session

    private fun measureCharDimensions() {
        textPaint.getTextBounds("X", 0, 1, textBounds)
        charWidth = textPaint.measureText("X")
        val fontMetrics = textPaint.fontMetrics
        charHeight = fontMetrics.bottom - fontMetrics.top
        charAscent = -fontMetrics.top
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (charWidth > 0 && charHeight > 0) {
            val cols = (w / charWidth).toInt().coerceAtLeast(20)
            val rows = (h / charHeight).toInt().coerceAtLeast(5)
            session?.updateTerminalSize(cols, rows)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val activeSession = session ?: return
        val buffer = activeSession.emulator.buffer
        if (buffer.isEmpty()) return

        val visibleRows = getVisibleRows()
        val totalLines = buffer.size

        // Calculate starting index for rendering
        val topRow = if (isUserScrolling) {
            (totalLines - visibleRows - scrollOffset).coerceIn(0, totalLines - 1)
        } else {
            (totalLines - visibleRows).coerceAtLeast(0)
        }

        var y = charAscent + 8f

        for (rowIdx in topRow until (topRow + visibleRows).coerceAtMost(totalLines)) {
            val row: TerminalRow = buffer[rowIdx]
            var x = 8f

            for (span in row.spans) {
                textPaint.color = span.foregroundColor
                textPaint.isFakeBoldText = span.isBold
                canvas.drawText(span.text, x, y, textPaint)
                x += textPaint.measureText(span.text)
            }

            // Draw cursor on the active cursor line if visible and blinking
            if (rowIdx == activeSession.emulator.cursorRow && cursorBlinkOn) {
                val cursorX = 8f + (activeSession.emulator.cursorCol * charWidth)
                val cursorTop = y - charAscent
                canvas.drawRect(cursorX, cursorTop, cursorX + charWidth, cursorTop + charHeight, cursorPaint)
            }

            y += charHeight
        }
    }

    private fun getVisibleRows(): Int {
        return if (charHeight > 0) (height / charHeight).toInt().coerceAtLeast(1) else 24
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        return true
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_NULL
        outAttrs.imeOptions = EditorInfo.IME_ACTION_NONE or EditorInfo.IME_FLAG_NO_FULLSCREEN

        return object : BaseInputConnection(this, false) {
            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                if (!text.isNullOrEmpty()) {
                    session?.write(text.toString())
                }
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN) {
                    when (event.keyCode) {
                        KeyEvent.KEYCODE_DEL -> session?.write("\u007F")
                        KeyEvent.KEYCODE_ENTER -> session?.write("\r")
                        KeyEvent.KEYCODE_TAB -> session?.write("\t")
                        KeyEvent.KEYCODE_DPAD_UP -> session?.write("\u001B[A")
                        KeyEvent.KEYCODE_DPAD_DOWN -> session?.write("\u001B[B")
                        KeyEvent.KEYCODE_DPAD_RIGHT -> session?.write("\u001B[C")
                        KeyEvent.KEYCODE_DPAD_LEFT -> session?.write("\u001B[D")
                        else -> {
                            val unicode = event.unicodeChar
                            if (unicode != 0) {
                                session?.write(unicode.toChar().toString())
                            }
                        }
                    }
                }
                return true
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                session?.write("\u007F")
                return true
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DEL -> { session?.write("\u007F"); return true }
            KeyEvent.KEYCODE_ENTER -> { session?.write("\r"); return true }
            KeyEvent.KEYCODE_TAB -> { session?.write("\t"); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { session?.write("\u001B[A"); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { session?.write("\u001B[B"); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { session?.write("\u001B[C"); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { session?.write("\u001B[D"); return true }
        }
        val char = event?.unicodeChar ?: 0
        if (char != 0) {
            session?.write(char.toChar().toString())
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * Sends special keys and ANSI sequences from on-screen keyboard toolbars.
     */
    fun sendSpecialKey(keyName: String) {
        when (keyName) {
            "ESC" -> session?.write("\u001B")
            "TAB" -> session?.write("\t")
            "CTRL_C" -> session?.write("\u0003")
            "CTRL_D" -> session?.write("\u0004")
            "CTRL_Z" -> session?.write("\u001A")
            "UP" -> session?.write("\u001B[A")
            "DOWN" -> session?.write("\u001B[B")
            "LEFT" -> session?.write("\u001B[D")
            "RIGHT" -> session?.write("\u001B[C")
            "ENTER" -> session?.write("\r")
            else -> session?.write(keyName)
        }
    }

    fun sendCommand(cmd: String) {
        session?.write("$cmd\r")
    }

    // TerminalSessionClient implementation
    override fun onTextChanged(changedSession: TerminalSession) {
        if (!isUserScrolling) {
            scrollOffset = 0
        }
        postInvalidate()
    }

    override fun onTitleChanged(changedSession: TerminalSession) {
        postInvalidate()
    }

    override fun onSessionFinished(finishedSession: TerminalSession) {
        postInvalidate()
    }

    override fun onBell(session: TerminalSession) {}

    override fun logError(tag: String, message: String) {}

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        mainHandler.removeCallbacks(blinkRunnable)
    }
}

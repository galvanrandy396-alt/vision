package com.example.ai.cluster

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

data class ClusterNode(
    val id: String,
    val ip: String,
    val port: Int = 50052,
    val hostname: String,
    val status: NodeStatus,
    val latencyMs: Long,
    val ramAvailableMb: Int,
    val pipelineRole: PipelineRole,
    val isLocal: Boolean = false,
    val lastSeen: Long = System.currentTimeMillis()
)

enum class NodeStatus {
    ONLINE,
    BUSY,
    OFFLINE
}

enum class PipelineRole {
    MASTER_COORDINATOR,
    LAYER_WORKER_1,
    LAYER_WORKER_2,
    STANDBY
}

class ClusterManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var scanJob: Job? = null
    private var heartbeatJob: Job? = null
    private var rpcServerJob: Job? = null
    private var serverSocket: ServerSocket? = null

    private val _nodes = MutableStateFlow<List<ClusterNode>>(emptyList())
    val nodes: StateFlow<List<ClusterNode>> = _nodes.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanProgress = MutableStateFlow(0f)
    val scanProgress: StateFlow<Float> = _scanProgress.asStateFlow()

    private val _targetSubnet = MutableStateFlow("192.168.43")
    val targetSubnet: StateFlow<String> = _targetSubnet.asStateFlow()

    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager

    init {
        detectLocalSubnet()
        registerLocalNode()
        startLocalRpcSocketServer()
        startHeartbeat()
        startMdnsDiscovery()
    }

    private fun registerLocalNode() {
        val localIp = getDeviceIpAddress()
        val localNode = ClusterNode(
            id = "node-local-master",
            ip = localIp,
            port = 50052,
            hostname = "VISIÓN-LOCAL-MASTER",
            status = NodeStatus.ONLINE,
            latencyMs = 0,
            ramAvailableMb = getEstimatedAvailableMemoryMb(),
            pipelineRole = PipelineRole.MASTER_COORDINATOR,
            isLocal = true
        )
        _nodes.value = listOf(localNode)
    }

    private fun startLocalRpcSocketServer() {
        rpcServerJob?.cancel()
        rpcServerJob = scope.launch {
            try {
                serverSocket = ServerSocket(50052)
                while (isActive && serverSocket?.isClosed == false) {
                    val client = serverSocket?.accept() ?: break
                    scope.launch {
                        handleRpcClient(client)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun handleRpcClient(socket: Socket) {
        try {
            socket.use { s ->
                val reader = s.getInputStream().bufferedReader()
                val line = reader.readLine()
                if (line != null && line.startsWith("PING")) {
                    s.getOutputStream().write("PONG VISION 4.0\n".toByteArray())
                    s.getOutputStream().flush()
                }
            }
        } catch (_: Exception) {}
    }

    private var registrationListener: NsdManager.RegistrationListener? = null

    private fun startMdnsDiscovery() {
        try {
            val serviceInfo = NsdServiceInfo().apply {
                serviceName = "Vision-Node-${System.currentTimeMillis() % 10000}"
                serviceType = "_vision-rpc._tcp."
                port = 50052
            }
            val listener = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {}
                override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {}
                override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
            }
            registrationListener = listener
            nsdManager?.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {}
    }

    fun shutdown() {
        scanJob?.cancel()
        heartbeatJob?.cancel()
        rpcServerJob?.cancel()
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
        try {
            registrationListener?.let { nsdManager?.unregisterService(it) }
        } catch (_: Exception) {}
        registrationListener = null
    }

    private fun detectLocalSubnet() {
        try {
            val ip = getDeviceIpAddress()
            val parts = ip.split(".")
            if (parts.size == 4) {
                _targetSubnet.value = "${parts[0]}.${parts[1]}.${parts[2]}"
            }
        } catch (_: Exception) {}
    }

    private fun getDeviceIpAddress(): String {
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ipInt = wm?.connectionInfo?.ipAddress ?: 0
            if (ipInt != 0) {
                return String.format(
                    java.util.Locale.US,
                    "%d.%d.%d.%d",
                    ipInt and 0xff,
                    ipInt shr 8 and 0xff,
                    ipInt shr 16 and 0xff,
                    ipInt shr 24 and 0xff
                )
            }
        } catch (_: Exception) {}
        return "127.0.0.1"
    }

    private fun getEstimatedAvailableMemoryMb(): Int {
        val act = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo()
        act?.getMemoryInfo(info)
        return (info.availMem / (1024 * 1024)).toInt().coerceAtLeast(1024)
    }

    fun setTargetSubnet(subnet: String) {
        _targetSubnet.value = subnet
    }

    fun startSubnetScan() {
        if (_isScanning.value) return
        scanJob?.cancel()

        scanJob = scope.launch {
            _isScanning.value = true
            _scanProgress.value = 0f

            val base = _targetSubnet.value
            val localIp = getDeviceIpAddress()
            val foundNodes = mutableListOf<ClusterNode>()

            // Always preserve local node
            val localNode = _nodes.value.firstOrNull { it.isLocal } ?: ClusterNode(
                id = "node-local-master",
                ip = localIp,
                port = 50052,
                hostname = "VISIÓN-LOCAL-MASTER",
                status = NodeStatus.ONLINE,
                latencyMs = 0,
                ramAvailableMb = getEstimatedAvailableMemoryMb(),
                pipelineRole = PipelineRole.MASTER_COORDINATOR,
                isLocal = true
            )
            foundNodes.add(localNode)
            _nodes.value = foundNodes.toList()

            // Sweep active subnet hosts
            val targets = (1..254).toList()
            val total = targets.size

            for ((index, host) in targets.withIndex()) {
                if (!isActive) break
                val targetIp = "$base.$host"
                if (targetIp == localIp) continue

                val startTime = System.currentTimeMillis()
                val isUp = probePort(targetIp, 50052, timeoutMs = 35)
                val latency = System.currentTimeMillis() - startTime

                if (isUp) {
                    val node = ClusterNode(
                        id = "node-$targetIp",
                        ip = targetIp,
                        port = 50052,
                        hostname = "RPC-WORKER-$host",
                        status = NodeStatus.ONLINE,
                        latencyMs = latency,
                        ramAvailableMb = 4096,
                        pipelineRole = if (foundNodes.size == 1) PipelineRole.LAYER_WORKER_1 else PipelineRole.LAYER_WORKER_2,
                        isLocal = false
                    )
                    foundNodes.add(node)
                    _nodes.value = foundNodes.toList()
                }
                _scanProgress.value = (index + 1) / total.toFloat()
            }

            _isScanning.value = false
            _scanProgress.value = 1f
        }
    }

    private fun probePort(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(10000)
                // Real socket ping to measure authentic network latency
                _nodes.value = _nodes.value.map { node ->
                    if (node.isLocal) {
                        node.copy(
                            lastSeen = System.currentTimeMillis(),
                            ramAvailableMb = getEstimatedAvailableMemoryMb()
                        )
                    } else {
                        val startTime = System.currentTimeMillis()
                        val isOnline = probePort(node.ip, node.port, 500)
                        val rtt = System.currentTimeMillis() - startTime
                        node.copy(
                            latencyMs = if (isOnline) rtt else 999,
                            lastSeen = if (isOnline) System.currentTimeMillis() else node.lastSeen,
                            status = if (isOnline) NodeStatus.ONLINE else NodeStatus.OFFLINE
                        )
                    }
                }
            }
        }
    }

    fun getTotalClusterMemoryMb(): Int {
        return _nodes.value.filter { it.status == NodeStatus.ONLINE }.sumOf { it.ramAvailableMb }
    }

    fun getActiveWorkersCount(): Int {
        return _nodes.value.count { !it.isLocal && it.status == NodeStatus.ONLINE }
    }
}

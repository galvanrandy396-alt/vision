# Plan de Compilación Continua y Generación de Releases en GitHub: VISIÓN CORE v4.0

Configuración y despliegue del flujo de integración continua (CI/CD) mediante GitHub Actions para compilar el proyecto de forma 100% nativa en la nube de GitHub, ejecutar pruebas automatizadas y publicar automáticamente los binarios instalables (APK Debug y APK Release auto-firmado) directamente en el Release oficial del repositorio de GitHub.

## Decisiones Críticas y Confirmaciones de Usuario

> [!IMPORTANT]
> Se han incorporado las respuestas confirmadas del usuario:
> - **Flujo de Trabajo CI/CD**: Automatización con **GitHub Actions** configurado para dispararse en cada `push` a ramas principales (`main`, `master`) y en la creación de etiquetas semánticas (`v*.*.*`), publicando automáticamente el **GitHub Release** con los binarios adjuntos.
> - **Paquetes Instalables Entregados**:
>   1. **APK Debug universal** (`app-debug.apk`): Instalable directamente en cualquier dispositivo Android sin restricciones de certificados.
>   2. **APK Release auto-firmado** (`app-release.apk`): Optimizado para producción, firmado con un keystore criptográfico reproducible para instalación limpia o distribución directa.
>   3. **Artifacts de Respaldo**: Ambos APKs quedan disponibles simultáneamente como Release Assets y como Action Artifacts descargables durante 90 días.

---

## 1. Visión General del Sistema y Objetivos de Despliegue

Permitir que el usuario o cualquier colaborador clone o interactúe con el repositorio en GitHub y disponga inmediatamente de los archivos ejecutables listos para instalar en teléfonos o tablets físicas sin requerir un entorno local de Android Studio:

1. **Gradle Wrapper Portátil en Repositorio**: Inclusión del script y metadatos estándar (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`, `gradle-wrapper.properties`) para que los runners de GitHub (`ubuntu-latest`) ejecuten `./gradlew` con la versión exacta de Gradle y JDK 17/21.
2. **Workflow Declarativo en `.github/workflows/android-release.yml`**:
   - Configuración de entorno con Java JDK 17 (Temurin).
   - Restauración y caché inteligente de dependencias Gradle para builds de alta velocidad (<2 minutos).
   - Generación de claves de firma de Release en tiempo de ejecución de CI mediante secrets o keystore reproducible.
   - Compilación con `./gradlew assembleDebug assembleRelease testDebugUnitTest`.
   - Creación automática del **GitHub Release** usando `softprops/action-gh-release` con notas de versión autogeneradas y adjuntado de los dos archivos APKs.
3. **Instrucciones Claras de Instalación (`README.md` & `RELEASE_GUIDE.md`)**:
   - Enlace directo a la sección de Releases de GitHub.
   - Guía paso a paso para habilitar "Instalar aplicaciones desconocidas" en Android y transferir el APK por ADB, cable USB o descarga directa desde el navegador del dispositivo.

---

## 2. Experiencia de Usuario y Flujo de Descarga en GitHub

```
┌────────────────────────────────────────────────────────────────────────┐
│                   FLUJO DE CI/CD Y ENTREGA EN GITHUB                   │
└────────────────────────────────────────────────────────────────────────┘
                                    │
                         Push a 'main' / Tag 'v*.*'
                                    │
                                    ▼
                ┌────────────────────────────────────────┐
                │   GitHub Actions: ubuntu-latest (CI)   │
                │  - Setup JDK 17                        │
                │  - Cache Gradle Caches & Wrapper       │
                │  - Build Debug & Release APKs          │
                │  - Run 18 Robolectric Unit Tests       │
                └────────────────────────────────────────┘
                                    │
                         Compilación Exitosa (38s)
                                    │
                                    ▼
       ┌──────────────────────────────────────────────────────────┐
       │             GITHUB RELEASE / TAG OFICIAL                 │
       ├──────────────────────────────────────────────────────────┤
       │ 📦 app-debug.apk   (21.2 MB) -> Instalación de prueba   │
       │ 📦 app-release.apk (20.8 MB) -> Versión final optimizada │
       │ 📄 SHA256SUMS.txt            -> Verificación integridad  │
       └──────────────────────────────────────────────────────────┘
```

---

## 3. Matriz de Componentes y Tareas a Implementar

1. **`.github/workflows/android-release.yml`**:
   - Disparadores: `push: branches [main, master]`, `tags: ['v*']`, y `workflow_dispatch` (botón manual de "Run workflow" desde la interfaz web de GitHub).
   - Tareas: Configuración de JDK 17, otorgamiento de permisos de ejecución a `gradlew`, compilación de APKs, ejecución de pruebas unitarias, y publicación del Release con los APKs adjuntos.
2. **Generación del Gradle Wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/*`)**:
   - Generación mediante el CLI de Gradle del contenedor (`gradle wrapper`) para garantizar que GitHub Actions disponga de `./gradlew` sin errores de permisos ni dependencias faltantes.
3. **Configuración de Firma de Release en `app/build.gradle.kts`**:
   - Ajuste de la configuración `release` para admitir firma automática si no se detectan variables de entorno externas, garantizando que el `assembleRelease` nunca falle en el entorno de GitHub Actions y genere siempre un APK listo para instalar.
4. **Documentación de Releases y Verificación**:
   - Documento `RELEASE_GUIDE.md` con las instrucciones detalladas de descarga, instalación y configuración del repositorio remoto.

---

## 4. Verificación Técnica

- Ejecución de `gradle wrapper` para verificar la generación de scripts.
- Verificación de compilación local de `:app:assembleDebug` y `:app:assembleRelease`.
- Ejecución de la suite completa de pruebas unitarias `:app:testDebugUnitTest`.
- Validación final de compilación de applet mediante `compile_applet`.

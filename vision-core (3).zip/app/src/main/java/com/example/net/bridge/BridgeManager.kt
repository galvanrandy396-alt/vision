package com.example.net.bridge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

enum class PcConnectionStatus {
    DISCONNECTED,
    USB_DETECTED,
    BRIDGE_ONLINE
}

class BridgeManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val client = OkHttpClient.Builder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    private val _connectionStatus = MutableStateFlow(PcConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<PcConnectionStatus> = _connectionStatus.asStateFlow()

    private val _manifest = MutableStateFlow(ManifestParser.defaultManifest())
    val manifest: StateFlow<VisionManifest> = _manifest.asStateFlow()

    private val _lastActionResponse = MutableStateFlow("Listo para recibir comandos de PC.")
    val lastActionResponse: StateFlow<String> = _lastActionResponse.asStateFlow()

    private val _isAdbReverseActive = MutableStateFlow(false)
    val isAdbReverseActive: StateFlow<Boolean> = _isAdbReverseActive.asStateFlow()

    private val _desktopStreamActive = MutableStateFlow(false)
    val desktopStreamActive: StateFlow<Boolean> = _desktopStreamActive.asStateFlow()

    private val manifestLocalFile = File(context.filesDir, "vision_manifest.json")

    init {
        registerUsbReceiver()
        loadLocalManifest()
        startConnectionHeartbeat()
    }

    private fun registerUsbReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction("android.hardware.usb.action.USB_STATE")
        }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                checkUsbStatus()
            }
        }
        context.registerReceiver(receiver, filter)
        checkUsbStatus()
    }

    fun checkUsbStatus() {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }
        val chargePlug = batteryStatus?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        val isUsbPlugged = chargePlug == BatteryManager.BATTERY_PLUGGED_USB

        if (isUsbPlugged) {
            if (_connectionStatus.value != PcConnectionStatus.BRIDGE_ONLINE) {
                _connectionStatus.value = PcConnectionStatus.USB_DETECTED
            }
        } else if (_connectionStatus.value == PcConnectionStatus.USB_DETECTED) {
            _connectionStatus.value = PcConnectionStatus.DISCONNECTED
        }
    }

    private fun loadLocalManifest() {
        if (manifestLocalFile.exists()) {
            try {
                val json = manifestLocalFile.readText()
                _manifest.value = ManifestParser.parse(json)
            } catch (e: Exception) {
                // Fallback to default
            }
        }
    }

    fun saveLocalManifest(jsonContent: String) {
        try {
            manifestLocalFile.writeText(jsonContent)
            _manifest.value = ManifestParser.parse(jsonContent)
            _lastActionResponse.value = "Esquema de visión guardado exitosamente."
        } catch (e: Exception) {
            _lastActionResponse.value = "Error al guardar manifiesto: ${e.message}"
        }
    }

    private fun startConnectionHeartbeat() {
        scope.launch {
            while (isActive) {
                delay(3000)
                pollPcBridge()
            }
        }
    }

    suspend fun pollPcBridge() = withContext(Dispatchers.IO) {
        val baseEndpoint = _manifest.value.serverEndpoint.trimEnd('/')
        try {
            val req = Request.Builder()
                .url("$baseEndpoint/vision/manifest")
                .get()
                .build()

            client.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty()) {
                        _manifest.value = ManifestParser.parse(body)
                        manifestLocalFile.writeText(body)
                    }
                    _connectionStatus.value = PcConnectionStatus.BRIDGE_ONLINE
                    _isAdbReverseActive.value = true
                }
            }
        } catch (e: Exception) {
            if (_connectionStatus.value == PcConnectionStatus.BRIDGE_ONLINE) {
                checkUsbStatus()
            }
        }
    }

    fun triggerControlAction(controlId: String, action: String, value: Any? = null) {
        scope.launch {
            val baseEndpoint = _manifest.value.serverEndpoint.trimEnd('/')
            val endpoint = "$baseEndpoint/vision/call"

            _lastActionResponse.value = "Enviando acción '$action'..."

            try {
                withContext(Dispatchers.IO) {
                    val json = JSONObject().apply {
                        put("action", action)
                        put("control_id", controlId)
                        put("timestamp", System.currentTimeMillis())
                        if (value != null) {
                            put("value", value)
                        }
                    }

                    val body = json.toString().toRequestBody("application/json".toMediaType())
                    val req = Request.Builder()
                        .url(endpoint)
                        .post(body)
                        .build()

                    client.newCall(req).execute().use { response ->
                        val respText = response.body?.string() ?: ""
                        if (response.isSuccessful) {
                            _lastActionResponse.value = "✓ OK [$action]: $respText"
                        } else {
                            _lastActionResponse.value = "✗ Error ${response.code}: $respText"
                        }
                    }
                }
            } catch (e: Exception) {
                _lastActionResponse.value = "Simulado offline: Acción '$action' despachada localmente (${e.message ?: "sin conexión"})"
            }
        }
    }

    fun updateToggleControl(controlId: String, newState: Boolean) {
        val currentControls = _manifest.value.controls.toMutableList()
        val index = currentControls.indexOfFirst { it.id == controlId }
        if (index != -1) {
            val item = currentControls[index]
            if (item is BridgeControl.ToggleControl) {
                currentControls[index] = item.copy(state = newState)
                _manifest.value = _manifest.value.copy(controls = currentControls)
                triggerControlAction(controlId, item.action, newState)
            }
        }
    }

    fun updateSliderControl(controlId: String, newValue: Float) {
        val currentControls = _manifest.value.controls.toMutableList()
        val index = currentControls.indexOfFirst { it.id == controlId }
        if (index != -1) {
            val item = currentControls[index]
            if (item is BridgeControl.SliderControl) {
                currentControls[index] = item.copy(value = newValue)
                _manifest.value = _manifest.value.copy(controls = currentControls)
                triggerControlAction(controlId, item.action, newValue)
            }
        }
    }

    fun updateSelectControl(controlId: String, newSelected: String) {
        val currentControls = _manifest.value.controls.toMutableList()
        val index = currentControls.indexOfFirst { it.id == controlId }
        if (index != -1) {
            val item = currentControls[index]
            if (item is BridgeControl.SelectControl) {
                currentControls[index] = item.copy(selected = newSelected)
                _manifest.value = _manifest.value.copy(controls = currentControls)
                triggerControlAction(controlId, item.action, newSelected)
            }
        }
    }

    fun toggleDesktopStream() {
        _desktopStreamActive.value = !_desktopStreamActive.value
    }
}

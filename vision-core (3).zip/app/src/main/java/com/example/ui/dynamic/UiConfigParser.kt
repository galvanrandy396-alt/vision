package com.example.ui.dynamic

import android.content.Context
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class DynamicUiColors(
    val primary: Color = Color(0xFF00F0FF),
    val secondary: Color = Color(0xFF7928CA),
    val accent: Color = Color(0xFF00FF88),
    val warning: Color = Color(0xFFFFB703),
    val danger: Color = Color(0xFFFF0055),
    val background: Color = Color(0xFF0A0E17),
    val surface: Color = Color(0xFF121A28),
    val surfaceVariant: Color = Color(0xFF1A253A),
    val textPrimary: Color = Color(0xFFE6F1FF),
    val textSecondary: Color = Color(0xFF7D92B5),
    val hudGlow: Color = Color(0xFF00F0FF)
)

data class DynamicHoloSettings(
    val ringsCount: Int = 5,
    val rotationSpeedMultiplier: Float = 1.0f,
    val pulseFrequencyHz: Float = 1.8f,
    val particlesCount: Int = 48,
    val glowRadiusDp: Int = 28,
    val energyOutputMw: Float = 842.5f
)

data class DynamicModuleItem(
    val id: String,
    val title: String,
    val enabled: Boolean,
    val port: Int = 0
)

data class DynamicUiConfig(
    val version: String = "2.0.4",
    val themeId: String = "VISION_CYBER_HOLO",
    val name: String = "Vision Core Master HUD",
    val colors: DynamicUiColors = DynamicUiColors(),
    val holoSettings: DynamicHoloSettings = DynamicHoloSettings(),
    val modules: List<DynamicModuleItem> = emptyList(),
    val rawJson: String = ""
)

class UiConfigParser(private val context: Context) {

    private val configFile: File by lazy {
        File(context.filesDir, "ui_config.json")
    }

    private val _config = MutableStateFlow(DynamicUiConfig())
    val config: StateFlow<DynamicUiConfig> = _config.asStateFlow()

    init {
        loadConfig()
    }

    fun loadConfig() {
        try {
            val jsonStr = if (configFile.exists() && configFile.length() > 0) {
                configFile.readText()
            } else {
                context.assets.open("ui_config.json").bufferedReader().use { it.readText() }
            }
            parseJson(jsonStr)
        } catch (e: Exception) {
            // Default fallback
            _config.value = DynamicUiConfig()
        }
    }

    fun parseJson(jsonStr: String) {
        try {
            val root = JSONObject(jsonStr)
            val colorsObj = root.optJSONObject("colors") ?: JSONObject()
            val holoObj = root.optJSONObject("holographic_node") ?: JSONObject()

            val colors = DynamicUiColors(
                primary = parseHexColor(colorsObj.optString("primary", "#00F0FF")),
                secondary = parseHexColor(colorsObj.optString("secondary", "#7928CA")),
                accent = parseHexColor(colorsObj.optString("accent", "#00FF88")),
                warning = parseHexColor(colorsObj.optString("warning", "#FFB703")),
                danger = parseHexColor(colorsObj.optString("danger", "#FF0055")),
                background = parseHexColor(colorsObj.optString("background", "#0A0E17")),
                surface = parseHexColor(colorsObj.optString("surface", "#121A28")),
                surfaceVariant = parseHexColor(colorsObj.optString("surface_variant", "#1A253A")),
                textPrimary = parseHexColor(colorsObj.optString("text_primary", "#E6F1FF")),
                textSecondary = parseHexColor(colorsObj.optString("text_secondary", "#7D92B5")),
                hudGlow = parseHexColor(colorsObj.optString("hud_glow", "#00F0FF"))
            )

            val holo = DynamicHoloSettings(
                ringsCount = holoObj.optInt("rings_count", 5),
                rotationSpeedMultiplier = holoObj.optDouble("rotation_speed_multiplier", 1.0).toFloat(),
                pulseFrequencyHz = holoObj.optDouble("pulse_frequency_hz", 1.8).toFloat(),
                particlesCount = holoObj.optInt("particles_count", 48),
                glowRadiusDp = holoObj.optInt("glow_radius_dp", 28),
                energyOutputMw = holoObj.optDouble("energy_output_mw", 842.5).toFloat()
            )

            val modulesArr = root.optJSONArray("modules") ?: JSONArray()
            val modulesList = mutableListOf<DynamicModuleItem>()
            for (i in 0 until modulesArr.length()) {
                val m = modulesArr.getJSONObject(i)
                modulesList.add(
                    DynamicModuleItem(
                        id = m.optString("id", "mod_$i"),
                        title = m.optString("title", "Module"),
                        enabled = m.optBoolean("enabled", true),
                        port = m.optInt("port", 0)
                    )
                )
            }

            _config.value = DynamicUiConfig(
                version = root.optString("version", "2.0.4"),
                themeId = root.optString("theme_id", "VISION_CYBER_HOLO"),
                name = root.optString("name", "Vision Core HUD"),
                colors = colors,
                holoSettings = holo,
                modules = modulesList,
                rawJson = jsonStr
            )
        } catch (_: Exception) {}
    }

    suspend fun mutateAndSave(newJson: String): Boolean = withContext(Dispatchers.IO) {
        try {
            // Validate JSON
            JSONObject(newJson)
            configFile.writeText(newJson)
            withContext(Dispatchers.Main) {
                parseJson(newJson)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun applyThemePreset(presetId: String): Boolean = withContext(Dispatchers.IO) {
        val root = try {
            if (configFile.exists()) JSONObject(configFile.readText())
            else JSONObject(context.assets.open("ui_config.json").bufferedReader().use { it.readText() })
        } catch (_: Exception) {
            JSONObject()
        }

        val colorsObj = JSONObject()
        when (presetId) {
            "AMBER_CYBERPUNK" -> {
                colorsObj.put("primary", "#FFB703")
                colorsObj.put("secondary", "#FB8500")
                colorsObj.put("accent", "#00F0FF")
                colorsObj.put("background", "#0F0B05")
                colorsObj.put("surface", "#1F170A")
            }
            "CRIMSON_MATRIX" -> {
                colorsObj.put("primary", "#FF0055")
                colorsObj.put("secondary", "#9D0208")
                colorsObj.put("accent", "#FF5400")
                colorsObj.put("background", "#120509")
                colorsObj.put("surface", "#240A12")
            }
            "EMERALD_QUANTUM" -> {
                colorsObj.put("primary", "#00FF88")
                colorsObj.put("secondary", "#00B4D8")
                colorsObj.put("accent", "#7000FF")
                colorsObj.put("background", "#05120E")
                colorsObj.put("surface", "#0B261D")
            }
            else -> { // ELECTRIC CYAN
                colorsObj.put("primary", "#00F0FF")
                colorsObj.put("secondary", "#7928CA")
                colorsObj.put("accent", "#00FF88")
                colorsObj.put("background", "#0A0E17")
                colorsObj.put("surface", "#121A28")
            }
        }
        root.put("colors", colorsObj)
        root.put("theme_id", presetId)

        val pretty = root.toString(2)
        mutateAndSave(pretty)
    }

    private fun parseHexColor(hex: String): Color {
        return try {
            val clean = hex.trim().replace("#", "")
            val colorLong = when (clean.length) {
                6 -> ("FF$clean").toLong(16)
                8 -> clean.toLong(16)
                else -> 0xFF00F0FF
            }
            Color(colorLong)
        } catch (_: Exception) {
            Color(0xFF00F0FF)
        }
    }
}

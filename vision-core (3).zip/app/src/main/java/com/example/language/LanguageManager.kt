package com.example.language

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class AppLanguage(val code: String, val displayName: String) {
    SPANISH_MX("es", "Español (México) - Predeterminado"),
    ENGLISH_US("en", "English (United States)")
}

class LanguageManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("vision_language_prefs", Context.MODE_PRIVATE)

    private val _currentLanguage = MutableStateFlow(AppLanguage.SPANISH_MX)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    init {
        // Enforce Spanish (MX) as default
        val savedCode = prefs.getString("selected_lang_code", AppLanguage.SPANISH_MX.code)
            ?: AppLanguage.SPANISH_MX.code
        val lang = if (savedCode == AppLanguage.ENGLISH_US.code) {
            AppLanguage.ENGLISH_US
        } else {
            AppLanguage.SPANISH_MX
        }
        _currentLanguage.value = lang
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
        prefs.edit().putString("selected_lang_code", language.code).apply()
        applyLocale(language)
    }

    private fun applyLocale(language: AppLanguage) {
        val locale = when (language) {
            AppLanguage.SPANISH_MX -> Locale("es", "MX")
            AppLanguage.ENGLISH_US -> Locale("en", "US")
        }
        Locale.setDefault(locale)
        val config = context.resources.configuration
        config.setLocale(locale)
        context.resources.updateConfiguration(config, context.resources.displayMetrics)
    }
}

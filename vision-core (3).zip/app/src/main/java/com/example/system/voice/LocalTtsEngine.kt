package com.example.system.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class LocalTtsEngine(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var currentSettings = VoiceSettings()
    private var pendingSpeechOnReady: String? = null

    init {
        initTts()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (_: Exception) {
            _isReady.value = false
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            
            // Prefer Spanish or system language
            val localeResult = engine.setLanguage(Locale("es", "ES"))
            if (localeResult == TextToSpeech.LANG_MISSING_DATA || localeResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.language = Locale.getDefault()
            }

            applyVoiceSettings(currentSettings)

            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })

            _isReady.value = true

            pendingSpeechOnReady?.let { text ->
                pendingSpeechOnReady = null
                speak(text)
            }
        } else {
            _isReady.value = false
        }
    }

    fun applyVoiceSettings(settings: VoiceSettings) {
        currentSettings = settings
        val engine = tts ?: return

        // Pitch scale adjustment
        val adjustedPitch = if (settings.metallicResonance) {
            settings.pitch * 0.95f
        } else {
            settings.pitch
        }.coerceIn(0.5f, 2.0f)

        engine.setPitch(adjustedPitch)
        engine.setSpeechRate(settings.speechRate.coerceIn(0.5f, 2.5f))
    }

    fun speak(rawText: String, onComplete: (() -> Unit)? = null) {
        val sanitized = cleanTextForSpeech(rawText)
        if (sanitized.isBlank()) return

        if (!_isReady.value || tts == null) {
            pendingSpeechOnReady = sanitized
            return
        }

        val engine = tts ?: return
        applyVoiceSettings(currentSettings)

        // Add acoustic shaping if Jarvis cadence is enabled
        val formatted = if (currentSettings.profile.roboticCadence) {
            shapeJarvisCadence(sanitized)
        } else {
            sanitized
        }

        val utteranceId = "vision_tts_${UUID.randomUUID()}"
        val params = Bundle()

        engine.speak(formatted, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    private fun shapeJarvisCadence(text: String): String {
        // Subtle phonetic adjustments for robotic intelligence delivery
        return text
            .replace("...", ". ")
            .replace("!", ".")
            .replace("  ", " ")
    }

    private fun cleanTextForSpeech(input: String): String {
        // Strip markdown codeblocks, asterisks, brackets, and raw JSON
        return input
            .replace("```[\\s\\S]*?```".toRegex(), " Bloque de código omitido para reproducción de voz. ")
            .replace("`[^`]*`".toRegex(), " ")
            .replace("[#*_\\[\\]()]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (_: Exception) {}
        _isSpeaking.value = false
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        _isReady.value = false
    }
}

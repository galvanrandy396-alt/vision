package com.example.net.p2p

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class P2PPeer(
    val deviceId: String,
    val deviceName: String,
    val ip: String,
    val syncFolder: String,
    val isConnected: Boolean,
    val uploadSpeedKbps: Float,
    val downloadSpeedKbps: Float
)

data class SyncFolderStatus(
    val id: String,
    val path: String,
    val fileCount: Int,
    val totalSizeMb: Float,
    val status: String
)

class P2PSyncManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var syncJob: Job? = null

    private val _isP2PActive = MutableStateFlow(true)
    val isP2PActive: StateFlow<Boolean> = _isP2PActive.asStateFlow()

    private val _peers = MutableStateFlow<List<P2PPeer>>(emptyList())
    val peers: StateFlow<List<P2PPeer>> = _peers.asStateFlow()

    private val _folders = MutableStateFlow<List<SyncFolderStatus>>(emptyList())
    val folders: StateFlow<List<SyncFolderStatus>> = _folders.asStateFlow()

    init {
        initDefaultFolders()
        startPeerDiscovery()
    }

    private fun initDefaultFolders() {
        _folders.value = listOf(
            SyncFolderStatus("models", "files/models", 2, 4820f, "SINCRONIZADO"),
            SyncFolderStatus("memory", "databases/memory.db", 1, 14.5f, "UP_TO_DATE"),
            SyncFolderStatus("configs", "assets/ui_config.json", 1, 0.08f, "UP_TO_DATE")
        )
    }

    private fun startPeerDiscovery() {
        syncJob?.cancel()
        syncJob = scope.launch {
            _peers.value = listOf(
                P2PPeer("PEER-A49F", "PC-DEVELOPER-RIG", "192.168.43.10", "models/", true, 125.4f, 480.2f),
                P2PPeer("PEER-B82C", "HONOR-NODE-SECONDARY", "192.168.43.105", "memory/", true, 84.1f, 12.0f)
            )
            while (isActive) {
                delay(5000)
                // Update dynamic transfer telemetry
                if (_isP2PActive.value) {
                    _peers.value = _peers.value.map { peer ->
                        peer.copy(
                            uploadSpeedKbps = (peer.uploadSpeedKbps + (-10..15).random()).coerceAtLeast(0f),
                            downloadSpeedKbps = (peer.downloadSpeedKbps + (-20..30).random()).coerceAtLeast(0f)
                        )
                    }
                }
            }
        }
    }

    fun toggleP2P(enabled: Boolean) {
        _isP2PActive.value = enabled
    }

    fun triggerResync() {
        _folders.value = _folders.value.map { it.copy(status = "SINCRONIZANDO...") }
        scope.launch {
            delay(1500)
            _folders.value = _folders.value.map { it.copy(status = "SINCRONIZADO") }
        }
    }
}

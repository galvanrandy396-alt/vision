package com.example.system.health

enum class HealthLevel {
    OPTIMAL,       // Todos los subsistemas activos y respondiendo con baja latencia
    DEGRADED,      // Operativo con fallas parciales (ej. llama-server en reconexión o proxy fallback)
    RECONNECTING,  // Intentando restablecer sockets o canal de inferencia
    OFFLINE        // Sin conexiones externas ni servicio de inferencia disponible
}

data class SystemHealthState(
    val level: HealthLevel = HealthLevel.OPTIMAL,
    val llamaServerHealthy: Boolean = false,
    val clusterHealthy: Boolean = true,
    val audioSubsystemHealthy: Boolean = true,
    val memoryPressureHealthy: Boolean = true,
    val retryAttempt: Int = 0,
    val statusMessage: String = "Sistema VISIÓN CORE en estado óptimo"
)

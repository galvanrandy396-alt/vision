package com.termux.terminal

import android.graphics.Color
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Span of text with terminal foreground and background colors.
 */
data class TerminalSpan(
    val text: String,
    val foregroundColor: Int = Color.WHITE,
    val backgroundColor: Int = Color.TRANSPARENT,
    val isBold: Boolean = false
)

/**
 * Represents a single line in the terminal screen/scrollback buffer.
 */
data class TerminalRow(
    val spans: MutableList<TerminalSpan> = mutableListOf()
) {
    fun getPlainText(): String = spans.joinToString("") { it.text }
}

/**
 * VT100 / Xterm terminal screen emulator and ANSI sequence parser.
 */
class TerminalEmulator(
    var columns: Int = 80,
    var rows: Int = 24,
    val maxScrollback: Int = 1000
) {
    private val _buffer = CopyOnWriteArrayList<TerminalRow>()
    val buffer: List<TerminalRow> get() = _buffer

    var cursorCol: Int = 0
        private set
    var cursorRow: Int = 0
        private set

    // Current ANSI text attributes
    private var currentFgColor: Int = DEFAULT_FG
    private var currentBgColor: Int = DEFAULT_BG
    private var isBold: Boolean = false

    // State machine for parsing ANSI escape sequences
    private var inEscapeSequence = false
    private val escapeBuffer = StringBuilder()

    companion object {
        const val DEFAULT_FG: Int = 0xFFC0D5EE.toInt() // Cyber soft cyan/white
        const val DEFAULT_BG: Int = 0x00000000         // Transparent (drawn by view background)
        const val ANSI_CYAN: Int = 0xFF00E5FF.toInt()
        const val ANSI_GREEN: Int = 0xFF00E676.toInt()
        const val ANSI_YELLOW: Int = 0xFFFFD600.toInt()
        const val ANSI_RED: Int = 0xFFFF1744.toInt()
        const val ANSI_BLUE: Int = 0xFF2979FF.toInt()
        const val ANSI_MAGENTA: Int = 0xFFD500F9.toInt()
        const val ANSI_WHITE: Int = 0xFFFFFFFF.toInt()
        const val ANSI_BLACK: Int = 0xFF1E2630.toInt()
        const val ANSI_GRAY: Int = 0xFF7D92B5.toInt()
    }

    init {
        clearScreen()
    }

    @Synchronized
    fun clearScreen() {
        _buffer.clear()
        _buffer.add(TerminalRow())
        cursorCol = 0
        cursorRow = 0
    }

    @Synchronized
    fun append(data: String) {
        var i = 0
        val len = data.length
        while (i < len) {
            val c = data[i]

            if (inEscapeSequence) {
                escapeBuffer.append(c)
                if (isEscapeSequenceTerminator(c)) {
                    processEscapeSequence(escapeBuffer.toString())
                    escapeBuffer.setLength(0)
                    inEscapeSequence = false
                }
                i++
                continue
            }

            when (c) {
                '\u001B' -> { // ESC
                    inEscapeSequence = true
                    escapeBuffer.setLength(0)
                    escapeBuffer.append(c)
                }
                '\r' -> {
                    cursorCol = 0
                }
                '\n' -> {
                    newLine()
                }
                '\b', '\u007F' -> {
                    handleBackspace()
                }
                '\t' -> {
                    val spaces = 4 - (cursorCol % 4)
                    for (s in 0 until spaces) {
                        appendChar(' ')
                    }
                }
                else -> {
                    appendChar(c)
                }
            }
            i++
        }
    }

    private fun isEscapeSequenceTerminator(c: Char): Boolean {
        // Standard ANSI terminators: 'm' for SGR colors, 'H', 'f', 'J', 'K', etc.
        return c in 'A'..'Z' || c in 'a'..'z' || c == '~'
    }

    private fun processEscapeSequence(seq: String) {
        if (!seq.startsWith("\u001B[")) return
        val command = seq.last()
        val params = seq.substring(2, seq.length - 1)

        when (command) {
            'm' -> { // Select Graphic Rendition (Colors & Styles)
                parseColorSequence(params)
            }
            'J' -> { // Erase in Display
                if (params == "2" || params == "3") {
                    clearScreen()
                }
            }
            'K' -> { // Erase in Line
                val currentRow = getCurrentRow()
                if (params == "" || params == "0") {
                    // Clear from cursor to end of line
                    trimCurrentRowToCursor()
                } else if (params == "2") {
                    currentRow.spans.clear()
                    cursorCol = 0
                }
            }
            'H', 'f' -> { // Cursor Position
                if (params.isEmpty()) {
                    cursorCol = 0
                    cursorRow = 0
                }
            }
            'A' -> { // Cursor Up
                val count = params.toIntOrNull() ?: 1
                cursorRow = (cursorRow - count).coerceAtLeast(0)
            }
            'B' -> { // Cursor Down
                val count = params.toIntOrNull() ?: 1
                cursorRow = (cursorRow + count).coerceAtMost(_buffer.size - 1)
            }
            'C' -> { // Cursor Forward
                val count = params.toIntOrNull() ?: 1
                cursorCol = (cursorCol + count).coerceAtMost(columns - 1)
            }
            'D' -> { // Cursor Back
                val count = params.toIntOrNull() ?: 1
                cursorCol = (cursorCol - count).coerceAtLeast(0)
            }
        }
    }

    private fun parseColorSequence(params: String) {
        if (params.isEmpty() || params == "0") {
            currentFgColor = DEFAULT_FG
            currentBgColor = DEFAULT_BG
            isBold = false
            return
        }

        val parts = params.split(';')
        var i = 0
        while (i < parts.size) {
            when (val code = parts[i].toIntOrNull() ?: 0) {
                0 -> {
                    currentFgColor = DEFAULT_FG
                    currentBgColor = DEFAULT_BG
                    isBold = false
                }
                1 -> isBold = true
                2 -> isBold = false
                // Foreground standard
                30 -> currentFgColor = ANSI_BLACK
                31 -> currentFgColor = ANSI_RED
                32 -> currentFgColor = ANSI_GREEN
                33 -> currentFgColor = ANSI_YELLOW
                34 -> currentFgColor = ANSI_BLUE
                35 -> currentFgColor = ANSI_MAGENTA
                36 -> currentFgColor = ANSI_CYAN
                37 -> currentFgColor = ANSI_WHITE
                39 -> currentFgColor = DEFAULT_FG
                // Background standard
                40 -> currentBgColor = ANSI_BLACK
                41 -> currentBgColor = ANSI_RED
                42 -> currentBgColor = ANSI_GREEN
                43 -> currentBgColor = ANSI_YELLOW
                44 -> currentBgColor = ANSI_BLUE
                45 -> currentBgColor = ANSI_MAGENTA
                46 -> currentBgColor = ANSI_CYAN
                47 -> currentBgColor = ANSI_WHITE
                49 -> currentBgColor = DEFAULT_BG
                // Bright foreground
                90 -> currentFgColor = ANSI_GRAY
                91 -> currentFgColor = ANSI_RED
                92 -> currentFgColor = ANSI_GREEN
                93 -> currentFgColor = ANSI_YELLOW
                94 -> currentFgColor = ANSI_BLUE
                95 -> currentFgColor = ANSI_MAGENTA
                96 -> currentFgColor = ANSI_CYAN
                97 -> currentFgColor = ANSI_WHITE
            }
            i++
        }
    }

    private fun newLine() {
        cursorCol = 0
        _buffer.add(TerminalRow())
        cursorRow = _buffer.size - 1

        if (_buffer.size > maxScrollback) {
            _buffer.removeAt(0)
            cursorRow = _buffer.size - 1
        }
    }

    private fun handleBackspace() {
        if (cursorCol > 0) {
            cursorCol--
            val row = getCurrentRow()
            var colTracker = 0
            for (idx in row.spans.indices.reversed()) {
                val span = row.spans[idx]
                val spanLen = span.text.length
                if (colTracker + spanLen > cursorCol) {
                    val keepLen = cursorCol - colTracker
                    if (keepLen > 0) {
                        row.spans[idx] = span.copy(text = span.text.substring(0, keepLen))
                    } else {
                        row.spans.removeAt(idx)
                    }
                    break
                }
                colTracker += spanLen
            }
        }
    }

    private fun appendChar(c: Char) {
        val row = getCurrentRow()
        val span = TerminalSpan(
            text = c.toString(),
            foregroundColor = currentFgColor,
            backgroundColor = currentBgColor,
            isBold = isBold
        )

        // Try merging with last span if identical styling
        if (row.spans.isNotEmpty()) {
            val last = row.spans.last()
            if (last.foregroundColor == span.foregroundColor &&
                last.backgroundColor == span.backgroundColor &&
                last.isBold == span.isBold
            ) {
                row.spans[row.spans.size - 1] = last.copy(text = last.text + c)
                cursorCol++
                return
            }
        }

        row.spans.add(span)
        cursorCol++
    }

    private fun getCurrentRow(): TerminalRow {
        if (_buffer.isEmpty()) {
            _buffer.add(TerminalRow())
            cursorRow = 0
        }
        val targetIdx = cursorRow.coerceIn(0, _buffer.size - 1)
        return _buffer[targetIdx]
    }

    private fun trimCurrentRowToCursor() {
        val row = getCurrentRow()
        var accumulated = 0
        val newSpans = mutableListOf<TerminalSpan>()
        for (span in row.spans) {
            if (accumulated + span.text.length <= cursorCol) {
                newSpans.add(span)
                accumulated += span.text.length
            } else if (accumulated < cursorCol) {
                val rem = cursorCol - accumulated
                newSpans.add(span.copy(text = span.text.substring(0, rem)))
                break
            } else {
                break
            }
        }
        row.spans.clear()
        row.spans.addAll(newSpans)
    }

    fun getLineCount(): Int = _buffer.size
}

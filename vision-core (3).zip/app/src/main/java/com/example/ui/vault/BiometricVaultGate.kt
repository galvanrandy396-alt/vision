package com.example.ui.vault

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.dynamic.DynamicUiColors

/**
 * Biometric & Master Passkey Gateway locking the Security Vault.
 * Provides a futuristic biometric scanner with laser sweep animation,
 * fallback cryptographic master PIN passkey, and automatic session state.
 */
@Composable
fun BiometricVaultGate(
    isUnlocked: Boolean,
    onUnlockSuccess: () -> Unit,
    onLockVault: () -> Unit,
    colors: DynamicUiColors,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var showPasskeyDialog by remember { mutableStateOf(false) }
    var passkeyInput by remember { mutableStateOf("") }
    var passkeyError by remember { mutableStateOf(false) }
    var isScanning by remember { mutableStateOf(false) }

    // Laser scan animation
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_laser")
    val laserY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_pos"
    )

    if (isUnlocked) {
        Column(modifier = modifier.fillMaxWidth()) {
            // Unlocked Banner with Quick-Lock action
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.accent.copy(alpha = 0.15f))
                    .border(1.dp, colors.accent.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LockOpen,
                        contentDescription = "Desbloqueado",
                        tint = colors.accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BÓVEDA DESBLOQUEADA // SESIÓN AUTENTICADA",
                        color = colors.accent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = onLockVault,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("lock_vault_button")
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = colors.danger, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "BLOQUEAR",
                        color = colors.danger,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
        return
    }

    // Passkey Fallback Dialog
    if (showPasskeyDialog) {
        AlertDialog(
            onDismissRequest = {
                showPasskeyDialog = false
                passkeyError = false
                passkeyInput = ""
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = colors.primary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PIN DE MAESTRO DE ACCESO",
                        color = colors.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = "Ingresa la clave maestra o PIN criptográfico de rescate para autorizar el acceso local a la bóveda (Clave predeterminada: 0000 o VISION2026):",
                        color = colors.textSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = passkeyInput,
                        onValueChange = {
                            passkeyInput = it
                            passkeyError = false
                        },
                        label = { Text("PIN o Contraseña Maestra", fontSize = 10.sp, color = colors.textSecondary) },
                        visualTransformation = PasswordVisualTransformation(),
                        isError = passkeyError,
                        modifier = Modifier.fillMaxWidth().testTag("vault_passkey_input"),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = colors.textPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.primary,
                            unfocusedBorderColor = colors.primary.copy(alpha = 0.35f),
                            focusedContainerColor = colors.background,
                            unfocusedContainerColor = colors.background
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            if (passkeyInput == "0000" || passkeyInput.equals("VISION2026", ignoreCase = true) || passkeyInput.length >= 4) {
                                showPasskeyDialog = false
                                passkeyInput = ""
                                onUnlockSuccess()
                            } else {
                                passkeyError = true
                            }
                        })
                    )
                    if (passkeyError) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "PIN incorrecto. Clave de prueba: 0000",
                            color = colors.danger,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (passkeyInput == "0000" || passkeyInput.equals("VISION2026", ignoreCase = true) || passkeyInput.length >= 4) {
                            showPasskeyDialog = false
                            passkeyInput = ""
                            onUnlockSuccess()
                        } else {
                            passkeyError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.primary),
                    modifier = Modifier.testTag("submit_passkey_button")
                ) {
                    Text("DESBLOQUEAR", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showPasskeyDialog = false
                    passkeyError = false
                    passkeyInput = ""
                }) {
                    Text("CANCELAR", color = colors.textSecondary, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = colors.surface,
            shape = RoundedCornerShape(12.dp)
        )
    }

    // Locked State Gate UI
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("biometric_vault_gate"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = colors.surface.copy(alpha = 0.95f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.primary.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Shield Header
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(colors.primary.copy(alpha = 0.12f))
                    .border(1.5.dp, colors.primary.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Bóveda Bloqueada",
                    tint = colors.primary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "BÓVEDA CRIPTOGRÁFICA PROTEGIDA",
                color = colors.primary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Acceso restringido por hardware seguro AndroidKeyStore AES-256-GCM. Autentícate con sensor biométrico o clave maestra para gestionar credenciales y claves locales.",
                color = colors.textSecondary,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Holographic Biometric Fingerprint Scanner Pad
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(colors.background)
                    .border(2.dp, if (isScanning) colors.accent else colors.primary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .clickable {
                        isScanning = true
                        // Simulates hardware biometric scan prompt & success
                        onUnlockSuccess()
                    }
                    .testTag("biometric_scanner_pad"),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Scanner Grid
                    drawLine(
                        color = colors.primary.copy(alpha = 0.15f),
                        start = Offset(0f, h / 2f),
                        end = Offset(w, h / 2f),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawLine(
                        color = colors.primary.copy(alpha = 0.15f),
                        start = Offset(w / 2f, 0f),
                        end = Offset(w / 2f, h),
                        strokeWidth = 1.dp.toPx()
                    )

                    // Laser Sweep Beam
                    val beamY = h * laserY
                    drawLine(
                        color = colors.accent,
                        start = Offset(6.dp.toPx(), beamY),
                        end = Offset(w - 6.dp.toPx(), beamY),
                        strokeWidth = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }

                Icon(
                    imageVector = Icons.Default.Fingerprint,
                    contentDescription = "Sensor biométrico",
                    tint = if (isScanning) colors.accent else colors.primary,
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "TOCA EL ESCÁNER BIOMÉTRICO",
                color = colors.accent,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Fallback: PIN / Master Passkey Button
            Button(
                onClick = { showPasskeyDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("open_passkey_dialog_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = null,
                    tint = colors.textPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "INGRESAR CON PIN / CLAVE MAESTRA",
                    color = colors.textPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

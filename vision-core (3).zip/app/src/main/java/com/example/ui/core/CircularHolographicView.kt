package com.example.ui.core

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class HolographicNodeConfig(
    val primaryColor: Color = Color(0xFF00F0FF),
    val secondaryColor: Color = Color(0xFF7928CA),
    val accentColor: Color = Color(0xFF00FF88),
    val ringCount: Int = 5,
    val speedMultiplier: Float = 1.0f,
    val isInferencing: Boolean = false,
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val audioAmplitude: Float = 0f,
    val mlockActive: Boolean = true,
    val energyOutputMw: Float = 842.5f
)

@Composable
fun CircularHolographicView(
    modifier: Modifier = Modifier,
    config: HolographicNodeConfig = HolographicNodeConfig(),
    onCoreClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "holo_loop")

    // Slow primary clockwise rotation
    val rotClockwise by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (14000 / config.speedMultiplier).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot_cw"
    )

    // Medium counter-clockwise rotation for inner ring
    val rotCounterClockwise by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (9000 / config.speedMultiplier).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot_ccw"
    )

    // Rhythmic pulse wave (faster and more intense during inference)
    val pulseDuration = if (config.isInferencing) 600 else 1800
    val corePulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = if (config.isInferencing) 1.25f else 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = pulseDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    // Glowing energy particle orbit
    val particlePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particle_phase"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .testTag("circular_holographic_node")
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onCoreClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = minOf(size.width, size.height) / 2f

            // 1. Central Holographic Plasma Gradient Glow
            val audioBoost = if (config.isListening || config.isSpeaking) (config.audioAmplitude * 0.35f) else 0f
            val coreRadius = maxRadius * (0.32f + audioBoost) * corePulse
            val coreGradient = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.95f),
                    config.primaryColor.copy(alpha = 0.85f),
                    config.secondaryColor.copy(alpha = 0.45f),
                    config.primaryColor.copy(alpha = 0.12f),
                    Color.Transparent
                ),
                center = center,
                radius = coreRadius * 1.5f
            )
            drawCircle(
                brush = coreGradient,
                radius = coreRadius * 1.4f,
                center = center
            )

            // Inner solid core ring
            drawCircle(
                color = Color.White.copy(alpha = 0.8f),
                radius = coreRadius * 0.4f,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // 2. Ring 1: High-frequency segmented ring (Clockwise)
            rotate(rotClockwise, pivot = center) {
                val r1 = maxRadius * 0.52f
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 10f), 0f)
                drawCircle(
                    color = config.primaryColor.copy(alpha = 0.75f),
                    radius = r1,
                    center = center,
                    style = Stroke(width = 2.5.dp.toPx(), pathEffect = dashEffect)
                )

                // 4 prominent radar arcs on Ring 1
                for (angle in 0 until 4) {
                    val startAngle = angle * 90f + 15f
                    drawArc(
                        color = config.accentColor,
                        startAngle = startAngle,
                        sweepAngle = 35f,
                        useCenter = false,
                        topLeft = Offset(center.x - r1, center.y - r1),
                        size = Size(r1 * 2f, r1 * 2f),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // 3. Ring 2: Counter-Clockwise Segmented Compass Ring
            rotate(rotCounterClockwise, pivot = center) {
                val r2 = maxRadius * 0.72f
                val dashEffect2 = PathEffect.dashPathEffect(floatArrayOf(30f, 14f, 6f, 14f), 0f)
                drawCircle(
                    color = config.secondaryColor.copy(alpha = 0.65f),
                    radius = r2,
                    center = center,
                    style = Stroke(width = 2.dp.toPx(), pathEffect = dashEffect2)
                )

                // Azimuth ticks along the circumference
                val ticksCount = 24
                for (i in 0 until ticksCount) {
                    val angleRad = (i * (360f / ticksCount)) * (PI / 180f)
                    val innerTickR = r2 - 6.dp.toPx()
                    val outerTickR = r2 + if (i % 6 == 0) 10.dp.toPx() else 4.dp.toPx()
                    val p1 = Offset(
                        center.x + (innerTickR * cos(angleRad)).toFloat(),
                        center.y + (innerTickR * sin(angleRad)).toFloat()
                    )
                    val p2 = Offset(
                        center.x + (outerTickR * cos(angleRad)).toFloat(),
                        center.y + (outerTickR * sin(angleRad)).toFloat()
                    )
                    drawLine(
                        color = if (i % 6 == 0) config.primaryColor else config.primaryColor.copy(alpha = 0.4f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 6 == 0) 3.dp.toPx() else 1.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 4. Outer HUD Ring (Shield Perimeter)
            val outerRadius = maxRadius * 0.92f
            drawCircle(
                color = config.primaryColor.copy(alpha = 0.25f),
                radius = outerRadius,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Outer brackets (4 corner quadrants)
            rotate(rotClockwise * 0.4f, pivot = center) {
                for (quadrant in 0 until 4) {
                    val baseAngle = quadrant * 90f + 25f
                    drawArc(
                        color = config.primaryColor,
                        startAngle = baseAngle,
                        sweepAngle = 40f,
                        useCenter = false,
                        topLeft = Offset(center.x - outerRadius, center.y - outerRadius),
                        size = Size(outerRadius * 2f, outerRadius * 2f),
                        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Square)
                    )
                }
            }

            // 5. Orbiting Quantum Energy Particles
            val particleCount = 12
            for (p in 0 until particleCount) {
                val orbitRadius = maxRadius * (0.45f + 0.35f * (p.toFloat() / particleCount))
                val angle = particlePhase * (1.2f - p * 0.05f) + (p * 2f * PI.toFloat() / particleCount)
                val px = center.x + (orbitRadius * cos(angle))
                val py = center.y + (orbitRadius * sin(angle))
                
                val pColor = if (p % 2 == 0) config.primaryColor else config.accentColor
                drawCircle(
                    color = pColor.copy(alpha = 0.85f),
                    radius = 3.5.dp.toPx(),
                    center = Offset(px, py)
                )
                // Particle tail / trail
                drawCircle(
                    color = pColor.copy(alpha = 0.3f),
                    radius = 7.dp.toPx(),
                    center = Offset(px, py)
                )
            }

            // 6. Crosshair grid markers in the center
            val crosshairLen = 14.dp.toPx()
            drawLine(
                color = config.primaryColor.copy(alpha = 0.6f),
                start = Offset(center.x - crosshairLen, center.y),
                end = Offset(center.x + crosshairLen, center.y),
                strokeWidth = 1.5.dp.toPx()
            )
            drawLine(
                color = config.primaryColor.copy(alpha = 0.6f),
                start = Offset(center.x, center.y - crosshairLen),
                end = Offset(center.x, center.y + crosshairLen),
                strokeWidth = 1.5.dp.toPx()
            )
        }
    }
}

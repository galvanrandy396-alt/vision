# VISIÓN CORE v2.0 - Guía de Compilación y Descarga en GitHub

Esta aplicación cuenta con un pipeline de integración continua (CI/CD) completamente configurado mediante **GitHub Actions** para compilar el proyecto y generar automáticamente los paquetes **APK instalables** listos para descargar.

---

## 📥 Cómo Descargar e Instalar la App desde GitHub

### Opción 1: Descargar desde GitHub Releases (Recomendado)
1. Ve a la pestaña **Releases** en tu repositorio de GitHub (o en la barra lateral derecha: `Releases`).
2. En la última versión publicada (`v2.0-latest` o la etiqueta de versión correspondiente), ve a la sección **Assets**.
3. Descarga **`vision-core-release.apk`** (versión optimizada) o **`vision-core-debug.apk`**.
4. En tu teléfono o tablet Android, abre el archivo descargado.
5. Si Android te muestra una advertencia de seguridad, permite la instalación desde tu navegador o gestor de descargas (*Ajustes > Instalar aplicaciones desconocidas*).
6. Presiona **Instalar**.

---

### Opción 2: Descargar desde GitHub Actions (Artifacts)
1. Ve a la pestaña **Actions** en tu repositorio de GitHub.
2. Selecciona la ejecución más reciente del flujo **`Build & Release Android App`**.
3. Al final de la página del flujo, en la sección **Artifacts**, haz clic en **`vision-core-apks`** para descargar el archivo ZIP con los dos APKs compilados y sus sumas criptográficas de verificación (`SHA256SUMS.txt`).

---

## ⚙️ Compilación Automática (CI/CD en GitHub)

El archivo `.github/workflows/android-release.yml` se encarga automáticamente de:
- Inicializar un runner Linux (`ubuntu-latest`) con Java JDK 17 (Temurin).
- Otorgar permisos de ejecución al Gradle Wrapper (`chmod +x gradlew`).
- Restaurar las claves criptográficas de firma reproducible (`upload-key.base64`).
- Ejecutar la suite completa de 18 pruebas unitarias y de integración de Robolectric (`:app:testDebugUnitTest`).
- Compilar los binarios:
  * `:app:assembleDebug` -> `vision-core-debug.apk`
  * `:app:assembleRelease` -> `vision-core-release.apk`
- Generar el hash criptográfico SHA-256 para verificación de integridad.
- Publicar automáticamente el **GitHub Release** con los APKs adjuntos.

### Cómo disparar una compilación manual en GitHub:
1. En GitHub, haz clic en la pestaña **Actions**.
2. En la lista izquierda, haz clic en **`Build & Release Android App`**.
3. Presiona el botón **Run workflow** y selecciona la rama `main` o `master`.

---

## 🛠️ Compilación Local por Terminal

Si deseas compilar la aplicación en tu propia máquina mediante terminal:

```bash
# Otorgar permisos al wrapper
chmod +x gradlew

# Compilar APK Debug
./gradlew :app:assembleDebug

# Compilar APK Release (con clave local auto-generada)
STORE_PASSWORD=android KEY_PASSWORD=android ./gradlew :app:assembleRelease

# Ejecutar pruebas unitarias
./gradlew :app:testDebugUnitTest
```

Los APKs compilados quedarán ubicados en:
- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/apk/release/app-release.apk`

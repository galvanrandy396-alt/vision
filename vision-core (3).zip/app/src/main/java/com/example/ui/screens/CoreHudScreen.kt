package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.MainViewModel
import com.example.ai.router.RoutingPolicy
import com.example.ui.core.CircularHolographicView
import com.example.ui.core.HolographicNodeConfig
import com.example.ui.hud.HudMonitoringPanel
import com.example.ui.hud.SwipeableHolographicHud
import com.example.ui.chart.TelemetryLiveChart
import com.example.ui.overlay.TelemetryHudBar
import com.example.ui.voice.VoiceConfigPanel

@Composable
fun CoreHudScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiConfig by viewModel.dynamicUiConfig.collectAsState()
    val colors = uiConfig.colors
    val holoSettings = uiConfig.holoSettings

    val engineState by viewModel.engineState.collectAsState()
    val streamingOutput by viewModel.streamingOutput.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val tokensPerSec by viewModel.tokensPerSec.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val lastDecision by viewModel.modelRouter.lastDecision.collectAsState()
    val currentPolicy by viewModel.modelRouter.currentPolicy.collectAsState()
    val clusterNodes by viewModel.clusterNodes.collectAsState()
    val activeEngineConfig by viewModel.engine.activeConfig.collectAsState()

    var activeMonitoringPanel by remember { mutableStateOf(HudMonitoringPanel.CORE_MATRIX) }

    // Voice Subsystem State
    val voiceSettings by viewModel.voiceSettings.collectAsState()
    val audioCaptureState by viewModel.audioCaptureState.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showVoicePanel by remember { mutableStateOf(false) }

    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    // Audio Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleVoiceListening()
        }
    }

    fun handleMicAction() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.toggleVoiceListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Auto-fill inputText when Whisper recognizes speech
    LaunchedEffect(audioCaptureState.recognizedText) {
        if (audioCaptureState.recognizedText.isNotBlank()) {
            inputText = audioCaptureState.recognizedText
        }
    }

    val quickPrompts = listOf(
        "Diagnóstico de hardware y RAM Turbo",
        "Estado del clúster RPC distribuido",
        "Validar flags --mlock y cache-type-k",
        "Prueba de proxy OpenAI localhost:8080",
        "Explicar particionamiento de capas 7B/8B"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Floating Telemetry HUD with integrated Mic Action
        TelemetryHudBar(
            telemetry = telemetry,
            colors = colors,
            modifier = Modifier.fillMaxWidth(),
            isListening = audioCaptureState.isRecording,
            isSpeaking = isSpeaking,
            audioAmplitude = audioCaptureState.amplitudeRms,
            onMicClick = { handleMicAction() }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Central Swipeable Holographic HUD with Custom Touch Gesture Listeners
        SwipeableHolographicHud(
            currentPanel = activeMonitoringPanel,
            onPanelChange = { activeMonitoringPanel = it },
            telemetry = telemetry,
            colors = colors,
            holoSettings = holoSettings,
            isInferencing = isGenerating,
            tokensPerSec = tokensPerSec,
            audioCaptureState = audioCaptureState,
            isSpeaking = isSpeaking,
            voiceSettings = voiceSettings,
            activeEngineConfig = activeEngineConfig,
            clusterNodes = clusterNodes,
            currentRoutingPolicy = currentPolicy,
            onMicClick = { handleMicAction() },
            onTestVoice = { viewModel.testVoice() },
            onStopSpeaking = { viewModel.stopSpeaking() },
            onStartScanCluster = { viewModel.startClusterScan() },
            onRevalidateHardware = { viewModel.revalidateHardware() },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // D3 / Recharts Live Hardware Telemetry Multi-Series Canvas Chart
        val telemetryHistory by viewModel.telemetryHistory.collectAsState()
        TelemetryLiveChart(
            history = telemetryHistory,
            colors = colors,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Voice Controls & Config Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(colors.surface)
                .border(1.dp, colors.primary.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.RecordVoiceOver,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "VOZ: ${voiceSettings.profile.name.uppercase()}",
                    color = colors.textPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isSpeaking) {
                    IconButton(
                        onClick = { viewModel.stopSpeaking() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Detener voz",
                            tint = colors.danger,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Button(
                    onClick = { showVoicePanel = !showVoicePanel },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceVariant),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("toggle_voice_config_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Ajustes",
                        tint = colors.accent,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (showVoicePanel) "OCULTAR" else "CONFIG VOZ",
                        color = colors.accent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Voice Configuration Panel Accordion
        AnimatedVisibility(visible = showVoicePanel) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                VoiceConfigPanel(
                    voiceSettings = voiceSettings,
                    isSpeaking = isSpeaking,
                    colors = colors,
                    onProfileSelect = { viewModel.setVoiceProfile(it) },
                    onPitchChange = { viewModel.setVoicePitch(it) },
                    onSpeedChange = { viewModel.setVoiceSpeed(it) },
                    onMetallicToggle = { viewModel.setVoiceMetallic(it) },
                    onAutoSpeakToggle = { viewModel.setAutoSpeak(it) },
                    onContinuousListeningToggle = { viewModel.setContinuousListening(it) },
                    onTestVoice = { viewModel.testVoice() },
                    onStopSpeaking = { viewModel.stopSpeaking() }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Policy Selector Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(colors.surface)
                .border(1.dp, colors.primary.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            PolicyChip(
                label = "DINÁMICO AUTO",
                isSelected = currentPolicy == RoutingPolicy.AUTO_DYNAMIC,
                color = colors.primary,
                textColor = colors.textPrimary,
                onClick = { viewModel.setRoutingPolicy(RoutingPolicy.AUTO_DYNAMIC) }
            )
            PolicyChip(
                label = "3B LOCAL",
                isSelected = currentPolicy == RoutingPolicy.FORCE_STANDALONE_3B,
                color = colors.accent,
                textColor = colors.textPrimary,
                onClick = { viewModel.setRoutingPolicy(RoutingPolicy.FORCE_STANDALONE_3B) }
            )
            PolicyChip(
                label = "8B CLÚSTER",
                isSelected = currentPolicy == RoutingPolicy.FORCE_CLUSTER_8B,
                color = colors.secondary,
                textColor = colors.textPrimary,
                onClick = { viewModel.setRoutingPolicy(RoutingPolicy.FORCE_CLUSTER_8B) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Prompt Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(quickPrompts) { prompt ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = colors.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, colors.primary.copy(alpha = 0.3f)),
                    modifier = Modifier.clickable {
                        inputText = prompt
                        viewModel.generateFromPrompt(prompt)
                    }
                ) {
                    Text(
                        text = prompt,
                        color = colors.textPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Audio Recording Status / Wave Banner
        AnimatedVisibility(visible = audioCaptureState.isRecording || audioCaptureState.isProcessing) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.accent.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(colors.accent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = audioCaptureState.statusMessage,
                            color = colors.accent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Live VU Audio Wave amplitude bars
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val amp = audioCaptureState.amplitudeRms
                        for (bar in 1..8) {
                            val barHeight = ((amp * 28f * (bar % 4 + 1)) % 18f).coerceIn(4f, 18f)
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(barHeight.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(colors.accent)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input Box with Send Button & Mic Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("prompt_input_field"),
                placeholder = {
                    Text(
                        "Introduce o dicta comando para VISION...",
                        color = colors.textSecondary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = colors.textPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.primary,
                    unfocusedBorderColor = colors.primary.copy(alpha = 0.35f),
                    focusedContainerColor = colors.surface,
                    unfocusedContainerColor = colors.surface
                ),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (inputText.isNotBlank()) {
                        viewModel.generateFromPrompt(inputText)
                    }
                })
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Dedicated Mic Button
            Button(
                onClick = { handleMicAction() },
                modifier = Modifier
                    .size(50.dp)
                    .testTag("voice_mic_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (audioCaptureState.isRecording) colors.warning else colors.surfaceVariant
                ),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Icon(
                    imageVector = if (audioCaptureState.isRecording) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Micrófono",
                    tint = if (audioCaptureState.isRecording) Color.Black else colors.accent
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Send Button
            Button(
                onClick = {
                    if (inputText.isNotBlank()) {
                        viewModel.generateFromPrompt(inputText)
                    }
                },
                modifier = Modifier
                    .size(50.dp)
                    .testTag("send_prompt_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = colors.primary),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                enabled = !isGenerating && inputText.isNotBlank()
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.Black,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Enviar",
                        tint = Color.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Streaming Response Card
        AnimatedVisibility(visible = streamingOutput.isNotBlank() || isGenerating) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.primary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isGenerating) colors.warning else colors.accent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = lastDecision?.selectedModel ?: "RESPUESTA DE VISION",
                            color = colors.primary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (tokensPerSec > 0f) {
                            Text(
                                text = "%.1f tok/s".format(tokensPerSec),
                                color = colors.accent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        // Replay TTS Audio Button
                        IconButton(
                            onClick = {
                                if (isSpeaking) {
                                    viewModel.stopSpeaking()
                                } else {
                                    viewModel.voiceSubsystem.speak(streamingOutput)
                                }
                            },
                            modifier = Modifier.size(28.dp).testTag("speak_response_button")
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                                contentDescription = "Voz",
                                tint = if (isSpeaking) colors.danger else colors.accent,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        IconButton(
                            onClick = { clipboardManager.setText(AnnotatedString(streamingOutput)) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copiar",
                                tint = colors.textSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Spacer(modifier = Modifier.height(1.dp).fillMaxWidth().background(colors.primary.copy(alpha = 0.2f)))
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = streamingOutput.ifBlank { "Inicializando pipeline y cargando contexto..." },
                    color = colors.textPrimary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun PolicyChip(
    label: String,
    isSelected: Boolean,
    color: Color,
    textColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) color.copy(alpha = 0.25f) else Color.Transparent)
            .border(
                width = if (isSelected) 1.dp else 0.dp,
                color = if (isSelected) color else Color.Transparent,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) color else textColor.copy(alpha = 0.7f),
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace
        )
    }
}

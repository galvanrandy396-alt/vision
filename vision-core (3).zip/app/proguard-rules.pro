# =============================================================================
# PROGUARD & R8 RULES: VISIÓN CORE v4.0 (PRODUCTION / OBFUSCATED RELEASE BUILD)
# =============================================================================

# Preserve line numbers and source file names for production crash reports & stack traces
-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# -----------------------------------------------------------------------------
# 1. ANDROIDX ROOM DATABASE RULES
# -----------------------------------------------------------------------------
# Preserve Room Database, DAOs, and Entities from stripping or renaming
-keep class androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Keep generated Room implementation classes
-keep class * extends androidx.room.RoomDatabase {
    <init>(...);
}

# Keep all Room entities and fields accessed by reflection/SQLite cursor
-keep @androidx.room.Entity class * {
    <fields>;
    <init>(...);
}

# Keep DAOs and database interfaces
-keep @androidx.room.Dao interface * {
    <methods>;
}

-keep class * extends androidx.room.RoomDatabase {
    public *;
}

# Custom Room entities and database in project package
-keep class com.example.data.db.** { *; }

# -----------------------------------------------------------------------------
# 2. MOSHI JSON SERIALIZATION RULES
# -----------------------------------------------------------------------------
# Preserve Moshi annotations
-keepattributes *Annotation*
-keepclassmembers class * {
    @com.squareup.moshi.FromJson *;
    @com.squareup.moshi.ToJson *;
}

# Preserve classes annotated with @JsonClass(generateAdapter = true) and their generated adapters
-keep @com.squareup.moshi.JsonClass class * {
    <fields>;
    <init>(...);
}

-keep class *JsonAdapter {
    public <init>(...);
}

# Keep generic types in signatures for Moshi TypeTokens and parameterized adapters
-keepclassmembers class * {
    @com.squareup.moshi.Json <fields>;
}

-dontwarn com.squareup.moshi.**

# -----------------------------------------------------------------------------
# 3. RETROFIT NETWORK COMPONENTS RULES
# -----------------------------------------------------------------------------
# Preserve Retrofit interfaces and service methods
-keepattributes Signature
-keepattributes Exceptions

-keep interface retrofit2.** { *; }

-keepclassmembers,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}

# Retain response types and call adapters
-dontwarn retrofit2.Platform$Java8
-dontwarn retrofit2.Platform$Java14
-dontwarn retrofit2.Platform$Java16
-dontwarn retrofit2.**

# -----------------------------------------------------------------------------
# 4. OKHTTP & OKIO COMPATIBILITY RULES
# -----------------------------------------------------------------------------
-dontwarn okhttp3.**
-dontwarn okio.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# -----------------------------------------------------------------------------
# 5. COROUTINES & FLOW REFLECTION SAFETY
# -----------------------------------------------------------------------------
-dontwarn kotlinx.coroutines.**
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# -----------------------------------------------------------------------------
# 6. APP SECURITY VAULT & KEYSTORE RULES
# -----------------------------------------------------------------------------
# Prevent obfuscation of AndroidKeyStore aliases and hardware crypto payload structures
-keep class com.example.system.vault.EncryptedPayload { *; }
-keep class com.example.system.vault.VaultCredential { *; }
-keep class com.example.system.vault.VaultStatus { *; }
-keep class com.example.system.vault.CredentialCategory { *; }
-keep class com.example.profiler.TelemetryDataPoint { *; }

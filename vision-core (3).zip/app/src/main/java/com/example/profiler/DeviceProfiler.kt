package com.example.profiler

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class RealDeviceProfile(
    val nodeId: String,
    val deviceModel: String,
    val manufacturer: String,
    val androidSdk: Int,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val freeRamMb: Long,
    val swapTotalMb: Long,
    val swapFreeMb: Long,
    val thermalCelsius: Float,
    val cpuCores: Int,
    val cpuArchitecture: String,
    val cpuUsagePercent: Int,
    val coreFrequenciesMhz: List<Int>,
    val recommendedModel: String,
    val recommendedContext: Int,
    val batteryMode: String,
    val rpcPort: Int,
    val timestamp: Long
)

data class TelemetryDataPoint(
    val timestamp: Long = System.currentTimeMillis(),
    val cpuPercent: Int,
    val ramUsedMb: Int,
    val ramTotalMb: Int,
    val thermalCelsius: Float
)

class DeviceProfiler(private val context: Context) {

    private val nodeIdFile = File(context.filesDir, ".vision_node_id")
    val nodeId: String by lazy {
        if (nodeIdFile.exists()) {
            nodeIdFile.readText().trim()
        } else {
            val id = "PKC-" + UUID.randomUUID().toString().take(8).uppercase()
            try {
                nodeIdFile.writeText(id)
            } catch (_: Exception) {}
            id
        }
    }

    private val _currentProfile = MutableStateFlow<RealDeviceProfile?>(null)
    val currentProfile: StateFlow<RealDeviceProfile?> = _currentProfile.asStateFlow()

    private val _telemetryHistory = MutableStateFlow<List<TelemetryDataPoint>>(emptyList())
    val telemetryHistory: StateFlow<List<TelemetryDataPoint>> = _telemetryHistory.asStateFlow()

    // For CPU percentage calculation via /proc/stat
    private var lastTotalJiffies = 0L
    private var lastIdleJiffies = 0L
    private var lastCpuPercent = 12

    init {
        sampleMetrics()
    }

    fun sampleMetrics(): RealDeviceProfile {
        // 1. Meminfo parsing directly from Linux kernel (/proc/meminfo)
        var memTotalKb = 0L
        var memFreeKb = 0L
        var memAvailableKb = 0L
        var swapTotalKb = 0L
        var swapFreeKb = 0L

        try {
            val meminfo = File("/proc/meminfo")
            if (meminfo.exists()) {
                meminfo.forEachLine { line ->
                    when {
                        line.startsWith("MemTotal:") -> memTotalKb = parseKb(line)
                        line.startsWith("MemFree:") -> memFreeKb = parseKb(line)
                        line.startsWith("MemAvailable:") -> memAvailableKb = parseKb(line)
                        line.startsWith("SwapTotal:") -> swapTotalKb = parseKb(line)
                        line.startsWith("SwapFree:") -> swapFreeKb = parseKb(line)
                    }
                }
            }
        } catch (_: Exception) {}

        // Fallback / validation with ActivityManager
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)

        val totalRamMb = if (memTotalKb > 0) memTotalKb / 1024 else (memInfo.totalMem / (1024 * 1024))
        val availRamMb = if (memAvailableKb > 0) memAvailableKb / 1024 else (memInfo.availMem / (1024 * 1024))
        val freeRamMb = if (memFreeKb > 0) memFreeKb / 1024 else availRamMb

        // 2. Real CPU Usage calculation from /proc/stat
        val cpuUsagePercent = calculateRealCpuUsage()

        // 3. Real Core Frequencies from /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq
        val coreFrequenciesMhz = readCoreFrequencies()

        // 4. Real Thermal zone query (/sys/class/thermal/thermal_zone*/temp)
        val thermalCelsius = readThermalZone()

        // 5. CPU Cores & Arch
        val cpuCores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val cpuArch = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"

        // 6. Autonomous Model Recommendation based on real RAM calculation
        val (recommendedModel, recommendedCtx) = when {
            availRamMb >= 7000 -> Pair("Llama 3.1 8B Q4_K_M (Cluster/Local High)", 8192)
            availRamMb >= 3800 -> Pair("DeepSeek R1 Distill 7B Q4_K_M (Equilibrado)", 4096)
            availRamMb >= 2200 -> Pair("Qwen 2.5 3B Instruct Q4_K_M (Standalone Recomendado)", 2048)
            else -> Pair("Phi-3.5 Mini 3.8B Q4_0 (Ahorro de Memoria)", 2048)
        }

        val batteryMode = when {
            thermalCelsius >= 45.0f -> "AHORRO (ALTA TEMP)"
            availRamMb >= 5000 -> "BESTIA"
            else -> "EQUILIBRADO"
        }

        val profile = RealDeviceProfile(
            nodeId = nodeId,
            deviceModel = Build.MODEL,
            manufacturer = Build.MANUFACTURER,
            androidSdk = Build.VERSION.SDK_INT,
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            freeRamMb = freeRamMb,
            swapTotalMb = swapTotalKb / 1024,
            swapFreeMb = swapFreeKb / 1024,
            thermalCelsius = thermalCelsius,
            cpuCores = cpuCores,
            cpuArchitecture = cpuArch,
            cpuUsagePercent = cpuUsagePercent,
            coreFrequenciesMhz = coreFrequenciesMhz,
            recommendedModel = recommendedModel,
            recommendedContext = recommendedCtx,
            batteryMode = batteryMode,
            rpcPort = 50052,
            timestamp = System.currentTimeMillis()
        )

        _currentProfile.value = profile
        writeNodeJson(profile)

        val usedRamMb = (totalRamMb - availRamMb).toInt().coerceAtLeast(256)
        val point = TelemetryDataPoint(
            timestamp = profile.timestamp,
            cpuPercent = cpuUsagePercent,
            ramUsedMb = usedRamMb,
            ramTotalMb = totalRamMb.toInt(),
            thermalCelsius = thermalCelsius
        )
        val list = _telemetryHistory.value.toMutableList()
        list.add(point)
        if (list.size > 30) {
            list.removeAt(0)
        }
        _telemetryHistory.value = list

        return profile
    }

    private fun calculateRealCpuUsage(): Int {
        try {
            val statFile = File("/proc/stat")
            if (statFile.exists() && statFile.canRead()) {
                val line = statFile.bufferedReader().use { it.readLine() }
                if (line != null && line.startsWith("cpu ")) {
                    val parts = line.trim().split("\\s+".toRegex()).drop(1).mapNotNull { it.toLongOrNull() }
                    if (parts.size >= 4) {
                        val user = parts[0]
                        val nice = parts[1]
                        val system = parts[2]
                        val idle = parts[3]
                        val iowait = if (parts.size > 4) parts[4] else 0L
                        val irq = if (parts.size > 5) parts[5] else 0L
                        val softirq = if (parts.size > 6) parts[6] else 0L

                        val currentTotal = user + nice + system + idle + iowait + irq + softirq
                        val currentIdle = idle + iowait

                        val deltaTotal = currentTotal - lastTotalJiffies
                        val deltaIdle = currentIdle - lastIdleJiffies

                        lastTotalJiffies = currentTotal
                        lastIdleJiffies = currentIdle

                        if (deltaTotal > 0) {
                            val active = deltaTotal - deltaIdle
                            val percent = ((active.toDouble() / deltaTotal) * 100).toInt().coerceIn(1, 100)
                            lastCpuPercent = percent
                            return percent
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return lastCpuPercent
    }

    private fun readCoreFrequencies(): List<Int> {
        val freqs = mutableListOf<Int>()
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        for (i in 0 until cores) {
            val freqFile = File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
            if (freqFile.exists() && freqFile.canRead()) {
                try {
                    val khz = freqFile.readText().trim().toIntOrNull() ?: 0
                    freqs.add(khz / 1000)
                } catch (_: Exception) {
                    freqs.add(0)
                }
            } else {
                freqs.add(0)
            }
        }
        return freqs
    }

    private fun readThermalZone(): Float {
        val thermalPaths = listOf(
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/thermal/thermal_zone1/temp",
            "/sys/devices/virtual/thermal/thermal_zone0/temp"
        )
        for (path in thermalPaths) {
            try {
                val f = File(path)
                if (f.exists() && f.canRead()) {
                    val raw = f.readText().trim().toLongOrNull() ?: continue
                    val deg = if (raw > 1000) raw / 1000f else raw.toFloat()
                    if (deg in 10f..110f) return deg
                }
            } catch (_: Exception) {}
        }
        return 38.0f // Nominal hardware baseline
    }

    private fun writeNodeJson(profile: RealDeviceProfile) {
        try {
            val json = JSONObject().apply {
                put("node_id", profile.nodeId)
                put("device_model", profile.deviceModel)
                put("manufacturer", profile.manufacturer)
                put("android_sdk", profile.androidSdk)
                put("total_ram_mb", profile.totalRamMb)
                put("avail_ram_mb", profile.availableRamMb)
                put("free_ram_mb", profile.freeRamMb)
                put("swap_total_mb", profile.swapTotalMb)
                put("thermal_celsius", profile.thermalCelsius)
                put("cpu_cores", profile.cpuCores)
                put("cpu_arch", profile.cpuArchitecture)
                put("cpu_usage_percent", profile.cpuUsagePercent)
                put("recommended_model", profile.recommendedModel)
                put("recommended_context", profile.recommendedContext)
                put("battery_mode", profile.batteryMode)
                put("rpc_port", profile.rpcPort)
                put("timestamp", profile.timestamp)
                put("iso_time", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date(profile.timestamp)))
            }

            // Save to internal storage node.json
            val nodeFile = File(context.filesDir, "node.json")
            nodeFile.writeText(json.toString(2))

            // Also mirror to ~/node.json in termux home if exists
            val homeDir = File(context.filesDir, "home")
            if (homeDir.exists()) {
                File(homeDir, "node.json").writeText(json.toString(2))
            }
        } catch (_: Exception) {}
    }

    private fun parseKb(line: String): Long {
        return try {
            line.substringAfter(":").replace("[^0-9]".toRegex(), "").toLong()
        } catch (_: Exception) {
            0L
        }
    }
}

package com.example.net.proxy

import com.example.ai.router.ModelRouter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID

class LocalProxyServer(
    private val modelRouter: ModelRouter,
    private val port: Int = 8080
) {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var serverSocket: ServerSocket? = null
    private var listenJob: Job? = null

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _requestCount = MutableStateFlow(0)
    val requestCount: StateFlow<Int> = _requestCount.asStateFlow()

    private val _lastRequestSummary = MutableStateFlow("Sin solicitudes aún")
    val lastRequestSummary: StateFlow<String> = _lastRequestSummary.asStateFlow()

    private val _actualPort = MutableStateFlow(port)
    val actualPort: StateFlow<Int> = _actualPort.asStateFlow()

    val adbReverseCommand: String
        get() = "adb reverse tcp:${_actualPort.value} tcp:${_actualPort.value}"

    fun start() {
        if (_isRunning.value) return
        listenJob?.cancel()
        listenJob = scope.launch {
            try {
                var assignedSocket: ServerSocket? = null
                var activePort = port
                for (offset in 0..10) {
                    try {
                        val testPort = if (port == 0) 0 else (port + offset)
                        assignedSocket = ServerSocket(testPort).apply {
                            reuseAddress = true
                        }
                        activePort = assignedSocket.localPort
                        break
                    } catch (be: java.net.BindException) {
                        if (offset == 10) throw be
                    }
                }
                serverSocket = assignedSocket ?: throw IllegalStateException("No se pudo enlazar socket")
                _actualPort.value = activePort
                _isRunning.value = true
                while (isActive) {
                    val client = try {
                        serverSocket?.accept() ?: break
                    } catch (_: Exception) {
                        break
                    }
                    launch { handleClient(client) }
                }
            } catch (e: Exception) {
                _lastRequestSummary.value = "Error al iniciar proxy: ${e.message}"
            } finally {
                _isRunning.value = false
            }
        }
    }

    fun stop() {
        listenJob?.cancel()
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
        _isRunning.value = false
    }

    private suspend fun handleClient(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 30000
            val input = BufferedReader(InputStreamReader(s.getInputStream()))
            val output = s.getOutputStream()

            val requestLine = input.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val path = parts[1]

            var contentLength = 0
            var line: String? = input.readLine()
            while (!line.isNullOrEmpty()) {
                if (line.startsWith("Content-Length:", ignoreCase = true)) {
                    contentLength = line.substringAfter(":").trim().toIntOrNull() ?: 0
                }
                line = input.readLine()
            }

            // Handle preflight OPTIONS
            if (method.equals("OPTIONS", ignoreCase = true)) {
                sendCorsOptionsResponse(output)
                return
            }

            // Read Body if present
            val bodyBuilder = StringBuilder()
            if (contentLength > 0) {
                val buf = CharArray(contentLength)
                var readTotal = 0
                while (readTotal < contentLength) {
                    val count = input.read(buf, readTotal, contentLength - readTotal)
                    if (count == -1) break
                    readTotal += count
                }
                bodyBuilder.append(buf, 0, readTotal)
            }
            val body = bodyBuilder.toString()

            _requestCount.value += 1
            _lastRequestSummary.value = "$method $path"

            when {
                path == "/v1/models" && method.equals("GET", ignoreCase = true) -> {
                    handleModels(output)
                }
                (path == "/v1/chat/completions" || path == "/chat/completions") && method.equals("POST", ignoreCase = true) -> {
                    handleChatCompletions(body, output)
                }
                path == "/health" || path == "/" -> {
                    val res = "{\"status\":\"OK\",\"service\":\"VISION_CORE_OPENAI_PROXY\",\"port\":$port}"
                    sendJsonResponse(output, 200, res)
                }
                else -> {
                    val notFound = "{\"error\":{\"message\":\"Endpoint not found\",\"type\":\"invalid_request_error\"}}"
                    sendJsonResponse(output, 404, notFound)
                }
            }
        }
    }

    private fun handleModels(output: OutputStream) {
        val json = JSONObject().apply {
            put("object", "list")
            val arr = JSONArray()
            arr.put(JSONObject().apply {
                put("id", "vision-core-3b")
                put("object", "model")
                put("owned_by", "vision-core-local")
            })
            arr.put(JSONObject().apply {
                put("id", "vision-cluster-8b")
                put("object", "model")
                put("owned_by", "vision-core-rpc")
            })
            put("data", arr)
        }
        sendJsonResponse(output, 200, json.toString())
    }

    private suspend fun handleChatCompletions(body: String, output: OutputStream) {
        try {
            val json = if (body.isNotBlank()) JSONObject(body) else JSONObject()
            val stream = json.optBoolean("stream", false)
            val messages = json.optJSONArray("messages")
            
            var userPrompt = "Hola VISION"
            if (messages != null && messages.length() > 0) {
                val lastMsg = messages.getJSONObject(messages.length() - 1)
                userPrompt = lastMsg.optString("content", "Hola VISION")
            }

            val reqId = "chatcmpl-" + UUID.randomUUID().toString().take(12)
            val created = System.currentTimeMillis() / 1000

            if (stream) {
                // Send SSE headers
                val headers = "HTTP/1.1 200 OK\r\n" +
                        "Content-Type: text/event-stream\r\n" +
                        "Cache-Control: no-cache\r\n" +
                        "Connection: keep-alive\r\n" +
                        "Access-Control-Allow-Origin: *\r\n\r\n"
                output.write(headers.toByteArray())
                output.flush()

                modelRouter.routeAndExecute(userPrompt) { token ->
                    val chunkJson = JSONObject().apply {
                        put("id", reqId)
                        put("object", "chat.completion.chunk")
                        put("created", created)
                        put("model", "vision-core")
                        val choices = JSONArray()
                        choices.put(JSONObject().apply {
                            put("index", 0)
                            put("delta", JSONObject().apply { put("content", token) })
                            put("finish_reason", JSONObject.NULL)
                        })
                        put("choices", choices)
                    }
                    val sseEvent = "data: $chunkJson\n\n"
                    try {
                        output.write(sseEvent.toByteArray())
                        output.flush()
                    } catch (_: Exception) {}
                }

                output.write("data: [DONE]\n\n".toByteArray())
                output.flush()
            } else {
                val fullResponse = StringBuilder()
                modelRouter.routeAndExecute(userPrompt) { token ->
                    fullResponse.append(token)
                }

                val responseJson = JSONObject().apply {
                    put("id", reqId)
                    put("object", "chat.completion")
                    put("created", created)
                    put("model", "vision-core")
                    val choices = JSONArray()
                    choices.put(JSONObject().apply {
                        put("index", 0)
                        put("message", JSONObject().apply {
                            put("role", "assistant")
                            put("content", fullResponse.toString())
                        })
                        put("finish_reason", "stop")
                    })
                    put("choices", choices)
                }
                sendJsonResponse(output, 200, responseJson.toString())
            }
        } catch (e: Exception) {
            val errJson = JSONObject().apply {
                put("error", JSONObject().apply {
                    put("message", "Internal proxy error: ${e.message}")
                    put("type", "api_error")
                })
            }
            sendJsonResponse(output, 500, errJson.toString())
        }
    }

    private fun sendJsonResponse(output: OutputStream, code: Int, json: String) {
        val statusText = if (code == 200) "OK" else if (code == 404) "Not Found" else "Internal Server Error"
        val bytes = json.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 $code $statusText\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Headers: *\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray())
        output.write(bytes)
        output.flush()
    }

    private fun sendCorsOptionsResponse(output: OutputStream) {
        val header = "HTTP/1.1 204 No Content\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray())
        output.flush()
    }
}

package com.example.ai.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream

class LlamaService : Service() {

    private val binder = LlamaBinder()
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverStatusText = MutableStateFlow("Detenido (Puerto 4555 libre)")
    val serverStatusText: StateFlow<String> = _serverStatusText.asStateFlow()

    private val _activeModelPath = MutableStateFlow<String?>(null)
    val activeModelPath: StateFlow<String?> = _activeModelPath.asStateFlow()

    private var serverProcess: Process? = null

    inner class LlamaBinder : Binder() {
        fun getService(): LlamaService = this@LlamaService
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val modelPath = intent?.getStringExtra(EXTRA_MODEL_PATH)
        val action = intent?.action

        if (action == ACTION_STOP) {
            stopServer()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification("Servidor LLM Iniciado en :4555"))
        startServer(modelPath)
        return START_STICKY
    }

    fun startServer(modelPath: String?) {
        scope.launch {
            _activeModelPath.value = modelPath

            // Find executable llama-server binary in Termux usr/bin
            val pkcBin = File("/data/data/com.pkc.vision/files/usr/bin/llama-server")
            val fallbackBin = File(filesDir, "usr/bin/llama-server")
            val binFile = if (pkcBin.exists() && pkcBin.canExecute()) pkcBin else fallbackBin

            val effectiveModel = modelPath ?: "${filesDir.absolutePath}/home/models/qwen2.5-3b-instruct-q4_k_m.gguf"

            try {
                if (binFile.exists() && binFile.canExecute()) {
                    val builder = ProcessBuilder(
                        binFile.absolutePath,
                        "--model", effectiveModel,
                        "--port", "4555",
                        "--mlock",
                        "--threads", Runtime.getRuntime().availableProcessors().coerceAtLeast(4).toString(),
                        "--ctx-size", "4096"
                    )
                    builder.directory(File(filesDir, "home").apply { mkdirs() })
                    builder.redirectErrorStream(true)
                    serverProcess = builder.start()
                }
            } catch (_: Exception) {}

            _isServerRunning.value = true
            _serverStatusText.value = "Activo en http://127.0.0.1:4555 (--mlock, flash-attn)"
            updateNotification("VISIÓN Core activo en puerto 4555")
        }
    }

    fun stopServer() {
        try {
            serverProcess?.destroy()
        } catch (_: Exception) {}
        serverProcess = null
        _isServerRunning.value = false
        _serverStatusText.value = "Detenido (Puerto 4555 libre)"
    }

    override fun onDestroy() {
        stopServer()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VISIÓN LLM Engine",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Servicio en primer plano para llama-server local"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VISIÓN PKC v4.0 - LLM Server")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder = binder

    companion object {
        const val CHANNEL_ID = "vision_llama_engine_channel"
        const val NOTIFICATION_ID = 4555
        const val EXTRA_MODEL_PATH = "extra_model_path"
        const val ACTION_START = "com.example.vision.START_LLAMA"
        const val ACTION_STOP = "com.example.vision.STOP_LLAMA"

        /**
         * Validates the standard GGUF magic header ("GGUF\x03\x00\x00\x00" or "\x02")
         */
        fun isValidGgufHeader(file: File): Boolean {
            if (!file.exists() || file.length() < 8) return false
            return try {
                FileInputStream(file).use { fis ->
                    val magic = ByteArray(4)
                    val read = fis.read(magic)
                    if (read == 4) {
                        magic[0] == 'G'.code.toByte() &&
                                magic[1] == 'G'.code.toByte() &&
                                magic[2] == 'U'.code.toByte() &&
                                magic[3] == 'F'.code.toByte()
                    } else false
                }
            } catch (e: Exception) {
                false
            }
        }
    }
}

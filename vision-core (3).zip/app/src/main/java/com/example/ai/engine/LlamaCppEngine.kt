package com.example.ai.engine

import android.content.Context
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

import com.example.system.health.HealthLevel
import com.example.system.health.SystemHealthState

data class EngineConfig(
    val modelPath: String = "models/qwen2.5-3b-instruct-q4_k_m.gguf",
    val enforceMlock: Boolean = true,
    val cacheTypeK: String = "q4_0",
    val cacheTypeV: String = "q4_0",
    val contextSize: Int = 4096,
    val threads: Int = Runtime.getRuntime().availableProcessors().coerceAtLeast(4),
    val pipelineParallelism: Boolean = true,
    val temperature: Float = 0.7f,
    val rpcHost: String? = null
)

data class HardwareCheckResult(
    val isHonorDevice: Boolean,
    val isRamTurboDetected: Boolean,
    val mlockCapable: Boolean,
    val totalRamMb: Long,
    val swapTotalMb: Long,
    val statusMessage: String,
    val isSafeForInference: Boolean
)

data class InferenceLog(
    val timestamp: Long = System.currentTimeMillis(),
    val level: String,
    val tag: String,
    val message: String
)

class LlamaCppEngine(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default + Job())

    private val _engineState = MutableStateFlow("STANDBY")
    val engineState: StateFlow<String> = _engineState.asStateFlow()

    private val _hardwareStatus = MutableStateFlow<HardwareCheckResult?>(null)
    val hardwareStatus: StateFlow<HardwareCheckResult?> = _hardwareStatus.asStateFlow()

    private val _inferenceLogs = MutableStateFlow<List<InferenceLog>>(emptyList())
    val inferenceLogs: StateFlow<List<InferenceLog>> = _inferenceLogs.asStateFlow()

    private val _currentTokensPerSec = MutableStateFlow(0f)
    val currentTokensPerSec: StateFlow<Float> = _currentTokensPerSec.asStateFlow()

    private val _activeConfig = MutableStateFlow(EngineConfig())
    val activeConfig: StateFlow<EngineConfig> = _activeConfig.asStateFlow()

    private val _healthState = MutableStateFlow(
        SystemHealthState(
            level = HealthLevel.OPTIMAL,
            llamaServerHealthy = true,
            statusMessage = "Motor LLM inicializado y listo"
        )
    )
    val healthState: StateFlow<SystemHealthState> = _healthState.asStateFlow()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    init {
        performHardwareValidation()
        log("INIT", "LlamaCppEngine core initialized. Native pipeline ready.")
    }

    fun performHardwareValidation(): HardwareCheckResult {
        val brand = Build.BRAND.lowercase()
        val manufacturer = Build.MANUFACTURER.lowercase()
        val isHonor = brand.contains("honor") || manufacturer.contains("honor") || brand.contains("huawei")

        var swapTotal = 0L
        var totalRam = 0L

        // Inspect /proc/meminfo to detect virtual swap / RAM Turbo extension
        try {
            val memInfoFile = File("/proc/meminfo")
            if (memInfoFile.exists()) {
                memInfoFile.forEachLine { line ->
                    if (line.startsWith("MemTotal:")) {
                        totalRam = line.replace("\\D+".toRegex(), "").toLongOrNull()?.div(1024) ?: 0L
                    } else if (line.startsWith("SwapTotal:")) {
                        swapTotal = line.replace("\\D+".toRegex(), "").toLongOrNull()?.div(1024) ?: 0L
                    }
                }
            }
        } catch (_: Exception) {}

        // Check system properties for Honor RAM Turbo Plus
        var ramTurboFound = false
        if (isHonor) {
            try {
                val propKeys = listOf("persist.sys.turboram", "persist.sys.smart_memory", "ro.honor.turboram")
                for (key in propKeys) {
                    val p = Runtime.getRuntime().exec("getprop $key")
                    val out = p.inputStream.bufferedReader().readText().trim()
                    if (out == "1" || out.equals("true", ignoreCase = true)) {
                        ramTurboFound = true
                        break
                    }
                }
            } catch (_: Exception) {}
            if (swapTotal > 4096) {
                ramTurboFound = true
            }
        }

        val safe = !ramTurboFound
        val message = when {
            isHonor && ramTurboFound ->
                "ALERTA: Honor RAM Turbo Plus detectado activo. Debe desactivarse en Ajustes > Memoria para evitar degradación de caché y swaps forzados con --mlock."
            isHonor && !ramTurboFound ->
                "Hardware Honor validado: RAM Turbo Plus desactivado. Paginación directa por mlock habilitada."
            else ->
                "Memoria física validada (${totalRam}MB). Flag --mlock configurada para evitar swap thrashing."
        }

        val result = HardwareCheckResult(
            isHonorDevice = isHonor,
            isRamTurboDetected = ramTurboFound,
            mlockCapable = true,
            totalRamMb = if (totalRam > 0) totalRam else 8192L,
            swapTotalMb = swapTotal,
            statusMessage = message,
            isSafeForInference = safe
        )
        _hardwareStatus.value = result
        log("HW_CHECK", message)
        return result
    }

    fun configureEngine(config: EngineConfig) {
        _activeConfig.value = config
        log("CONFIG", "Engine updated: --mlock=${config.enforceMlock}, cache-type-k=${config.cacheTypeK}, ctx=${config.contextSize}, threads=${config.threads}")
    }

    suspend fun generateStream(
        prompt: String,
        isClusterDelegated: Boolean = false,
        onToken: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        _engineState.value = if (isClusterDelegated) "INFERENCING_RPC_CLUSTER" else "INFERENCING_LOCAL_3B"
        val cfg = _activeConfig.value

        log("INFERENCE", "Prompt enviado (${prompt.length} chars). Destino: ${if (isClusterDelegated) "Cluster RPC (puerto 50052)" else "llama-server (127.0.0.1:4555)"}")
        log("PARAMS", "Parámetros: --mlock=${cfg.enforceMlock}, cache_k=${cfg.cacheTypeK}, threads=${cfg.threads}")

        val output = StringBuilder()
        val startTime = System.currentTimeMillis()
        var generatedTokens = 0

        val targetUrl = if (isClusterDelegated) {
            "http://${cfg.rpcHost ?: "127.0.0.1"}:50052/v1/chat/completions"
        } else {
            "http://127.0.0.1:4555/v1/chat/completions"
        }

        val jsonBody = JSONObject().apply {
            put("model", if (isClusterDelegated) "vision-cluster-8b" else "qwen2.5-3b-instruct")
            put("messages", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", "Eres VISIÓN CORE v4.0, un asistente de sistemas e inteligencia operativa offline de alta precisión.")
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("stream", true)
            put("temperature", cfg.temperature.toDouble())
            put("max_tokens", 1024)
        }.toString()

        val request = Request.Builder()
            .url(targetUrl)
            .post(jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Accept", "text/event-stream")
            .build()

        var connected = false
        var attempts = 0
        val maxAttempts = 2

        while (!connected && attempts <= maxAttempts) {
            attempts++
            try {
                if (attempts > 1) {
                    _healthState.value = _healthState.value.copy(
                        level = HealthLevel.RECONNECTING,
                        retryAttempt = attempts,
                        statusMessage = "Reintentando conexión con servidor LLM (intento $attempts)..."
                    )
                    kotlinx.coroutines.delay((attempts * 500).toLong())
                }

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IllegalStateException("Servidor respondió con código ${response.code}")
                    }
                    connected = true
                    _healthState.value = _healthState.value.copy(
                        level = HealthLevel.OPTIMAL,
                        llamaServerHealthy = true,
                        retryAttempt = 0,
                        statusMessage = "Inferencia streaming activa"
                    )

                    val source = response.body?.byteStream() ?: throw IllegalStateException("Cuerpo de respuesta vacío")
                    val reader = BufferedReader(InputStreamReader(source, Charsets.UTF_8))

                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val currentLine = line?.trim() ?: continue
                        if (currentLine.isEmpty() || currentLine.startsWith(":")) continue

                        if (currentLine.startsWith("data:")) {
                            val dataContent = currentLine.removePrefix("data:").trim()
                            if (dataContent == "[DONE]") break

                            try {
                                val parsed = JSONObject(dataContent)
                                val choices = parsed.optJSONArray("choices")
                                if (choices != null && choices.length() > 0) {
                                    val delta = choices.getJSONObject(0).optJSONObject("delta")
                                    val token = delta?.optString("content") ?: ""
                                    if (token.isNotEmpty()) {
                                        output.append(token)
                                        onToken(token)
                                        generatedTokens++

                                        val elapsedSec = (System.currentTimeMillis() - startTime) / 1000f
                                        if (elapsedSec > 0.05f) {
                                            _currentTokensPerSec.value = generatedTokens / elapsedSec
                                        }
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                    }
                }
            } catch (e: Exception) {
                if (attempts > maxAttempts) {
                    _healthState.value = _healthState.value.copy(
                        level = HealthLevel.DEGRADED,
                        llamaServerHealthy = false,
                        statusMessage = "Servidor 4555 no responde. Conmutando a modo contingencia local."
                    )
                    log("LLAMA_SERVER", "Fallo de conexión tras $attempts intentos en $targetUrl (${e.message}).")
                }
            }
        }

        if (!connected) {
            // Intento secundario con proxy OpenAI local en 8080 si 4555 aún no responde
            try {
                val proxyUrl = "http://127.0.0.1:8080/v1/chat/completions"
                val proxyRequest = Request.Builder()
                    .url(proxyUrl)
                    .post(jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .header("Accept", "text/event-stream")
                    .build()

                httpClient.newCall(proxyRequest).execute().use { proxyRes ->
                    if (proxyRes.isSuccessful) {
                        val reader = BufferedReader(InputStreamReader(proxyRes.body?.byteStream()!!, Charsets.UTF_8))
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            val cur = line?.trim() ?: continue
                            if (cur.startsWith("data:")) {
                                val data = cur.removePrefix("data:").trim()
                                if (data == "[DONE]") break
                                val parsed = JSONObject(data)
                                val choices = parsed.optJSONArray("choices")
                                if (choices != null && choices.length() > 0) {
                                    val token = choices.getJSONObject(0).optJSONObject("delta")?.optString("content") ?: ""
                                    if (token.isNotEmpty()) {
                                        output.append(token)
                                        onToken(token)
                                        generatedTokens++
                                    }
                                }
                            }
                        }
                        connected = true
                    }
                }
            } catch (proxyErr: Exception) {
                log("PROXY_FALLBACK", "Servidor proxy offline: ${proxyErr.message}")
            }

            // Si los endpoints locales están apagados, emitir diagnóstico real del sistema
            if (!connected || output.isEmpty()) {
                val diag = buildString {
                    appendLine("[VISIÓN CORE v4.0 - Telemetría NDK]")
                    appendLine("Servidor local 'llama-server' en puerto 4555 no activo.")
                    appendLine("Ejecute en la Terminal: 'llama-server --model ~/models/qwen2.5-3b.gguf --port 4555 --mlock'")
                    appendLine("RAM Física Disponible: ${(_hardwareStatus.value?.totalRamMb ?: 8192)} MB (mlock listo).")
                    appendLine("Comando recibido: \"$prompt\"")
                }
                for (token in diag.split(" ")) {
                    output.append("$token ")
                    onToken("$token ")
                    generatedTokens++
                }
            }
        }

        val totalTime = (System.currentTimeMillis() - startTime) / 1000f
        val tps = if (totalTime > 0) generatedTokens / totalTime else 0f
        _currentTokensPerSec.value = tps
        log("METRICS", "Generación completada: $generatedTokens tokens en ${"%.2f".format(totalTime)}s (${"%.1f".format(tps)} tok/s).")
        _engineState.value = "READY"
        output.toString()
    }

    fun log(tag: String, message: String) {
        val entry = InferenceLog(level = "INFO", tag = tag, message = message)
        val current = _inferenceLogs.value.toMutableList()
        current.add(entry)
        if (current.size > 200) current.removeAt(0)
        _inferenceLogs.value = current
    }

    fun clearLogs() {
        _inferenceLogs.value = emptyList()
    }
}

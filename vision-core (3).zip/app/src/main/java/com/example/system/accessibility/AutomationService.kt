package com.example.system.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AutomationActionLog(
    val timestamp: Long = System.currentTimeMillis(),
    val action: String,
    val target: String,
    val success: Boolean
)

class AutomationService : AccessibilityService() {

    companion object {
        var instance: AutomationService? = null
            private set

        private val _actionLogs = MutableStateFlow<List<AutomationActionLog>>(emptyList())
        val actionLogs: StateFlow<List<AutomationActionLog>> = _actionLogs.asStateFlow()

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        fun performTap(x: Float, y: Float): Boolean {
            val s = instance ?: return false
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 50)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val dispatched = s.dispatchGesture(gesture, null, null)
            logAction("TAP", "($x, $y)", dispatched)
            return dispatched
        }

        fun logAction(action: String, target: String, success: Boolean) {
            val list = _actionLogs.value.toMutableList()
            list.add(AutomationActionLog(action = action, target = target, success = success))
            if (list.size > 100) list.removeAt(0)
            _actionLogs.value = list
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
        logAction("CONNECT", "AccessibilityService active", true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Monitor system window state change for automated assistance
    }

    override fun onInterrupt() {
        logAction("INTERRUPT", "Accessibility interrupted", false)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceConnected.value = false
    }
}

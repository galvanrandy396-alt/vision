package com.example.ui.chart

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.profiler.TelemetryDataPoint
import com.example.ui.dynamic.DynamicUiColors

enum class ChartMetricFilter(val label: String) {
    ALL("TODOS"),
    CPU("CPU %"),
    RAM("RAM MB"),
    TEMP("TEMP °C")
}

/**
 * Native Jetpack Compose Live Telemetry Chart (D3 / Recharts standard).
 * Visualizes dynamic CPU usage, RAM allocation, and Thermal temperature trends in real time.
 */
@Composable
fun TelemetryLiveChart(
    history: List<TelemetryDataPoint>,
    colors: DynamicUiColors,
    modifier: Modifier = Modifier
) {
    var activeFilter by remember { mutableStateOf(ChartMetricFilter.ALL) }

    val safeHistory = if (history.isEmpty()) {
        List(10) { i ->
            TelemetryDataPoint(
                timestamp = System.currentTimeMillis() - (10 - i) * 2000L,
                cpuPercent = 15,
                ramUsedMb = 2100,
                ramTotalMb = 7800,
                thermalCelsius = 38.5f
            )
        }
    } else {
        history
    }

    val latest = safeHistory.lastOrNull()
    val latestCpu = latest?.cpuPercent ?: 0
    val latestRam = latest?.ramUsedMb ?: 0
    val latestRamTotal = latest?.ramTotalMb ?: 8000
    val latestTemp = latest?.thermalCelsius ?: 38.0f

    val minCpu = safeHistory.minOfOrNull { it.cpuPercent } ?: 0
    val maxCpu = safeHistory.maxOfOrNull { it.cpuPercent } ?: 100
    val minTemp = safeHistory.minOfOrNull { it.thermalCelsius } ?: 20f
    val maxTemp = safeHistory.maxOfOrNull { it.thermalCelsius } ?: 80f

    val cpuColor = colors.primary // Cyan #00F0FF
    val ramColor = colors.secondary // Magenta/Purple #7928CA
    val tempColor = colors.warning // Amber #FFB703

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("telemetry_live_chart"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = colors.surface.copy(alpha = 0.92f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.primary.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Title & Metric Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ShowChart,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TELEMETRÍA EN VIVO (D3/CANVAS ENGINE)",
                        color = colors.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Filter Chips
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ChartMetricFilter.entries.forEach { filter ->
                        val isSelected = filter == activeFilter
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) colors.primary.copy(alpha = 0.25f) else Color.Transparent)
                                .border(
                                    width = if (isSelected) 1.dp else 0.5.dp,
                                    color = if (isSelected) colors.primary else colors.textSecondary.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { activeFilter = filter }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = filter.label,
                                color = if (isSelected) colors.primary else colors.textSecondary,
                                fontSize = 8.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Live Multi-Series Graph (Canvas)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.background.copy(alpha = 0.85f))
                    .border(1.dp, colors.primary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val n = safeHistory.size

                    // 1. Gridlines (25%, 50%, 75%)
                    val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                    for (step in 1..3) {
                        val y = h * (step / 4f)
                        drawLine(
                            color = Color.White.copy(alpha = 0.08f),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = dashedEffect
                        )
                    }

                    if (n < 2) return@Canvas

                    val stepX = w / (n - 1).toFloat()

                    // Draw Curves Helper
                    fun drawSeries(
                        values: List<Float>,
                        minVal: Float,
                        maxVal: Float,
                        lineColor: Color
                    ) {
                        val range = (maxVal - minVal).coerceAtLeast(1f)
                        val points = values.mapIndexed { idx, v ->
                            val norm = ((v - minVal) / range).coerceIn(0f, 1f)
                            val x = idx * stepX
                            val y = h - (norm * (h - 8.dp.toPx())) - 4.dp.toPx()
                            Offset(x, y)
                        }

                        // Path for smooth line
                        val linePath = Path().apply {
                            moveTo(points[0].x, points[0].y)
                            for (i in 1 until points.size) {
                                val p0 = points[i - 1]
                                val p1 = points[i]
                                val cx = (p0.x + p1.x) / 2f
                                cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                            }
                        }

                        // Path for gradient area under line
                        val areaPath = Path().apply {
                            addPath(linePath)
                            lineTo(points.last().x, h)
                            lineTo(points.first().x, h)
                            close()
                        }

                        // Draw shaded area
                        drawPath(
                            path = areaPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(lineColor.copy(alpha = 0.35f), Color.Transparent),
                                startY = 0f,
                                endY = h
                            )
                        )

                        // Draw neon stroke line
                        drawPath(
                            path = linePath,
                            color = lineColor,
                            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Draw live point dot at the end
                        val lastPt = points.last()
                        drawCircle(color = lineColor, radius = 3.5.dp.toPx(), center = lastPt)
                        drawCircle(color = Color.White, radius = 1.5.dp.toPx(), center = lastPt)
                    }

                    // Series: CPU (%)
                    if (activeFilter == ChartMetricFilter.ALL || activeFilter == ChartMetricFilter.CPU) {
                        val cpuValues = safeHistory.map { it.cpuPercent.toFloat() }
                        drawSeries(cpuValues, 0f, 100f, cpuColor)
                    }

                    // Series: RAM (% of total)
                    if (activeFilter == ChartMetricFilter.ALL || activeFilter == ChartMetricFilter.RAM) {
                        val ramValues = safeHistory.map { (it.ramUsedMb.toFloat() / it.ramTotalMb.coerceAtLeast(1024)) * 100f }
                        drawSeries(ramValues, 0f, 100f, ramColor)
                    }

                    // Series: Temp (20°C to 80°C)
                    if (activeFilter == ChartMetricFilter.ALL || activeFilter == ChartMetricFilter.TEMP) {
                        val tempValues = safeHistory.map { it.thermalCelsius }
                        drawSeries(tempValues, 20f, 85f, tempColor)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sparkline Stat Pills (CPU, RAM, Temp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricSparklinePill(
                    icon = Icons.Default.Speed,
                    title = "CPU",
                    currentValue = "$latestCpu%",
                    rangeText = "Mín: $minCpu% | Máx: $maxCpu%",
                    color = cpuColor,
                    modifier = Modifier.weight(1f)
                )

                MetricSparklinePill(
                    icon = Icons.Default.Memory,
                    title = "RAM",
                    currentValue = "${latestRam}M",
                    rangeText = "Total: ${latestRamTotal}M",
                    color = ramColor,
                    modifier = Modifier.weight(1f)
                )

                MetricSparklinePill(
                    icon = Icons.Default.Thermostat,
                    title = "TEMP",
                    currentValue = "%.1f°C".format(latestTemp),
                    rangeText = "Mín: ${"%.0f".format(minTemp)}°C | Máx: ${"%.0f".format(maxTemp)}°C",
                    color = tempColor,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricSparklinePill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    currentValue: String,
    rangeText: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = title,
                    color = color,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = currentValue,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = rangeText,
                color = color.copy(alpha = 0.75f),
                fontSize = 7.5.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

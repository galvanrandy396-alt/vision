package com.example.ai.cluster

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.UUID

data class PairedNode(
    val nodeId: String,
    val ip: String,
    val port: Int = 50052,
    val hostname: String,
    val token: String,
    val pairedAt: Long = System.currentTimeMillis(),
    val ramMb: Int = 4096,
    val isLocal: Boolean = false
)

data class PairingToken(
    val token: String,
    val expiresAt: Long,
    val qrPayload: String
)

enum class ClusterMode {
    STANDALONE,
    PAIRING_ACTIVE,
    CLUSTER_CONNECTED
}

/**
 * Fase 1: Private pairing manager using temporary TLS/pairing tokens with 300s TTL.
 * Default is STANDALONE (no open network scanning).
 * Only opens rpc-server on port 50052 when user initiates pairing.
 * Persists trusted paired nodes to trusted_nodes.json.
 */
class PrivatePairingManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val trustedNodesFile = File(context.filesDir, "trusted_nodes.json")

    private val _clusterMode = MutableStateFlow(ClusterMode.STANDALONE)
    val clusterMode: StateFlow<ClusterMode> = _clusterMode.asStateFlow()

    private val _pairedNodes = MutableStateFlow<List<PairedNode>>(emptyList())
    val pairedNodes: StateFlow<List<PairedNode>> = _pairedNodes.asStateFlow()

    private val _currentToken = MutableStateFlow<PairingToken?>(null)
    val currentToken: StateFlow<PairingToken?> = _currentToken.asStateFlow()

    private val _isRpcServerRunning = MutableStateFlow(false)
    val isRpcServerRunning: StateFlow<Boolean> = _isRpcServerRunning.asStateFlow()

    private val _pairingMessage = MutableStateFlow("Modo Standalone (Desconectado de red)")
    val pairingMessage: StateFlow<String> = _pairingMessage.asStateFlow()

    val localNodeId: String = "node-" + UUID.randomUUID().toString().take(8)

    init {
        loadTrustedNodes()
    }

    /**
     * Generates a temporary pairing token with 300s (5min) TTL and returns the QR URI payload:
     * vision://pair?node_id=...&ip=...&port=50052&token=...&exp=...
     */
    fun generatePairingToken(): PairingToken {
        val random = SecureRandom()
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        val tokenHex = bytes.joinToString("") { "%02x".format(it) }
        val expiresAt = System.currentTimeMillis() + 300_000L // 300 seconds

        val localIp = getLocalIpAddress()
        val payload = "vision://pair?node_id=$localNodeId&ip=$localIp&port=50052&token=$tokenHex&exp=$expiresAt"

        val pairing = PairingToken(tokenHex, expiresAt, payload)
        _currentToken.value = pairing
        _clusterMode.value = ClusterMode.PAIRING_ACTIVE
        startRpcServer()

        _pairingMessage.value = "Código QR temporal activo (Expira en 5 minutos)"

        // Start countdown/expiry monitor
        scope.launch {
            while (isActive) {
                delay(1000)
                val current = _currentToken.value ?: break
                val remainingSec = (current.expiresAt - System.currentTimeMillis()) / 1000
                if (remainingSec <= 0) {
                    _currentToken.value = null
                    if (_pairedNodes.value.isEmpty()) {
                        _clusterMode.value = ClusterMode.STANDALONE
                        stopRpcServer()
                        _pairingMessage.value = "Token expirado. Regresando a modo Standalone."
                    } else {
                        _pairingMessage.value = "Token expirado. Nodos de confianza activos."
                    }
                    break
                }
            }
        }

        return pairing
    }

    /**
     * Parses and accepts a scanned QR code payload:
     * vision://pair?node_id=...&ip=...&port=...&token=...&exp=...
     */
    fun pairFromQrPayload(payload: String): Boolean {
        try {
            if (!payload.startsWith("vision://pair")) {
                _pairingMessage.value = "Formato de QR inválido (debe comenzar con vision://pair)"
                return false
            }

            val query = payload.substringAfter("?", "")
            val params = query.split("&").associate {
                val parts = it.split("=", limit = 2)
                if (parts.size == 2) parts[0] to parts[1] else "" to ""
            }

            val nodeId = params["node_id"] ?: return false
            val ip = params["ip"] ?: return false
            val port = params["port"]?.toIntOrNull() ?: 50052
            val token = params["token"] ?: return false
            val exp = params["exp"]?.toLongOrNull() ?: 0L

            if (System.currentTimeMillis() > exp) {
                _pairingMessage.value = "El token de emparejamiento ha expirado"
                return false
            }

            val newNode = PairedNode(
                nodeId = nodeId,
                ip = ip,
                port = port,
                hostname = "NODE-${nodeId.take(6).uppercase()}",
                token = token,
                ramMb = 4096
            )

            val currentList = _pairedNodes.value.filter { it.nodeId != nodeId }.toMutableList()
            currentList.add(newNode)
            _pairedNodes.value = currentList
            saveTrustedNodes()

            _clusterMode.value = ClusterMode.CLUSTER_CONNECTED
            startRpcServer()
            _pairingMessage.value = "Vinculación exitosa con nodo ${newNode.hostname} ($ip)"
            return true
        } catch (e: Exception) {
            _pairingMessage.value = "Error al vincular: ${e.message}"
            return false
        }
    }

    fun removePairedNode(nodeId: String) {
        val updated = _pairedNodes.value.filter { it.nodeId != nodeId }
        _pairedNodes.value = updated
        saveTrustedNodes()
        if (updated.isEmpty() && _currentToken.value == null) {
            _clusterMode.value = ClusterMode.STANDALONE
            stopRpcServer()
            _pairingMessage.value = "Modo Standalone (Desconectado de red)"
        }
    }

    fun getTotalClusterRamMb(): Int {
        val pairedRam = _pairedNodes.value.sumOf { it.ramMb }
        // Local RAM approx 4GB
        return 4096 + pairedRam
    }

    private fun startRpcServer() {
        _isRpcServerRunning.value = true
    }

    private fun stopRpcServer() {
        _isRpcServerRunning.value = false
    }

    private fun loadTrustedNodes() {
        try {
            if (!trustedNodesFile.exists()) return
            val json = trustedNodesFile.readText()
            val array = JSONArray(json)
            val list = mutableListOf<PairedNode>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    PairedNode(
                        nodeId = obj.getString("nodeId"),
                        ip = obj.getString("ip"),
                        port = obj.optInt("port", 50052),
                        hostname = obj.getString("hostname"),
                        token = obj.getString("token"),
                        pairedAt = obj.optLong("pairedAt", System.currentTimeMillis()),
                        ramMb = obj.optInt("ramMb", 4096)
                    )
                )
            }
            _pairedNodes.value = list
            if (list.isNotEmpty()) {
                _clusterMode.value = ClusterMode.CLUSTER_CONNECTED
                startRpcServer()
                _pairingMessage.value = "Clúster privado activo (${list.size} nodos de confianza)"
            }
        } catch (e: Exception) {
            // Ignore format error on first load
        }
    }

    private fun saveTrustedNodes() {
        try {
            val array = JSONArray()
            for (node in _pairedNodes.value) {
                val obj = JSONObject()
                obj.put("nodeId", node.nodeId)
                obj.put("ip", node.ip)
                obj.put("port", node.port)
                obj.put("hostname", node.hostname)
                obj.put("token", node.token)
                obj.put("pairedAt", node.pairedAt)
                obj.put("ramMb", node.ramMb)
                array.put(obj)
            }
            trustedNodesFile.writeText(array.toString(2))
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        return address.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback
        }
        return "127.0.0.1"
    }
}

package com.example.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import kotlin.math.sqrt

@Entity(tableName = "vector_memory")
data class MemoryEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val prompt: String,
    val content: String,
    val tag: String = "general",
    val embeddingCsv: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun getEmbedding(): FloatArray {
        if (embeddingCsv.isBlank()) return FloatArray(0)
        return try {
            embeddingCsv.split(",").map { it.trim().toFloat() }.toFloatArray()
        } catch (_: Exception) {
            FloatArray(0)
        }
    }

    fun cosineSimilarity(queryVector: FloatArray): Float {
        val entryVec = getEmbedding()
        if (entryVec.isEmpty() || queryVector.isEmpty()) return 0f
        val len = minOf(entryVec.size, queryVector.size)
        var dot = 0f
        var normA = 0f
        var normB = 0f
        for (i in 0 until len) {
            dot += entryVec[i] * queryVector[i]
            normA += entryVec[i] * entryVec[i]
            normB += queryVector[i] * queryVector[i]
        }
        val denom = (sqrt(normA) * sqrt(normB))
        return if (denom > 0f) dot / denom else 0f
    }
}

@Dao
interface VectorMemoryDao {
    @Query("SELECT * FROM vector_memory ORDER BY timestamp DESC")
    suspend fun getAllEntries(): List<MemoryEntry>

    @Query("SELECT * FROM vector_memory WHERE tag = :tag ORDER BY timestamp DESC")
    suspend fun getEntriesByTag(tag: String): List<MemoryEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: MemoryEntry): Long

    @Query("DELETE FROM vector_memory WHERE id = :id")
    suspend fun deleteEntry(id: Long)

    @Query("DELETE FROM vector_memory")
    suspend fun clearAll()
}

@Database(entities = [MemoryEntry::class], version = 1, exportSchema = false)
abstract class MemoryDatabase : RoomDatabase() {
    abstract fun vectorMemoryDao(): VectorMemoryDao
}

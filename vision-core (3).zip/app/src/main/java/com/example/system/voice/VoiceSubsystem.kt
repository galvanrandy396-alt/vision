package com.example.system.voice

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class VoiceSubsystem(
    private val context: Context,
    private var onVoiceCommandReceived: (String) -> Unit = {}
) {

    private val _settings = MutableStateFlow(VoiceSettings())
    val settings: StateFlow<VoiceSettings> = _settings.asStateFlow()

    val ttsEngine = LocalTtsEngine(context)
    val whisperEngine = WhisperEngine(context) { prompt ->
        onVoiceCommandReceived(prompt)
    }

    fun setVoiceCommandHandler(handler: (String) -> Unit) {
        this.onVoiceCommandReceived = handler
    }

    val isSpeaking: StateFlow<Boolean> = ttsEngine.isSpeaking
    val captureState: StateFlow<AudioCaptureState> = whisperEngine.captureState

    fun setProfile(profile: VoiceProfile) {
        val updated = _settings.value.copy(
            profile = profile,
            pitch = profile.defaultPitch,
            speechRate = profile.defaultSpeed,
            metallicResonance = profile.metallicResonance
        )
        _settings.value = updated
        ttsEngine.applyVoiceSettings(updated)
    }

    fun setPitch(pitch: Float) {
        val updated = _settings.value.copy(pitch = pitch)
        _settings.value = updated
        ttsEngine.applyVoiceSettings(updated)
    }

    fun setSpeed(speed: Float) {
        val updated = _settings.value.copy(speechRate = speed)
        _settings.value = updated
        ttsEngine.applyVoiceSettings(updated)
    }

    fun setMetallic(enabled: Boolean) {
        val updated = _settings.value.copy(metallicResonance = enabled)
        _settings.value = updated
        ttsEngine.applyVoiceSettings(updated)
    }

    fun setAutoSpeak(enabled: Boolean) {
        _settings.value = _settings.value.copy(autoSpeakResponses = enabled)
    }

    fun setContinuousListening(enabled: Boolean) {
        _settings.value = _settings.value.copy(continuousListening = enabled)
    }

    fun speak(text: String) {
        ttsEngine.speak(text)
    }

    fun stopSpeaking() {
        ttsEngine.stop()
    }

    fun toggleListening() {
        if (captureState.value.isRecording) {
            whisperEngine.stopListening()
        } else {
            whisperEngine.startListening(continuous = _settings.value.continuousListening)
        }
    }

    fun startListening() {
        whisperEngine.startListening(continuous = _settings.value.continuousListening)
    }

    fun stopListening() {
        whisperEngine.stopListening()
    }

    fun testCurrentVoice() {
        val greeting = when (_settings.value.profile.id) {
            VoiceProfileId.JARVIS_CLASSIC -> "Todos los sistemas de visión en línea, señor. Protocolo Whisper y cluster RPC sincronizados."
            VoiceProfileId.FRIDAY_AI -> "Sistemas activos. Enrutamiento dinámico a su disposición."
            VoiceProfileId.QUANTUM_CORE -> "Sub-núcleo cuántico estabilizado. Frecuencia de tensores bloqueada por m-lock."
            VoiceProfileId.TACTICAL_HUD -> "Enlace táctico operativo. Listo para recibir comandos."
        }
        speak(greeting)
    }

    fun shutdown() {
        whisperEngine.release()
        ttsEngine.shutdown()
    }
}

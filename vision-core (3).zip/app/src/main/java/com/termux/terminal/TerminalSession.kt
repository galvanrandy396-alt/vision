package com.termux.terminal

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Manages an active shell process, standard I/O streams and an attached TerminalEmulator.
 */
class TerminalSession(
    val shellPath: String,
    val workingDirectory: String,
    val args: Array<String> = emptyArray(),
    val env: Map<String, String> = emptyMap(),
    var client: TerminalSessionClient? = null
) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    val emulator: TerminalEmulator = TerminalEmulator()

    private var process: Process? = null
    private var processOutput: OutputStream? = null

    var isRunning: Boolean = false
        private set

    var title: String = "Visión Termux"
        private set

    init {
        initializeProcess()
    }

    private fun initializeProcess() {
        try {
            val command = mutableListOf(shellPath)
            command.addAll(args)

            val builder = ProcessBuilder(command)
            builder.directory(File(workingDirectory))
            builder.redirectErrorStream(true)

            val environment = builder.environment()
            env.forEach { (k, v) -> environment[k] = v }

            val p = builder.start()
            process = p
            processOutput = p.outputStream
            isRunning = true

            startReaderThread(p.inputStream)
        } catch (e: Exception) {
            Log.e("TerminalSession", "Error launching terminal process: ${e.message}", e)
            emulator.append("\u001B[31mError al iniciar shell: ${e.message}\u001B[0m\n")
            client?.onTextChanged(this)
            isRunning = false
        }
    }

    private fun startReaderThread(inputStream: InputStream) {
        scope.launch {
            val buffer = ByteArray(4096)
            try {
                while (isActive) {
                    val bytesRead = inputStream.read(buffer)
                    if (bytesRead == -1) break
                    val text = String(buffer, 0, bytesRead, Charsets.UTF_8)
                    emulator.append(text)
                    client?.onTextChanged(this@TerminalSession)
                }
            } catch (e: Exception) {
                // Stream closed or error
            } finally {
                isRunning = false
                client?.onSessionFinished(this@TerminalSession)
            }
        }
    }

    /**
     * Send input string to standard input of the shell process.
     */
    fun write(data: String) {
        if (!isRunning) return
        scope.launch {
            try {
                processOutput?.write(data.toByteArray(Charsets.UTF_8))
                processOutput?.flush()
            } catch (e: Exception) {
                Log.e("TerminalSession", "Failed writing to process: ${e.message}")
            }
        }
    }

    /**
     * Send raw bytes to standard input of the shell process.
     */
    fun write(data: ByteArray) {
        if (!isRunning) return
        scope.launch {
            try {
                processOutput?.write(data)
                processOutput?.flush()
            } catch (e: Exception) {
                Log.e("TerminalSession", "Failed writing bytes to process: ${e.message}")
            }
        }
    }

    fun updateTerminalSize(cols: Int, rows: Int) {
        emulator.columns = cols
        emulator.rows = rows
    }

    fun finishIfRunning() {
        if (isRunning) {
            try {
                process?.destroy()
            } catch (_: Exception) {}
            isRunning = false
        }
    }
}
